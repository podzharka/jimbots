package ru.jimbot.modules;

import ru.jimbot.modules.chat.Questions;

public class GameExtend
{
  private String uin;
  private int level;
  private long time;
  private Questions question;

  public GameExtend(String _uin, Questions _question, int _level, long expire)
  {
    this.time = (System.currentTimeMillis() + expire);
    this.level = _level;
    this.uin = _uin;
    this.question = _question;
  }

  public Questions getQuestion() {
    return this.question;
  }
  public int getLevel() {
    return this.level;
  }
  public String getUin() {
    return this.uin;
  }

  public boolean isExpire() {
    return System.currentTimeMillis() > this.time;
  }
}