package ru.jimbot.modules;

public class MillionaireExtend
{
  private String uin;
  private Integer level;
  private long time;
  private Integer question;
  private Integer answer;
  private Integer ball = Integer.valueOf(0);

  public MillionaireExtend(String uin, Integer level, Integer question, Integer answer, long time)
  {
    this.uin = uin;
    this.level = level;
    this.question = question;
    this.answer = answer;
    this.time = (System.currentTimeMillis() + time);
  }

  public String getUin() {
    return this.uin;
  }

  public Integer getLevel() {
    return this.level;
  }

  public Integer setLevel() {
    Integer localInteger1 = this.level; Integer localInteger2 = this.level = Integer.valueOf(this.level.intValue() + 1); return localInteger1;
  }

  public Integer getQuestion() {
    return this.question;
  }

  public Integer getAnswer() {
    return this.answer;
  }

  public void setQuestion(Integer question) {
    this.question = question;
  }

  public void setAnswer(Integer answer) {
    this.answer = answer;
  }

  public Integer getBall() {
    return this.ball;
  }

  public void setBall(Integer ball) {
    this.ball = ball;
  }

  public void updateTime(long time) {
    this.time = (System.currentTimeMillis() + time);
  }

  public boolean isTime() {
    return System.currentTimeMillis() > this.time;
  }
}