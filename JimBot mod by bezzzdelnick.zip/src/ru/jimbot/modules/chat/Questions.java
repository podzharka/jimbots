package ru.jimbot.modules.chat;

import ru.jimbot.db.DBObject;

public class Questions extends DBObject
{
  private int id = 0;
  private String question = "";
  private String answers = "";
  private int correct_answer = 0;
  private int difficulty_level = 0;

  public Questions() {
  }

  public Questions(int _id, String _question, String _answers, int _correct_answer, int _difficulty_level) {
    this.id = _id;
    this.question = _question;
    this.answers = _answers;
    this.correct_answer = _correct_answer;
    this.difficulty_level = _difficulty_level;
  }

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getQuestion() {
    return this.question;
  }

  public void setQuestion(String question) {
    this.question = question;
  }

  public String getAnswers() {
    return this.answers;
  }

  public void setAnswers(String answers) {
    this.answers = answers;
  }

  public int getDifficultyLevel() {
    return this.difficulty_level;
  }

  public void setDifficultyLevel(int difficulty_level) {
    this.difficulty_level = difficulty_level;
  }

  public boolean checkCorrectAnswer(int a) {
    return this.correct_answer == a;
  }

  public void setCorrectAnswer(int a) {
    this.correct_answer = a;
  }

  public String[] getFields()
  {
    return null;
  }

  public String getTableName()
  {
    return null;
  }

  public int[] getTypes()
  {
    return null;
  }
}