/**
* JimBot - Java IM Bot
* Copyright (C) 2006-2009 JimBot project
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package ru.jimbot.modules.chat;

import com.mysql.jdbc.PreparedStatement;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.Vector;
import java.util.StringTokenizer;
import java.util.concurrent.ConcurrentHashMap;
import ru.jimbot.Manager;

import ru.jimbot.Messages;
import ru.jimbot.modules.AbstractCommandProcessor;
import ru.jimbot.modules.AbstractServer;
import ru.jimbot.modules.Cmd;
import ru.jimbot.modules.CommandExtend;
import ru.jimbot.modules.CommandParser;
import ru.jimbot.modules.FloodElement;
import ru.jimbot.modules.WorkScript;
import ru.jimbot.modules.GameExtend;
import ru.jimbot.protocol.IcqProtocol;
import ru.jimbot.util.Log;
import ru.jimbot.util.MainProps;

/**
* Обработка команд чата
* 
* @author Prolubnikov Dmitry
*/
public class ChatCommandProc extends AbstractCommandProcessor {
public ChatServer srv;
private Random r = new Random();
public RobAdmin radm=null;
public AutoStatus xstatus = null;
public RobQuiz Quiz=null;
public ConcurrentHashMap<String, Integer> mobi;
private ConcurrentHashMap <String,String> up; // Запоминаем последний пришедший приват
private ConcurrentHashMap <String, KickInfo> statKick; // Расширенная статистика киков
private HashSet<String> warnFlag; // Флаг предупреждения о молчании
public int state=0;
private CommandParser parser;
private String uid = ""; //Текущий ИД для запроса версии, отвечает тока на свои ИД
private long new_ver_test_time = 0;
public ChatProps psp;
public ConcurrentHashMap<String, Long> mobitime;
public ClanCommand clan;
public Filter flt;
public long new_moroz_time = 0;
public long new_game_time = 0L;
private boolean firstStartMsg = false;
// Счетчики для контроля флуда: одинаковых сообщений, отброшеных сообщений
private ConcurrentHashMap <String, FloodElement> floodMap, floodMap2, floodNoReg;
private HashMap<String, CommandExtend> comMap;
// Для хранения доступных объектов авторизации
private HashMap<String, String> authObj = new HashMap<String, String>();
// Для хранения доступных команд
private HashMap<String, Cmd> commands = new HashMap<String, Cmd>();
private HashMap<String, GameExtend> gameMap;
public int getRND(int i){
return r.nextInt(i);
}

public boolean onlineAndAuthorized(IcqProtocol proc, String uin, String obj) {
if (psp.testAdmin(uin)) return true;
if (!isChat(proc,uin)) return false;
if (obj==null) return true;
return auth(proc,uin,obj);
}
public enum usersGroups
        {
        user, vip, killer, moder, admin, owner, owners;
        }
class KickInfo {
public int id=0;
public int len=0;
public int moder_id=0;
public int count=0;
public String reason = "";

KickInfo(int id, int moder_id, String r, int len) {
id = id;
len = len;
moder_id = moder_id;
reason = r;
count = 0;
}

public int inc() {return count++;}
}

/** Creates a new instance of ChatCommandProc */
public ChatCommandProc(ChatServer s) {
parser = new CommandParser(commands);
srv = s;
psp = ChatProps.getInstance(srv.getName());
up = new ConcurrentHashMap<String, String>();
statKick = new ConcurrentHashMap<String, KickInfo>();
floodMap = new ConcurrentHashMap <String, FloodElement>();
floodMap2 = new ConcurrentHashMap <String, FloodElement>();
floodNoReg = new ConcurrentHashMap <String, FloodElement>();
comMap = new HashMap<String, CommandExtend>();
warnFlag = new HashSet<String>();
clan = new ClanCommand(this);
flt = new Filter(this);
gameMap = new HashMap();
mobi = new ConcurrentHashMap();
mobitime = new ConcurrentHashMap();
init();
}

/**
* Инициализация списка команд и полномочий
*/
private void init(){
authObj.put("pmsg","Отправка приватных сообщений");
authObj.put("reg","Смена ника");
authObj.put("invite","Создание приглашения");
authObj.put("kickone","Кик одного пользователя");
authObj.put("kickall","Кик всех пользователей");
authObj.put("ban","Забанить пользователя");
authObj.put("settheme","Установить тему в комнате");
authObj.put("adminsay","Разговаривать с админом");
authObj.put("adminstat","Получать статистику от админа");
authObj.put("info","Получать информацию о юзере");
authObj.put("exthelp","Расширенная помощь");
authObj.put("authread","Получение инфы о полномочиях");
authObj.put("authwrite","Изменение полномочий пользователей");
authObj.put("whouser","Просмотр инфы о смене ников юзером");
authObj.put("room","Смена комнаты");
authObj.put("whoinv","Команда !whoinvite");
authObj.put("kickhist","Команда !kickhist");
authObj.put("chgkick","Изменение времени кика");
authObj.put("dblnick","Разрешено дублировать ник");
authObj.put("anyroom","Переход в любую комнату");
authObj.put("wroom","Создавать и изменять комнаты");
authObj.put("oxpana","возможность покупать охрану");
authObj.put("Kosti", "игра в кости");
authObj.put("Ryletka", "игра в рулетку");
authObj.put("doljnost","возможность покупать должность");
authObj.put("racia","рация-оператор");
authObj.put("OFF","сообщения от печкина");
authObj.put("allroom_mesage","во все комнаты");
authObj.put("zach","покупка щитов");
authObj.put("orujie","покупка оружия");
authObj.put("addbutilochka","Добавление фразы в игру \"Бутылочка\"");
authObj.put("Butilochka","Игра в бутылочку");
authObj.put("perevod","Перевод с кошелька на кошелек");
authObj.put("vbank","В банк");
authObj.put("izbank","Из банка");
authObj.put("banlast","Запереть юзера на время");
authObj.put("setpass","Установить пароль на комнату");
authObj.put("banroom","запирать и выпускать юзеров.");
authObj.put("chnick","Изменить ник юзеру.");
authObj.put("bar","Покупать выпивку.");
authObj.put("banother","Перетащить юзера в другую комнату.");
authObj.put("napadenie","Воровать у юзера");
authObj.put("admin","Вывод админов онлайн=)");
authObj.put("setclan", "Создание/удаление кланов");
authObj.put("casino", "игра casino");
authObj.put("game", "какаята игра");
authObj.put("ban_room", "убрать потом");
authObj.put("xst", "Менять xstatus");
authObj.put("razgovor", "разговаривать в чате");
authObj.put("svadba_razvod", "свадьба и развод юзеров =)");
authObj.put("exit", "команда !выход");
authObj.put("admin", "проверка админов онлайн");
authObj.put("invise", "спрятаться, показаться, невидимки");
authObj.put("zamorozka", "заморозка пользователя");
authObj.put("europe", "игра европейская рулетка");
authObj.put("uin", "отправка своего уины уина");
authObj.put("anek", "сервис анекдотов");
authObj.put("ownerhelp", "вывод справки для хозяев");
authObj.put("uchat", "затащить в чат.");

commands.put("!помощь", new Cmd("!помощь","",2));
commands.put("!справка", new Cmd("!справка","",2));
commands.put("!чат", new Cmd("!чат","",3));
commands.put("!вход", new Cmd("!вход","",3));
commands.put("!выход", new Cmd("!выход","",4));
commands.put("!правила", new Cmd("!правила","",5));
commands.put("!стат", new Cmd("!стат","",6));
commands.put("!гоуф", new Cmd("!гоуф","",7));
commands.put("!гоу", new Cmd("!гоу","$n",8));
commands.put("!пригласить", new Cmd("!пригласить","",9));
commands.put("!банлист", new Cmd("!банлист","",10));
commands.put("!киклист", new Cmd("!киклист","",11));
commands.put("!инфо", new Cmd("!инфо","$c",12));
commands.put("!кик", new Cmd("!кик","$c $n $s",13));
commands.put("!киквсех", new Cmd("!киквсех","",14));
commands.put("!листавт", new Cmd("!листавт","",15));
commands.put("!кто", new Cmd("!кто", "$n",16));
commands.put("!группы", new Cmd("!группы","",17));
commands.put("!права", new Cmd("!права","$n",18));
commands.put("!группа", new Cmd("!группа","$n $c",19));
commands.put("!полномочие", new Cmd("!полномочие","$n $c",20));
commands.put("!убрать", new Cmd("!убрать","$n $c",21));
commands.put("!бан", new Cmd("!бан","$c $s",22));
commands.put("!разбан", new Cmd("!разбан","$c",23));
commands.put("!рег", new Cmd("!рег","$c $c",24));
commands.put("!ник", new Cmd("!ник","$c $c",24));
commands.put("+тут", new Cmd("+тут","",25));
commands.put("+а", new Cmd("+а","",25));
commands.put("+лс", new Cmd("+лс","$n $s",26));
commands.put("+р", new Cmd("+р","$n $s",26));
commands.put("+ответ", new Cmd("+ответ","$s",27));
commands.put("!тема", new Cmd("!settheme","$s",28));
commands.put("!запрос", new Cmd("!запрос","$c",29));
commands.put("!комната", new Cmd("!комната", "$n $c", 33));
commands.put("!ктопригл", new Cmd("!ктопригл","$n",34));
commands.put("!кикхист", new Cmd("!кикхист","",35));
commands.put("!админу", new Cmd("!админу","$s",36));
commands.put("!банхист", new Cmd("!банхист","",37));
commands.put("+все", new Cmd("+все","",38));
commands.put("+аа", new Cmd("+аа","",38));
commands.put("!комнаты", new Cmd("!комнаты","",40));
commands.put("!созкомн", new Cmd("!созкомн","$n $s",41));
commands.put("!измкомн", new Cmd("!измкомн","$n $s",42));
commands.put("!охрана", new Cmd("!охрана","$c",43));
commands.put("!рычаг", new Cmd("!рычаг","$n $n",44));
commands.put("!рулетка", new Cmd("!рулетка","$n",45));
commands.put("!должность", new Cmd("!должность","$c",46));
commands.put("%", new Cmd("%", "$s", 47));
commands.put("!почта", new Cmd("!почта","",48));
commands.put("!сооб", new Cmd("!сооб", "$s", 49));
commands.put("!запереть", new Cmd("!запереть","$n $n", 50));
commands.put("!предложить",new Cmd("!предложить","$n",51));
commands.put("!арсенал", new Cmd("!арсенал","$c",52));
commands.put("!щит", new Cmd("!щит","$s",53));
commands.put("!оружие", new Cmd("!оружие","$n",54));
commands.put("!защита", new Cmd("!защита","$n",55));
commands.put("!огнемет", new Cmd("!огнемет","$n",56));
commands.put("!бутылочка", new Cmd("!бутылочка","",57));
commands.put("!сбут", new Cmd("!сбут","$s",58));
commands.put("!перевод", new Cmd("!перевод","$n $n",59));
commands.put("!банк", new Cmd("!банк","$n $n",60));
commands.put("!снять", new Cmd("!снять","$n $n",61));
commands.put("!анекдот", new Cmd("!анекдот","$s",62));
commands.put("!баш", new Cmd("!баш","$s",63));
commands.put("!анкета", new Cmd("!анкета","$n",64));
commands.put("!ледомет", new Cmd("!ледомет","$n",65));
commands.put("!богачи",new Cmd("!богачи","",66));
commands.put("!умники",new Cmd("!умники","",67));
commands.put("!мажоры",new Cmd("!мажоры","",68));
commands.put("!кенты",new Cmd("!кенты","",69));
commands.put("!кости",new Cmd("!кости","",70));
commands.put("!пароль", new Cmd("!пароль", "$c", 71));
commands.put("!купить", new Cmd("!купить","$n $s",72));
commands.put("!наперстки", new Cmd("!наперстки", "$n $n", 73));
commands.put("!выпустить", new Cmd("!выпустить", "$n", 74));
commands.put("!измник", new Cmd("!измник", "$n $c", 75));
commands.put("!бар", new Cmd("!бар", "$n", 76));
commands.put("!удкомн", new Cmd("!удкомн", "$n", 77));
commands.put("!кодз", new Cmd("!код", "$n", 78));
commands.put("!перетащить", new Cmd("!перетащить","$n $n", 79));
commands.put("!голос", new Cmd("!голос","$n $c",80));
commands.put("!напасть", new Cmd("!напасть", "$n", 81));
commands.put("!казино", new Cmd("!казино","",82));
commands.put("!админы", new Cmd("!админы","",83));
commands.put("!кодп", new Cmd("!кодп", "$n", 84));
commands.put("!кода", new Cmd("!кодп", "$n", 85));
commands.put("!здать", new Cmd("!здать", "$n $n", 86));
commands.put("!тюрьма", new Cmd("!тюрьма", "$n $n", 87));
commands.put("!отрезветь", new Cmd("!отрезветь","",88));
commands.put("!хстатус", new Cmd("!хстатус","$n $s",89));
commands.put("!свадьба", new Cmd("!свадьба", "$n $n", 90));
commands.put("!развод", new Cmd("!развод", "$n $n", 91));
commands.put("!смайлик", new Cmd("!смайлик", "$n", 92));
commands.put("!магазин", new Cmd("!магазин", "", 93));
commands.put("!свадьбы", new Cmd("!свадьбы", "", 94));
commands.put("!разводы", new Cmd("!разводы", "", 95));
commands.put("!чит", new Cmd("!чит", "$n", 96));
commands.put("!спрятаться", new Cmd("!спрятаться", "", 97));
commands.put("!показаться", new Cmd("!показаться", "", 98));
commands.put("!невидимки", new Cmd("!невидимки", "", 99));
commands.put("!игра", new Cmd("!игра", "$c $c", 100));
commands.put("!ответ", new Cmd("!ответ", "$c", 101));
commands.put("!ставка", new Cmd("!ставка", "$n $n $c", 102));
commands.put("!заморозка", new Cmd("!заморозка", "$n", 103));
commands.put("!уин", new Cmd("!уин", "$n", 104));
commands.put("!затащить", new Cmd("!затащить", "$n $s", 105));
commands.put("!команды", new Cmd("!команды","",106));
commands.put("!пдать", new Cmd("!пдать", "$n $n", 107));
commands.put("!адать", new Cmd("!адать", "$n $n", 108));
WorkScript.getInstance(srv.getName()).installAllChatCommandScripts(this);
commands.put("!about", new Cmd("!about","",1));
commands.put("!оботе", new Cmd("!оботе","",1));
}

/**
* Выдает список полномочий для работы
* @return
*/
public HashMap<String, String> getAuthObjects(){
return this.authObj;
}

/**
* Выдает список команд
* @return
*/
public HashMap<String, Cmd> getCommands(){
return this.commands;
}

/**
* Добавление нового объекта полномочий
* @param name
* @param comment
* @return - истина, если такой объект уже был в таблице
*/
public boolean addAuth(String name, String comment){
boolean f = authObj.containsKey(name);
authObj.put(name, comment);
return f;
}

/**
* Добавление новой команды
* @param name
* @param c
* @return - истина, если команда уже существует
*/
public boolean addCommand(String name, Cmd c) {
boolean f = commands.containsKey(name);
commands.put(name, c);
return f;
}

/**
* Возвращает экземпляр парсера
* @return
*/
public CommandParser getParser(){
return parser;
}



public AbstractServer getServer(){
return srv;
}

/**
* Основная процедура парсера команд
*/
public void parse(IcqProtocol proc, String uin, String mmsg) {
if(radm==null){
radm = new RobAdmin(srv);
radm.start();
} 
if(Quiz == null){
Quiz = new RobQuiz(srv);
Quiz.start();
}
if(psp.getBooleanProperty("auto_status.on.off")){
if(xstatus == null)
{
xstatus = new AutoStatus(srv);
xstatus.start();
}
}
state++;
Log.debug("CHAT: parse " + proc.baseUin + ", " + uin + ", " + mmsg);
if(psp.getBooleanProperty("chat.writeInMsgs"))
if(mmsg.length()>1000){
//Слишком длинные сообщения записывать в БД не нужно для избежания переполнений
srv.us.db.log(0,uin,"IN",mmsg.substring(0, 1000),0);
} else {
srv.us.db.log(0,uin,"IN",mmsg,0);
}
String tmsg = mmsg.trim();
if(tmsg.length()==0){
Log.error("Пустое сообщение в парсере команд: " + uin + ">" + mmsg);
return;
}
if(tmsg.charAt(0)=='!' || tmsg.charAt(0)=='+'){
Log.info("CHAT COM_LOG: " + uin + ">>" + tmsg);
}
try {   
if(srv.us.testUser(uin)){
if(isBan(uin)){
Log.flood2("CHAT_BAN: " + uin + ">" + mmsg);
return;
}
if(testKick(uin)>0){
infrequentSend(proc,uin,Messages.getString("ChatCommandProc.parse.7", new Object[] {testKick(uin)}));
Log.info("CHAT_KICK: " + uin + ">" + mmsg);
return;
}
if(srv.us.getUser(uin).state==UserWork.STATE_CHAT ||
srv.us.getUser(uin).state==UserWork.STATE_OFFLINE) goChat(proc, uin);
} else {
// Для нового юзера
// Проверка на флуд
if(floodNoReg.containsKey(uin)){
FloodElement e = floodNoReg.get(uin);
if(e.getDeltaTime()<(psp.getIntProperty("chat.floodTimeLimitNoReg")*1000)){
e.addMsg(tmsg);
floodNoReg.put(uin, e);
Log.flood("FLOOD NO REG " + uin + "> " + tmsg);
return; // Слишком часто
}
if(e.isDoubleMsg(tmsg) && e.getCount()>3){
e.addMsg(tmsg);
floodNoReg.put(uin, e);
Log.flood("FLOOD NO REG " + uin + "> " + tmsg);
return; // Повтор сообщений
}
e.addMsg(tmsg);
floodNoReg.put(uin, e);
} else {
FloodElement e = new FloodElement(psp.getIntProperty("chat.floodTimeLimitNoReg")*1000);
floodNoReg.put(uin, e);
}
if(tmsg.charAt(0)!='!' && !comMap.containsKey(uin)){
// Если это не команда - выводим приветствие, иначе обрабатываем команду
if(!psp.getBooleanProperty("chat.FreeReg")){
//                			proc.mq.add(uin,"Добро пожаловать в игровой чат.\n" +
//                					"Для помощи пошлите команду !справка\n" +
//                	                                "Не посылайте одинаковых сообщений и сообщения чаще " +
//                					psp.getIntProperty("chat.floodTimeLimitNoReg") + " сек.\n" +
proc.mq.add(uin,"Добро пожаловать в игровой чат.\n" +
"Для помощи пошлите команду !справка\n" +
"Не посылайте одинаковых сообщений и сообщения чаще " +
psp.getIntProperty("chat.floodTimeLimitNoReg") + " сек.\n" +
psp.getStringProperty("chat.inviteDescription"));
} else {
//                			proc.mq.add(uin,"Добро пожаловать в игровой чат.\n" +
//                					"Чтобы зарегистрироваться используйте команду !ник и ваш псведоним\n"+
//                					"Для помощи пошлите команду !справка\n" +
//                					"Не посылайте одинаковых сообщений и сообщения чаще " +
//                					psp.getIntProperty("chat.floodTimeLimitNoReg") + " сек.\n" );
proc.mq.add(uin,"Добро пожаловать в игровой чат.\n" +
"Чтобы зарегистрироваться используйте команду !ник и ваш псведоним\n"+
"Для помощи пошлите команду !справка\n" +
"Не посылайте одинаковых сообщений и сообщения чаще " +
psp.getIntProperty("chat.floodTimeLimitNoReg") + " сек.\n" );
}
return;
}
}
//            checkNewVersion(proc);
// Проверка на флуд
if(floodMap.containsKey(uin)){
FloodElement e = floodMap.get(uin);
e.addMsg(tmsg);
floodMap.put(uin, e);
} else {
FloodElement e = new FloodElement(psp.getIntProperty("chat.floodTimeLimit")*1000);
e.addMsg(tmsg);
floodMap.put(uin, e);
}
testFlood(proc,uin);
int tp = 0;
if(comMap.containsKey(uin) && srv.getProps().getBooleanProperty("chat.useCaptcha"))
if(!comMap.get(uin).isExpire())
tp = parser.parseCommand(comMap.get(uin).getCmd());
else {
tp = parser.parseCommand(tmsg);
comMap.remove(uin);
}
else
tp = parser.parseCommand(tmsg);
int tst=0;
if(tp<0)
tst=0;
else
tst = tp;
switch (tst){
case 1:
proc.mq.add(uin,MainProps.getAbout());
break;
case 2:
commandHelp(proc, uin);
break;
case 3:
goChat(proc, uin);
if(psp.getBooleanProperty("chat.getUserInfoOnChat"))
proc.mq.add(uin, "", 1); //proc.recUserInfo(uin,"0");
break;
case 4:
exitChat(proc, uin);
break;
case 5:
if(!isChat(proc,uin) && !psp.testAdmin(uin)) break;
proc.mq.add(uin,psp.getChatRules());
break;
case 6:
if(!psp.testAdmin(uin)) break;
proc.mq.add(uin,srv.us.getUinStat());
break;
case 7:
if(!isChat(proc,uin) && !psp.testAdmin(uin)) break;
commandGofree(proc, uin);
break;
case 8:
//TODO Выделить объект полномочий
if(!psp.testAdmin(uin)) break;
commandGo(proc, uin, parser.parseArgs(tmsg));
break;
case 9:
commandInvite(proc, uin);
break;
case 10:
if(!isChat(proc,uin) && !psp.testAdmin(uin)) break;
if(!auth(proc,uin, "ban")) return;
proc.mq.add(uin, srv.us.listUsers());
break;
case 11:
if(!isChat(proc,uin) && !psp.testAdmin(uin)) break;
if(!auth(proc,uin, "kickone")) return;
proc.mq.add(uin, listKickUsers());
break;
case 12:
commandInfo(proc, uin, parser.parseArgs(tmsg));
break;
case 13:
commandKick(proc, uin, parser.parseArgs(tmsg));
break;
case 14:
if(!isChat(proc,uin)) break;
if(!auth(proc,uin, "kickall")) return;
try{
kickAll(proc, uin);
} catch (Exception ex) {
ex.printStackTrace();
}
break;
case 15:
if(!isChat(proc,uin) && !psp.testAdmin(uin)) break;
if(!auth(proc,uin, "authread")) return;
proc.mq.add(uin,listAuthObjects());
break;
case 16:
commandWho(proc, uin, parser.parseArgs(tmsg));
break;
case 17:
if(!isChat(proc,uin) && !psp.testAdmin(uin)) break;
if(!auth(proc,uin, "authread")) return;
proc.mq.add(uin,psp.getStringProperty("auth.groups"));
break;
case 18:
commandCheckuser(proc, uin, parser.parseArgs(tmsg));
break;
case 19:
commandSetgroup(proc, uin, parser.parseArgs(tmsg));
break;
case 20:
commandGrant(proc, uin, parser.parseArgs(tmsg));
break;
case 21:
commandRevoke(proc, uin, parser.parseArgs(tmsg));
break;
case 22:
commandBan(proc, uin, parser.parseArgs(tmsg));
break;
case 23:
commandUban(proc, uin, parser.parseArgs(tmsg));
break;
case 24:
commandReg(proc, uin, parser.parseArgs(tmsg), mmsg);
break;
case 25:
commandA(proc, uin);
break;
case 26:
commandP(proc, uin, parser.parseArgs(tmsg), mmsg);
break;
case 27:
commandPP(proc, uin, parser.parseArgs(tmsg), mmsg);
break;
case 28:
commandSettheme(proc, uin, parser.parseArgs(tmsg));
break;
case 29:
commandGetinfo(proc, uin, parser.parseArgs(tmsg));
break;
case 30:
//                commandGetversion(proc, uin, parser.parseArgs(tmsg));
break;
case 31:
//                commandNewversion(proc, uin, parser.parseArgs(tmsg));
break;
//            case 32:
//                commandExec(proc, uin, parser.parseArgs(tmsg));
//                break;
case 33:
commandRoom(proc, uin, parser.parseArgs(tmsg));
break;
case 34: 
commandWhoinvite(proc, uin, parser.parseArgs(tmsg));
break;
case 35:
commandKickhist(proc, uin);
break;
case 36:
commandAdm(proc, uin, parser.parseArgs(tmsg));
break;
case 37:
commandBanhist(proc, uin);
break;
case 38:
commandAA(proc, uin);
break;
case 39: // Обработка команды макросом
String ret = WorkScript.getInstance(srv.getName()).startChatCommandScript(parser.parseCommand2(tmsg).script, tmsg, uin, proc, this);
if(!ret.equals("") && !ret.equals("ok")) proc.mq.add(uin,Messages.getString("ChatCommandProc.parse.2"));
break;
case 40:
commandLRoom(proc,uin);
break;
case 41:
commandCrRoom(proc, uin, parser.parseArgs(tmsg));
break;
case 42:
commandChRoom(proc, uin, parser.parseArgs(tmsg));
break;
case 43:
commandoxpana(proc, uin, parser.parseArgs(tmsg));
break;
case 44:
commandCasino(proc, uin, parser.parseArgs(tmsg));
break;
case 45:
commandRyletka(proc, uin, parser.parseArgs(mmsg));
break;
case 46:
commandDoljnost(proc, uin, parser.parseArgs(mmsg));
break;
case 47:
commandOpChat(proc, uin, parser.parseArgs(mmsg));
break;
case 48:
commandOFFMail(proc, uin, parser.parseArgs(mmsg));
break;
case 49:
commandSend(proc, uin, parser.parseArgs(mmsg));
break;
case 50:
commandBanroom(proc, uin, parser.parseArgs(mmsg));
break;
case 51:
commandPredlozhit(proc, uin, parser.parseArgs(tmsg));
break;
case 52:
commandArsenal(proc, uin, parser.parseArgs(tmsg));
break;
case 53:
commandSchit(proc, uin, parser.parseArgs(tmsg));
break;
case 54:
commandOryjie(proc, uin, parser.parseArgs(tmsg));
break;
case 55:
commandZachita(proc, uin, parser.parseArgs(tmsg));
break;
case 56:
commandFire(proc, uin, parser.parseArgs(tmsg));
break;
case 57:
commandbutilochka(proc,uin);
break;
case 58:
commandcbut(proc, uin, parser.parseArgs(tmsg));
break;
case 59:
commandPerevod(proc, uin, parser.parseArgs(tmsg));
break;
case 60:
commandVbank(proc, uin, parser.parseArgs(tmsg));
break;
case 61:
commandIzbank(proc, uin, parser.parseArgs(tmsg));
break;
case 62:
commandAnek(proc, uin, parser.parseArgs(tmsg));
break;
case 63:
commandBash(proc, uin, parser.parseArgs(tmsg));
break;
case 64:
commandAnketa(proc, uin, parser.parseArgs(tmsg));
break;
case 65:
commandAce(proc, uin, parser.parseArgs(tmsg));
break;
case 66:
commandBagach(proc, uin, parser.parseArgs(tmsg));
break;
case 67:
commandYmniki(proc, uin, parser.parseArgs(tmsg));
break;
case 68:
commandMa(proc, uin, parser.parseArgs(tmsg));
break;
case 69:
commandKent(proc, uin, parser.parseArgs(tmsg));
break;
case 70:
commandKosti(proc, uin, parser.parseArgs(tmsg));
break;
case 71:     
commandSetpass(proc, uin, parser.parseArgs(tmsg));
break;
case 72:
commandKomnata(proc, uin, parser.parseArgs(tmsg));
break;
case 73:
commandHaperstok(proc, uin, parser.parseArgs(tmsg));
break;
case 74:
commandUBanRoom(proc, uin, parser.parseArgs(tmsg));
break;
case 75:
commandChnNick(proc, uin, parser.parseArgs(tmsg));
break;
case 76:
commandBar(proc, uin, parser.parseArgs(tmsg));
break;
case 77:
commandDeleteRoom(proc, uin, parser.parseArgs(tmsg));
break;
case 78:
commandSmszoloto(proc, uin, parser.parseArgs(tmsg));
break;
case 79:
commandBanother(proc, uin, parser.parseArgs(tmsg));
break;
case 80:
commandGolos(proc, uin, parser.parseArgs(tmsg));
break;
case 81:
commandNapadenie(proc, uin, parser.parseArgs(tmsg));
break;
case 82:
commandKazino(proc, uin, parser.parseArgs(tmsg));
break;
case 83:
commandAdmin(proc, uin, parser.parseArgs(tmsg));
break;
case 84:
commandSmspre(proc, uin, parser.parseArgs(tmsg));
break;
case 85:
commandSmsavto(proc, uin, parser.parseArgs(tmsg));
break;
case 86:
commandZoloto(proc, uin, parser.parseArgs(tmsg));
break;
case 87:
commandBanRoom(proc, uin, parser.parseArgs(tmsg));
break;
case 88:
commandTrezv(proc, uin, tmsg, parser.parseArgs(tmsg));
break;
case 89:
commandXst(proc, uin, parser.parseArgs(tmsg));
break;
case 90:
commandSvadba(proc, uin, parser.parseArgs(tmsg), mmsg);
break;
case 91:
commandRazvod(proc, uin, parser.parseArgs(tmsg), mmsg);
break;
case 92:
commandSmailik(proc, uin, parser.parseArgs(tmsg), mmsg);
break;
case 93:
commandMagazin(proc, uin, parser.parseArgs(tmsg), mmsg);
break;
case 94:
commandSvadbaHist(proc, uin);
break;
case 95:
commandRazvodHist(proc, uin);
break;
case 96:
commandChit(proc, uin, parser.parseArgs(tmsg), mmsg);
break;
case 97:
commandInvise(proc, uin);
break;
case 98:
commandUinvise(proc, uin);
break;
case 99:
if ((isChat(proc, uin)) || (psp.testAdmin(uin)))
commandScrilis(proc, uin);
break;
case 100:
commandGame(proc, uin, parser.parseArgs(tmsg));
break;
case 101:
commandAnswer(proc, uin, parser.parseArgs(tmsg));
break;
case 102:
commandStavka(proc, uin, parser.parseArgs(mmsg));
break;
case 103:
commandMoroz(proc, uin, parser.parseArgs(mmsg));
break;
case 104:
commandUin(proc, uin, parser.parseArgs(mmsg));
break;
case 105:
commandZat(proc, uin, this.parser.parseArgs(tmsg), mmsg);
break;
case 106:
commandGames(proc, uin);
break;
case 107:
commandPres(proc, uin, parser.parseArgs(tmsg));
break;
case 108:
commandAvto(proc, uin, parser.parseArgs(tmsg));
break;
default:
if(flt.Parse(proc, uin, mmsg)) return;
if(clan.commandClan(proc, uin, mmsg)) return;
if(srv.us.getUser(uin).state==UserWork.STATE_CHAT){
//Сообщения начинающиеся с "!" и "+" не выводим в чат
try{
if(mmsg.substring(0, 1).equals("!")){
proc.mq.add(uin,Messages.getString("ChatCommandProc.parse.3"));
return;
}
if(srv.us.getUser(uin).bar != 0) {
mmsg = getBar(uin, mmsg);
}
} catch (Exception ex){
ex.printStackTrace();
}
if(psp.getBooleanProperty("adm.useAdmin")) radm.parse(proc,uin,mmsg,srv.us.getUser(uin).room);
if(psp.getBooleanProperty("filter.on")) mmsg = flt.mmsg (proc, mmsg, uin);
if(mmsg.equals("")) return;
String s = "";
String f = "";
File Persona1 = new File("./text/" + srv.getName() + "/sva/" + srv.us.getUser(uin).id  + ".txt");
if (Persona1.exists()) {
f = f + "" + psp.loadText(new StringBuilder().append("./text/").append(srv.getName()).append("/sva/").append(srv.us.getUser(uin).id ).append(".txt").toString());
f = f.replace('\n', ' ');
}
String group=srv.us.getUser(uin).group;
if (!auth(proc, uin, "razgovor")) return;
if (!group.equals("user")) s+="["+russGroup(uin)+"]";
else s += "["+srv.us.getUser(uin).id+"]";
if(mmsg.indexOf("/me")==0)
s = mmsg.replaceFirst("/me", "*" + srv.us.getUser(uin).localnick+f);
else
s += srv.us.getUser(uin).localnick + f + psp.getStringProperty("chat.delimiter")
+" " + mmsg;
if(s.length()>psp.getIntProperty("chat.MaxMsgSize")){
s = s.substring(0,psp.getIntProperty("chat.MaxMsgSize"));
proc.mq.add(uin,"Система: Слишком длинное сообщение было обрезано: " + s);
}
s = s.replace('\n',' ');
s = s.replace('\r',' ');
Log.talk("CHAT: " + uin + "<" + srv.us.getUser(uin).id +"> ["+srv.us.getUser(uin).room +"]>>" + s);
srv.us.db.log(srv.us.getUser(uin).id,uin,"OUT", s, srv.us.getUser(uin).room);
srv.cq.addMsg(s, uin, srv.us.getUser(uin).room);
Quiz.parse(uin, mmsg, srv.us.getUser(uin).room);
} else {
if(srv.us.getUser(uin).state==UserWork.STATE_NO_CHAT){
proc.mq.add(uin,"Для входа в чат используйте команду !чат. Для помощи пошлите команду !справка\n" +
"Не посылайте ваши сообщения слишком часто.");
} else {
proc.mq.add(uin,"Для входа в чат необходимо зарегистрироваться командой !ник никнейм. \n" +
"Для помощи пошлите команду !справка\n" +
"Не посылайте ваши сообщения слишком часто.");
}
}
}
} catch (Exception ex) {
ex.printStackTrace();
}
}

/**
* Команды чата
*/

/**
* !help
*/
public void commandHelp(IcqProtocol proc, String uin){
String[] s = psp.getHelp1().split("<br>");
for(int i=0;i<s.length;i++){
proc.mq.add(uin,s[i]);
}        
if(srv.us.authorityCheck(uin, "exthelp")){
s = psp.getHelp2().split("<br>");
for(int i=0;i<s.length;i++){
proc.mq.add(uin,s[i]);
}
if(srv.us.authorityCheck(uin, "ownerhelp")){
s = psp.getHelp3().split("<br>");
for(int i=0;i<s.length;i++){
proc.mq.add(uin,s[i]);
    }
}
}        
}
/**
* !команды
*/
public void commandGames(IcqProtocol proc, String uin){
String[] s = psp.getGames().split("<br>");
for(int i=0;i<s.length;i++){
proc.mq.add(uin,s[i]);
}
    }
private String antiadvertising(String msg)
  {
    Integer maxCnt = Integer.valueOf(this.psp.getIntProperty("antiadvertising.integer.cnt"));
    Integer Cnt = Integer.valueOf(0);
    String[] number = this.psp.getStringProperty("antiadvertising.number").split(";");
    String delimiters = this.psp.getStringProperty("antiadvertising.delimiters");
    StringTokenizer st = new StringTokenizer(msg, delimiters);
    while (st.hasMoreTokens()) {
      String s = st.nextToken();
      for (int i = 0; i < number.length; ++i)
      {
        Integer localInteger1;
        if ((((s.indexOf(number[i]) != -1) ? 1 : 0) & ((s.indexOf("%") == -1) ? 1 : 0)) != 0) {
          localInteger1 = Cnt; Integer localInteger2 = Cnt = Integer.valueOf(Cnt.intValue() + 1);
        }if (Cnt.intValue() > maxCnt.intValue())
          msg = msg.replace(s, "*");
      }
    }
    return msg;
  }

  private boolean testInteger(String msg)
  {
    Integer answer;
    try
    {
      answer = Integer.valueOf(Integer.parseInt(msg));
    } catch (NumberFormatException e) {
      return false;
    }
    return true;
  }
/**
* !gofree
* @param proc
* @param uin
*/
public void commandGofree(IcqProtocol proc, String uin){
try{
String s = srv.us.getFreeUin();
changeBaseUin(uin,s);
proc.mq.add(uin,"Система: Успешно завершено. Сообщения теперь будут приходить с номера " + s);
}catch (Exception ex){
ex.printStackTrace();
proc.mq.add(uin,"Ошибка "+ex.getMessage());
}        
}

/**
* !go
* @param proc
* @param uin
* @param v
*/
public void commandGo(IcqProtocol proc, String uin, Vector v){
try{
int k = (Integer)v.get(0);
if(k>=psp.uinCount() || k<0){
proc.mq.add(uin,"Ошибка: Ошибочный номер");
return;
}
changeBaseUin(uin,psp.getUin(k));
proc.mq.add(uin,"Система: Успешно завершено. Сообщения теперь будут приходить с номера " + psp.getUin(k));
} catch (Exception ex){
ex.printStackTrace();
proc.mq.add(uin, Messages.getString("ChatCommandProc.err", new Object[] {ex.getMessage()}));
}    
}

/**
* !invite
* @param proc
* @param uin
*/
public void commandInvite(IcqProtocol proc, String uin){
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(psp.getBooleanProperty("chat.FreeReg")){
proc.mq.add(uin,"Система: Чат открыт для свободного входа, приглашения создавать не нужно.");
return;
}
if(!auth(proc,uin, "invite")) return;
String s = srv.us.createInvite(srv.us.getUser(uin).id);
if(s.equals("")) {
proc.mq.add(uin,"Система: Не удалось создать новое приглашение, вы не использовали еще старое приглашение.");
} else {
proc.mq.add(uin,"Система: Создано новое приглашение, пароль: " + s +
"\nСрок действия, часов: " + psp.getIntProperty("chat.MaxInviteTime"));
}        
}

/**
* !info
* @param proc
* @param uin
* @param v
*/
public void commandInfo(IcqProtocol proc, String uin, Vector v){
if(!auth(proc,uin, "info")) return;
try {
String s = (String)v.get(0);
if(s.length()>=6){
proc.mq.add(uin,srv.us.getUserInfo(s));
} else {
try{
proc.mq.add(uin,srv.us.getUserInfo(Integer.parseInt(s)));
} catch (Exception ex){
proc.mq.add(uin,"Ошибка в команде");
}
}
} catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin, Messages.getString("ChatCommandProc.err", new Object[] {ex.getMessage()}));
}        
}

/**
* !kick
* @param proc
* @param uin
* @param v
*/
public void commandKick(IcqProtocol proc, String uin, Vector v){
if (!onlineAndAuthorized(proc, uin, "kickone")) return;
int moder_id = srv.us.getUser(uin).id;
String s = (String)v.get(0);
int t = (Integer)v.get(1);
Users uss = srv.us.getUser(uin);
String reason = (String)v.get(2);
int id=0;
try {
id = Integer.parseInt(s);
} catch (NumberFormatException ex){
proc.mq.add(uin,"Ошибка: \""+s+"\" не является числом.");
return;
}
String i = srv.us.getUser(id).sn;
if (psp.testAdmin(i)){
proc.mq.add(uin,"Система: Вы не можете кикнуть администратора чата!");
return;
}
if (testKick(i)>0 && !srv.us.authorityCheck(uin, "chgkick")) {
proc.mq.add(uin,"Система: Вы не можете изменить время кика.");
return;
}
if(t==0){
tkick(proc, i, psp.getIntProperty("chat.defaultKickTime"), moder_id,"");
proc.mq.add(uin,"Система: Юзер кикнут на: " + psp.getIntProperty("chat.defaultKickTime"));
}
else {
if (reason.equals("")) {
proc.mq.add(uin,"Система: Необходимо добавить причину кика.");
return;
}
int maxKickTime=psp.getIntProperty("chat.maxKickTime");
if (t>maxKickTime) t=maxKickTime;
tkick(proc, i, t, moder_id, reason);
proc.mq.add(uin,"Система: Юзер кикнут на: " + t);
srv.cq.addMsg(srv.us.getUser(i).localnick + " был удалён из чата на (" + t + ") минут,модератором [ID=" + uss.id + "] " + uss.localnick + " причина: "+ reason, i, srv.us.getUser(i).room);
}
}

/**
* !who
* @param proc
* @param uin
* @param v
*/
public void commandWho(IcqProtocol proc, String uin, Vector v){
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "whouser")) return;
try{
int id = (Integer)v.get(0);
proc.mq.add(uin, srv.us.getUserNicks(id));
} catch (Exception ex){
ex.printStackTrace();
proc.mq.add(uin, Messages.getString("ChatCommandProc.err", new Object[] {ex.getMessage()}));
}                        
}

/**
* !checkuser
* @param proc
* @param uin
* @param v
*/
public void commandCheckuser(IcqProtocol proc, String uin, Vector v){
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "authread")) return;
try{
int id = (Integer)v.get(0);
proc.mq.add(uin, srv.us.getUserAuthInfo(id));
} catch (Exception ex){
ex.printStackTrace();
proc.mq.add(uin, Messages.getString("ChatCommandProc.err", new Object[] {ex.getMessage()}));
}        
}

/**
* !setgroup
* @param proc
* @param uin
* @param v
*/
public void commandSetgroup(IcqProtocol proc, String uin, Vector v){
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "authwrite")) return;
try{
String s1 = (String)v.get(1);
int id = (Integer)v.get(0);
Users uss = srv.us.getUser(id);
if(uss.id!=id){
proc.mq.add(uin,"Ошибка: Пользователь не найден");
return;
}
if(!testUserGroup(s1)){
proc.mq.add(uin,"Ошибка: Нет такой группы пользователей");
return;
}
uss.group = s1;
boolean f = srv.us.setUserPropsValue(id, "group", s1) &&
srv.us.setUserPropsValue(id, "grant", "") &&
srv.us.setUserPropsValue(id, "revoke", "");
srv.us.clearCashAuth(id);
if(f)
proc.mq.add(uin,"Система: Успешно завершено");
else
proc.mq.add(uin,"Ошибка: Произошла ошибка");
} catch (Exception ex){
ex.printStackTrace();
proc.mq.add(uin, Messages.getString("ChatCommandProc.err", new Object[] {ex.getMessage()}));
}        
}

/**
* !grant
* @param proc
* @param uin
* @param v
*/
public void commandGrant(IcqProtocol proc, String uin, Vector v){
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "authwrite")) return;
try{
String s1 = (String)v.get(1);
int id = (Integer)v.get(0);
Users uss = srv.us.getUser(id);
if(uss.id!=id){
proc.mq.add(uin,"Ошибка: Пользователь не найден");
return;
}
if(!testAuthObject(s1)){
proc.mq.add(uin,"Ошибка: Нет такого объекта полномочий");
return;
}
if(srv.us.grantUser(id, s1))
proc.mq.add(uin,"Система: Успешно завершено");
else
proc.mq.add(uin,"Система: Произошла ошибка");
} catch (Exception ex){
ex.printStackTrace();
proc.mq.add(uin, Messages.getString("ChatCommandProc.err", new Object[] {ex.getMessage()}));
}        
}

/**
* !revoke
* @param proc
* @param uin
* @param v
*/
public void commandRevoke(IcqProtocol proc, String uin, Vector v){
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "authwrite")) return;
try{
String s1 = (String)v.get(1);
int id = (Integer)v.get(0);
Users uss = srv.us.getUser(id);
if(uss.id!=id){
proc.mq.add(uin,"Ошибка: Пользователь не найден");
return;
}
if(!testAuthObject(s1)){
proc.mq.add(uin,"Ошибка: Нет такого объекта полномочий");
return;
}
if(srv.us.revokeUser(id, s1))
proc.mq.add(uin,"Система: Успешно завершено");
else
proc.mq.add(uin,"Ошибка: Произошла ошибка");
} catch (Exception ex){
ex.printStackTrace();
proc.mq.add(uin, Messages.getString("ChatCommandProc.err", new Object[] {ex.getMessage()}));
}                
}

/**
* !ban
* @param proc
* @param uin
* @param v
*/
public void commandBan(IcqProtocol proc, String uin, Vector v){
if (!onlineAndAuthorized(proc, uin, "ban")) return;
String reason = (String)v.get(1);
if (reason.length()==0) {
proc.mq.add(uin,"Система: Необходимо добавить причину бана.");
return;
}
String s = (String)v.get(0);
Users bannedUser;
if (s.length()<6) {
int id = 0;
try {
id = Integer.parseInt(s);
} catch(NumberFormatException ex) {
proc.mq.add(uin,"Ошибка: \""+s+"\" не является числом.");
return;
}
bannedUser=srv.us.getUser(id);
s=bannedUser.sn;
}
else bannedUser=srv.us.getUser(s);
if (psp.testAdmin(s)){
proc.mq.add(uin,"Система: Вы не можете забанить администратора чата!");
return;
}
if (uin.equals(s)) {
proc.mq.add(uin,"Система: Нельзя забанить самого себя!");
return;
}
if (s.length()==0) return;
ban(proc, s, uin,reason);
proc.mq.add(uin,"Система: Пользователь " + s + " успешно забанен *YES*");
srv.cq.addMsg(bannedUser.localnick + " был забанен, причина: "+ reason, s, bannedUser.room);
}

/**
* !uban
* @param proc
* @param uin
* @param v
*/
public void commandUban(IcqProtocol proc, String uin, Vector v){
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "ban")) return;
try{
String s = (String)v.get(0);
String i="";
if(s.length()>=6){
uban(proc, s, uin);
} else {
int id = 0;
try {
id = Integer.parseInt(s);
} catch (Exception e) {
proc.mq.add(uin,"Ошибка: Ошибка в команде");
}
i = srv.us.getUser(id).sn;
if(!i.equals("")) uban(proc, i, uin);
proc.mq.add(uin,"Система: Пользователь " + i + " был выпущен из бани");
}            
} catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin, Messages.getString("ChatCommandProc.err", new Object[] {ex.getMessage()}));
}        
}

/**
* !reg
* @param proc
* @param uin
* @param v
* @param mmsg
*/
public void commandReg(IcqProtocol proc, String uin, Vector v, String mmsg){
try{
boolean twoPart = false; // Второй заход в процедуру после ответа?
if(srv.getProps().getBooleanProperty("chat.useCaptcha") && comMap.containsKey(uin)){
if(comMap.get(uin).getMsg().equalsIgnoreCase(mmsg)){
twoPart=true;
v = comMap.get(uin).getData();
comMap.remove(uin);
} else {
proc.mq.add(uin,"Система: Вы неправильно ответили на вопрос, попытайтесь зарегистрироваться еще раз.");
comMap.remove(uin);
return;
}
}
int maxNick = psp.getIntProperty("chat.maxNickLenght");
String lnick = (String)v.get(0);
Users uss = srv.us.getUser(uin);
if (lnick.equals("") || lnick.equals(" ")){
proc.mq.add(uin,"Ошибка: Ошибка регистрации, пустой ник");
Log.talk(uin + " Reg error: " + mmsg);
return;
}
if(lnick.length()>maxNick) {
lnick = lnick.substring(0,maxNick);
proc.mq.add(uin,"Система: Ваш ник слишком длинный и будет обрезан.");
}
String newNick=testNick(uin,lnick);
        if (newNick==null) {
            proc.mq.add(uin,"Ошибка: Пустой ник.");
            return;
        }
        if (!newNick.equals(lnick)) {
            lnick=newNick;
            proc.mq.add(uin,"Система: В вашем нике содержаться запретные символы, они будут удалены.");
        }
lnick = lnick.replace('\n',' ');
lnick = lnick.replace('\r',' ');
if(psp.getBooleanProperty("chat.isUniqueNick") && !qauth(proc,uin,"dblnick") && !psp.testAdmin(uin))
if(srv.us.isUsedNick(lnick)){
proc.mq.add(uin,"Ошибка: Такой ник уже существует. Попробуйте другой ник.");
return;
}
String oldNick = uss.localnick;
//смена ника - юзер уже в чате, пароль не нужен
if(uss.state!=UserWork.STATE_NO_REG) {
if(!auth(proc,uin, "reg")) return;
if(uss.state!=UserWork.STATE_CHAT) return; // Менять ник тока в чате
if(srv.us.getCountNickChange(uss.id)>psp.getIntProperty("chat.maxNickChanged")){
proc.mq.add(uin,"Система: Вы не можете так часто менять ник.");
return;
}
if(oldNick.equals(lnick)){
if(uss.state==UserWork.STATE_NO_CHAT)
proc.mq.add(uin,"Система: Ник не изменен. Для входа в чат используйте команду !вход");
else
proc.mq.add(uin,"Ошибка: Ник не изменен.");
return;
}
uss.localnick = lnick;
Log.talk(uin + " update " + mmsg);
proc.mq.add(uin,"Система: Обновление завершено");
srv.cq.addMsg("Система: У пользователя ''" + oldNick + "'' ник изменен на ''" + lnick, "''", uss.room);
srv.us.db.log(uss.id,uin,"REG",lnick,uss.room);
srv.us.db.event(uss.id, uin, "REG", 0, "", lnick);
uss.basesn = proc.baseUin;
srv.us.updateUser(uss);
return;
}
testNick(uin,lnick);
        if (newNick==null) {
            proc.mq.add(uin,"Ошибка: Пустой ник.");
            return;
        }
        if (!newNick.equals(lnick)) {
            lnick=newNick;
            proc.mq.add(uin,"Система: В вашем нике содержаться запретные символы, они будут удалены.");
        }
// Свободная регистрация
if(psp.getBooleanProperty("chat.FreeReg") ||
psp.testAdmin(uin)){
if(srv.getProps().getBooleanProperty("chat.useCaptcha") && !twoPart){
String s = getCaptcha();
proc.mq.add(uin,"Система: Взяли калькулятор;)? Да? Напишите ответ на несложный пример." +
"Время на раздумье 5 минут, перед ответом подождите 20 секунд, пример: " + s.split("=")[0] + "=");
comMap.put(uin, new CommandExtend(uin, mmsg, s.split("=")[1],v, 5*60000));
return;
}
uss.state=UserWork.STATE_NO_CHAT;
uss.basesn = proc.baseUin;
uss.localnick = lnick;
int id = srv.us.addUser(uss);
proc.mq.add(uin, "", 1);
Log.talk(uin + " Reg new user: " + mmsg);
srv.us.db.log(id,uin,"REG",lnick,uss.room);
srv.us.db.event(id, uin, "REG", 0, "", lnick);
srv.cq.addMsg("Система: Зарегистрировался пользователь " + uss.localnick + "[ID=" + uss.id + "]", "", uss.room);
proc.mq.add(uin,("Вы зарегестрировались в лучшем чатике от (c)bezzzdelnick, вход в чат по команде !чат"));
return;
}
// Регистрация по приглашению
String inv = (String)v.get(1);
if(inv.equals("")){
Log.talk(uin + " Reg error: " + mmsg);
proc.mq.add(uin,Messages.getString("ChatCommandProc.commandReg.12") + "\n" +
psp.getStringProperty("chat.inviteDescription"));
return;
}
if(srv.us.testInvite(inv)){
if(!srv.us.updateInvite(uin,inv)){
proc.mq.add(uin,Messages.getString("ChatCommandProc.commandReg.13") + "\n" +
psp.getStringProperty("chat.inviteDescription"));
Log.talk(uin + " Reg error: " + mmsg);
} else {
if(srv.getProps().getBooleanProperty("chat.useCaptcha") && !twoPart){
String s = getCaptcha();
proc.mq.add(uin,"Система: Взяли калькулятор;)? Да? Напишите ответ на несложный пример." +
"Время на раздумье 5 минут, перед ответом подождите 20 секунд, пример: " + s.split("=")[0] + "=");
comMap.put(uin, new CommandExtend(uin, mmsg, s.split("=")[1],v, 60000));
return;
}
uss.state=UserWork.STATE_NO_CHAT;
uss.basesn = proc.baseUin;
uss.localnick = lnick;
srv.us.updateUser(uss);
int id = srv.us.addUser(uss);
proc.mq.add(uin, "", 1);
srv.cq.addMsg("Система: Зарегистрировался пользователь " + uss.localnick + "[ID=" + uss.id + "]", "", uss.room);
proc.mq.add(uin,"Вы зарегестрировались в лучшем чате,от (c)bezzzdelnick ,вход в чат по команде !чат");
srv.us.db.log(id,uin,"REG",lnick, uss.room);
srv.us.db.event(id, uin, "REG", 0, "", lnick);
}
} else {
Log.talk(uin + " Reg error: " + mmsg);
proc.mq.add(uin, Messages.getString("ChatCommandProc.commandReg.14") + "\n" +
psp.getStringProperty("chat.inviteDescription"));//"Для регистрации в чате вам необходимо получить приглашение одного из пользователей.");
return;
}
} catch (Exception ex) {
ex.printStackTrace();
Log.talk(uin + " Reg error: " + mmsg);
proc.mq.add(uin,Messages.getString("ChatCommandProc.commandReg.13"));
}
}

/**
* +a
* @param proc
* @param uin
*/
public void commandA(IcqProtocol proc, String uin){
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
int room = srv.us.getUser(uin).room;
    Enumeration e1 = srv.cq.uq.keys();
    Enumeration e2 = srv.cq.uq.keys();
String s = "Комната: (" +room + ") - " + srv.us.getRoom(room).getName() +
"\nТема: " + srv.us.getRoom(room).getTopic() +
"\nСписок пользователей в комнате:\n";
if(psp.getBooleanProperty("adm.useAdmin"))
s += "0 - " + radm.NICK + '\n';
    int knt = 0;
    while (e1.hasMoreElements()) {
      String i1 = (String)e1.nextElement();
      Users uss = this.srv.us.getUser(i1);
      if ((uss.state == 2) && (!this.srv.us.authorityCheck(uss.id, "invisible")))
        ++knt;
    }
        int cnt = 0;
Enumeration<String> e = srv.cq.uq.keys();
while(e.hasMoreElements()){
String i = e.nextElement();
Users us = srv.us.getUser(i);
if(us.state==UserWork.STATE_CHAT){
      if ((us.state == 2) && (!this.srv.us.authorityCheck(us.id, "invisible")) && (us.room == room))
      {
cnt++;
int id = us.id;
if(us.room==room) s += us.id + " - " + us.localnick + " ["+ us.room + "]" + '\n';
}
}
}
s += "\nВсего пользователей в комнате: [" + cnt + "]";
        s += "\nВсего пользователей в чате: [" + knt + "]";
s += "\nВсего за сегодня зашло пользователей в чат: [" + srv.us.statUsersCount() + "]";
s += "\nВсего зарегано пользователей: ["+Integer.toString(srv.us.count()) + "]";
        proc.mq.add(uin, s);
String a=psp.getStringProperty("chat.aa");
a=a.replace(";","\n-------\n");
proc.mq.add(uin, "Новости: "+a);
    }

/**
* +aa
* @param proc
* @param uin
*/
public void commandAA(IcqProtocol proc, String uin){
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
int room = srv.us.getUser(uin).room;
int cnt=0;
String s = "Список пользователей в чате:\n";
if(psp.getBooleanProperty("adm.useAdmin"))
s += "0 - " + radm.NICK + '\n';
Enumeration<String> e = srv.cq.uq.keys();
while(e.hasMoreElements()){
String i = e.nextElement();
Users us = srv.us.getUser(i);
if ((us.state == 2) && (!this.srv.us.authorityCheck(us.id, "invisible"))) {
cnt++;
        String f = "";
        File Persona1 = new File("./text/" + this.srv.getName() + "/sva/" + us.id + ".txt");
        if (Persona1.exists()) {
          f = f + "" + this.psp.loadText(new StringBuilder().append("./text/").append(this.srv.getName()).append("/sva/").append(us.id).append(".txt").toString());
          f = f.replace('\n', ' ');
        }
if(us.state==UserWork.STATE_CHAT) s +="[" + us.id + "] - " + us.localnick + " ("+ us.room + ")" + '\n';
}
}
s += "\nВсего пользователей в чате: [" + cnt + "]";
s += "\nВсего за сегодня зашло пользователей в чат: [" + srv.us.statUsersCount() + "]";
s += "\nВсего зарегано пользователей: ["+Integer.toString(srv.us.count()) + "]";
proc.mq.add(uin, s);
String a=psp.getStringProperty("chat.aa");
a=a.replace(";","\n-------\n");
proc.mq.add(uin, "Новости: "+a);
}
/**
* +p
* @param proc
* @param uin
* @param v
* @param tmsg
*/
public void commandP(IcqProtocol proc, String uin, Vector v, String tmsg){
if(!isChat(proc,uin)) return;
if(!auth(proc,uin, "pmsg")) return;
try{
int no = (Integer)v.get(0);
String txt = (String)v.get(1);
if (psp.getBooleanProperty("filter.private.on")) txt = flt.mmsg (proc, txt, uin);
if(txt.equals("")) {
proc.mq.add(uin,"Система: Сообщение отсутствует");
return;
}
Users uss = srv.us.getUser(no);
if(uss == null){
proc.mq.add(uin,"Система: Такого пользователя не существует");
return;
}
if(!srv.cq.testUser(uss.sn)){
srv.us.db.info(uss.id, "", "OFFLINE", srv.us.getUser(uin).id, "", txt);
// Сообщаем об успешном выполнении команды
proc.mq.add(uin,"Печкин: Пользователя [ID = " + uss.id +"] " + uss.localnick + " нет в чате, ваше сообщение было успешно сохранено, он(а) сможет прочесть его, когда войдет в чат.");
Log.talk("CHAT: " + uss.sn + ">> Личное сообщение от " + srv.us.getUser(uin).localnick + ": " + txt);
srv.us.db.log(uss.id,uin,"PM",">> Личное сообщение от " + srv.us.getUser(uin).localnick + ": " + txt,uss.room);
return;
}
if(txt.length()>psp.getIntProperty("chat.MaxMsgSize")){
txt = txt.substring(0,psp.getIntProperty("chat.MaxMsgSize"));
proc.mq.add(uin,"Ошибка: Слишком длинное сообщение было обрезано: " + txt);
}
Log.talk("CHAT: " + uss.sn + ">> Личное сообщение от " + srv.us.getUser(uin).localnick + ": " + txt);
srv.us.db.log(uss.id,uin,"PM",">> Личное сообщение от " + srv.us.getUser(uin).localnick + ": " + txt,uss.room);
srv.getIcqProcess(uss.basesn).mq.add(uss.sn,Messages.getString("ChatCommandProc.commandP.4") + srv.us.getUser(uin).localnick + "[ID="+ srv.us.getUser(uin).id + "]: " + txt);
String im = psp.getStringProperty("uin1");
srv.getIcqProcess(srv.us.getUser(im).basesn).mq.add(im,"Шпион: [ID=" + srv.us.getUser(uin).id + "]" + srv.us.getUser(uin).localnick + " (uin: " + srv.us.getUser(uin).sn + ") отправил личное сообщение пользователю " + uss.localnick + " [ID=" + uss.id + "]: " + txt);
setPM(uss.sn, uin);
proc.mq.add(uin,"Система: Сообщение отправлено");
}catch (Exception ex){
ex.printStackTrace();
Log.talk(uin + " Private msg error: " + tmsg);
proc.mq.add(uin,"Ошибка: Ошибка отправки сообщения");
}
}

/**
* +pp
* @param proc
* @param uin
* @param v
* @param tmsg
*/
public void commandPP(IcqProtocol proc, String uin, Vector v, String tmsg){
if(!isChat(proc,uin)) return;
if(!auth(proc,uin, "pmsg")) return;
try{
String txt = (String)v.get(0);
String fsn = testPM(uin);
if (psp.getBooleanProperty("filter.private.on")) txt = flt.mmsg (proc, txt, uin);
if(txt.equals("")) {
//                proc.mq.add(uin,"Сообщение отсутствует");
proc.mq.add(uin,Messages.getString("ChatCommandProc.commandP.0"));
return;
}
if(fsn.equals("")) {
//                proc.mq.add(uin,"Не найдено входящих сообщений, отправлять некому");
proc.mq.add(uin,Messages.getString("ChatCommandProc.commandPP.0"));
return;
}
Users uss = srv.us.getUser(fsn);
if(uss == null){
//                proc.mq.add(uin,"Такого пользователя не существует");
proc.mq.add(uin,Messages.getString("ChatCommandProc.commandP.1"));
return;
}
if(!srv.cq.testUser(uss.sn)){
srv.us.db.info(uss.id, "", "OFFLINE", srv.us.getUser(uin).id, "", txt);
// Сообщаем об успешном выполнении команды
proc.mq.add(uin,"Пользователя [id=" + uss.id +"] " + uss.localnick + " нет в чате, ваше сообщение было успешно сохранено, он(а) сможет прочесть его, когда войдет в чат.");
Log.talk("CHAT: " + uss.sn + ">> Личное сообщение от " + srv.us.getUser(uin).localnick + ": " + txt);
srv.us.db.log(uss.id,uin,"PM",">> Личное сообщение от " + srv.us.getUser(uin).localnick + ": " + txt,uss.room);
return;
}
if(txt.length()>psp.getIntProperty("chat.MaxMsgSize")){
txt = txt.substring(0,psp.getIntProperty("chat.MaxMsgSize"));
//                proc.mq.add(uin,"Слишком длинное сообщение было обрезано: " + txt);
proc.mq.add(uin,Messages.getString("ChatCommandProc.commandP.3") + txt);
}
Log.talk("CHAT: " + uss.sn + ">> Личное сообщение от " + srv.us.getUser(uin).localnick + ": " + txt);
srv.us.db.log(uss.id,uin,"PM",">> Личное сообщение от " + srv.us.getUser(uin).localnick + ": " + txt,uss.room);
srv.getIcqProcess(uss.basesn).mq.add(uss.sn, Messages.getString("ChatCommandProc.commandP.4") + srv.us.getUser(uin).localnick +
": " + txt);
setPM(uss.sn, uin);
String im = psp.getStringProperty("uin1");
srv.getIcqProcess(srv.us.getUser(im).basesn).mq.add(im,"Шпион: [ID=" + srv.us.getUser(uin).id + "]" + srv.us.getUser(uin).localnick + " (uin: " + srv.us.getUser(uin).sn + ") отправил личное сообщение пользователю " + uss.localnick + " [ID=" + uss.id + "]: " + txt);
//            proc.mq.add(uin,"Сообщение отправлено");
proc.mq.add(uin,Messages.getString("ChatCommandProc.commandP.5"));
} catch (Exception ex) {
ex.printStackTrace();
Log.talk(uin + " Private msg error: " + tmsg);
//            proc.mq.add(uin,"ошибка отправки сообщения");
proc.mq.add(uin,Messages.getString("ChatCommandProc.commandP.6"));
}
}


/**
* !settheme
* @param proc
* @param uin
* @param v
*/
public void commandSettheme(IcqProtocol proc, String uin, Vector v){
if(!auth(proc,uin, "settheme")) return;
String s = (String)v.get(0);
int room = srv.us.getUser(uin).room;
Rooms r = srv.us.getRoom(room);
r.setTopic(s);
srv.us.saveRoom(r, "");
Log.info("Установлена тема комнаты " + room + ": " + s);
srv.cq.addMsg("Система: Тема комнаты изменена на: " + s, "", room);
}

/**
* !getinfo
* @param proc
* @param uin
* @param v
*/
public void commandGetinfo(IcqProtocol proc, String uin, Vector v){
if(!isAdmin(proc, uin)) return;
try{
String s = (String)v.get(0);
s = srv.us.getUser(Integer.parseInt(s)).sn;
proc.mq.add(s, "", 1);
proc.mq.add(uin,"Запрос инфо UIN=" + s);
} catch (Exception ex){
ex.printStackTrace();
proc.mq.add(uin,"Запрос инфо неудачен");
}        
}

/**
* !room
* @param proc
* @param uin
* @param v
*/
public void commandRoom(IcqProtocol proc, String uin, Vector v){
if (!onlineAndAuthorized(proc, uin, "room")) return;
int i = (Integer)v.get(0);
String pass = (String)v.get(1);
Users uss = srv.us.getUser(uin);
if (uss.room==i) {
proc.mq.add(uin,"Система: Вы сейчас уже находитесь в этой комнате.");
return;
}
if (qauth(proc,uin, "anyroom") || srv.us.checkRoom(i)) {
if (!srv.us.getRoom(i).checkPass(pass) && !psp.testAdmin(uin)) {
proc.mq.add(uin,"Система: Неверный пароль.");
return;
}
if (uss.state==UserWork.STATE_CHAT) srv.cq.addMsg(uss.localnick + " учапал(а) в комнату (" + (Integer)v.get(0) + ").", uin, uss.room);
int oldRoom=uss.room;
uss.room=i;
srv.us.updateUser(uss);
srv.cq.changeUserRoom(uin, i);
if (uss.state==UserWork.STATE_CHAT) srv.cq.addMsg(uss.localnick + " причапал(а) из комнаты ("+oldRoom+").", uin, uss.room);
proc.mq.add(uin,"Вы перешли в комнату " + i + " - " + srv.us.getRoom(i).getName() +
(srv.us.getRoom(i).getTopic().equals("") ? "" : ("\r\nТема: " + srv.us.getRoom(i).getTopic())));
} else {
proc.mq.add(uin,"Система: Такой комнаты не существует.");
}
}

/**
* !whoinvite
* @param proc
* @param uin
* @param v
*/
public void commandWhoinvite(IcqProtocol proc, String uin, Vector v) {
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "whoinv")) return;
try {
int i = (Integer)v.get(0);
proc.mq.add(uin,srv.us.getUserInvites(i));
} catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin,ex.getMessage());            
}
}

/**
* !kickhist
* @param proc
* @param uin
*/
public void commandKickhist(IcqProtocol proc, String uin) {
if(!auth(proc,uin, "kickhist")) return;
try {
proc.mq.add(uin,srv.us.getKickHist());
} catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin,ex.getMessage());            
}
}
/**
* !админу
* @param proc
* @param uin
*/
public void commandAdm(IcqProtocol proc, String uin, Vector v) {
try {
Users uss = srv.us.getUser(uin);
OutputStreamWriter ow = new OutputStreamWriter(new FileOutputStream("./services/" + srv.getName() + "/text/AgmuHy.txt", true), "windows-1251");
String s = "[" + new Timestamp(System.currentTimeMillis()) + "] [" + uss.localnick + "][" + uss.id + "]-[" + uin + "]: " + (String) v.get(0) + "n";
ow.write(s);
ow.close();
if (psp.getBooleanProperty("chat.lichnoe.admin.on.off")) {
String k = psp.getStringProperty("chat.lichnoe.admin");
String[] kk = k.split(";");
for (int i = 0; i < kk.length; i++) {
Users usss = srv.us.getUser(kk[i]);
srv.getIcqProcess(usss.basesn).mq.add(usss.sn, "Админ сообщение от " + uss.localnick + "[" + uss.id + "]-[" + uin + "]: " + (String) v.get(0));
}
}
Log.talk("Админ сообщение от " + uss.localnick + "[" + uss.id + "]-[" + uin + "]: " + (String) v.get(0));
proc.mq.add(uin, "Система: Сообщение сохранено");
} catch (Exception ex) {
ex.printStackTrace();
Log.talk("Error save msg: " + ex.getMessage());
proc.mq.add(uin, "Система: Ошибка добавления");
}
}

/**
* !banhist
* @param proc
* @param uin
*/
public void commandBanhist(IcqProtocol proc, String uin) {
if(!auth(proc,uin, "ban")) return;
try {
proc.mq.add(uin,srv.us.getBanHist());
} catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin,ex.getMessage());            
}
}

/**
* !lroom - Выводит список зарегистрированных комнат
* @param proc
* @param uin
*/
public void commandLRoom(IcqProtocol proc, String uin) {
if (!onlineAndAuthorized(proc, uin, null)) return;
String s = "Список комнат в чате:\r\n";
Set<Integer> rid = srv.us.getRooms();
Integer[] rooms=(Integer[])rid.toArray(new Integer[0]);
Arrays.sort(rooms);
for (Integer i:rooms) {
int cnt=0;
Enumeration<String> e = srv.cq.uq.keys();
while (e.hasMoreElements()) {
String g = e.nextElement();
Users us = srv.us.getUser(g);
if(us.state==UserWork.STATE_CHAT && us.room==i) cnt++;
}
s += i + " - " + srv.us.getRoom(i).getName() + " (" + cnt + " чел.)\r\n";
}
proc.mq.add(uin,s);
}


/**
* !crroom - Создание новой комнаты
* @param proc
* @param uin
* @param v
*/
public void commandCrRoom(IcqProtocol proc, String uin, Vector v){
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "wroom")) return;
Users uss = this.srv.us.getUser(uin);
int room = (Integer)v.get(0);
String s = (String)v.get(1);
if(srv.us.checkRoom(room)){
proc.mq.add(uin,"Система: Такая комната уже существует.");
return;
}
Rooms r = new Rooms();
r.setId(room);
r.setName(s);
srv.us.createRoom(r);
srv.cq.addMsg("Система: Была создана комната " + this.srv.us.getRoom(room).getName() + " (" + room + ") пользователем " + uss.localnick + " [ID=" + uss.id + "]", uin, uss.room);
srv.cq.addMsg("Система: Была создана комната " + this.srv.us.getRoom(room).getName() + " (" + room + ") пользователем " + uss.localnick + " [ID=" + uss.id + "]", uin, 0);
proc.mq.add(uin,"Система: Комната (" + room + ") успешно создана.");
}

/**
* !chroom - Изменение названия комнаты
* @param proc
* @param uin
* @param v
*/
public void commandChRoom(IcqProtocol proc, String uin, Vector v){
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "wroom")) return;
int room = (Integer)v.get(0);
String s = (String)v.get(1);
if(!srv.us.checkRoom(room)){
proc.mq.add(uin,"Система: Такой комнаты не существует.");
return;
}
Rooms r = srv.us.getRoom(room);
r.setName(s);
srv.us.saveRoom(r,"");   
proc.mq.add(uin,"Система: Комната (" + room + ") успешно изменена.");
}
/**
* !охрана - Покупка охраны
* @param proc
* @param uin
* @param v
*/
public void commandoxpana(IcqProtocol proc, String uin, Vector v){
if (!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if (!auth(proc,uin, "oxpana")) return;
String dol = (String)v.get(0); // набранная должность
Users uss = srv.us.getUser(uin);
if(uss.room!=17)
{
proc.mq.add(uin,"Система: Охрана нанимается в (17) комнате - " + srv.us.getRoom(17).getName() + "");
return;
}
if(dol.equals("1"))
{
if(uss.zoloto < 100)
{
proc.mq.add(uin,"Система: Ваш Баланс: (" + uss.zoloto + ") золотых, на какие шиши ты купишь охрану:-D");
return;
}
int gold = uss.zoloto-100;
uss.zoloto=gold;
uss.hpoxp=100;
uss.nazoxp= "Амбал";
proc.mq.add(uin,"Охранник: Ты купил в охрану Амбала, с тебя (100) золотых.");
srv.cq.addMsg("Охранник: " + uss.localnick+ " нанял в охрану Амбала(100). ", uss.sn, uss.room);
}
else if(dol.equals("2"))
{
if(uss.zoloto < 1000)
{
proc.mq.add(uin,"Система: Ваш Баланс: (" + uss.zoloto + ") золотых, на какие шиши ты купишь охрану:-D");
return;
}
int gold = uss.zoloto-1000;
uss.zoloto=gold;
uss.hpoxp=1000;
uss.nazoxp= "Мент";
proc.mq.add(uin,"Охранник: Ты купил в охрану Мента, с тебя (1000) золотых.");
srv.cq.addMsg("Охранник: " + uss.localnick+ " нанял в охрану Мента(1000). ", uss.sn, uss.room);
}
else if(dol.equals("3"))
{
if(uss.zoloto < 10000)
{
proc.mq.add(uin,"Система: Ваш Баланс: (" + uss.zoloto + ") золотых, на какие шиши ты купишь охрану:-D");
return;
}
int gold = uss.zoloto-10000;
uss.zoloto=gold;
uss.hpoxp=10000;
uss.nazoxp= "Спецназовец";
proc.mq.add(uin,"Охранник: Ты купил в охрану Спецназовца, с тебя (10000) золотых.");
srv.cq.addMsg("Охранник: " + uss.localnick+ " нанял в охрану Спецназовца(10000). ", uss.sn, uss.room);
}
else if(dol.equals("4"))
{
if(uss.zoloto < 100000)
{
proc.mq.add(uin,"Система: Ваш Баланс: (" + uss.zoloto + ") золотых, на какие шиши ты купишь охрану:-D");
return;
}
int gold = uss.zoloto-100000;
uss.zoloto=gold;
uss.hpoxp=100000;
uss.nazoxp= "Шайка гопоты";
proc.mq.add(uin,"Охранник: Ты купил в охрану Шайку гопоты, с тебя (100000) золотых.");
srv.cq.addMsg("Охранник: " + uss.localnick+ " нанял в охрану Шайку гопоты(100000). ", uss.sn, uss.room);
}
else
{
proc.mq.add(uin,"-=ОХРАНА=-\n--------\n(1) Амбал - здоровье (100), цена 100. \n(2) Мент - здоровье (1000), цена 1000.\n(3) Спецназовец - здоровье (10000), цена 10000.\n(4) Шайка гопоты - здоровье (100000), цена 100000.");
}
}


/**
* Игра казино
* @param proc
* @param uin
*/
public void commandCasino(IcqProtocol proc, String uin, Vector v){
if (!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if (!auth(proc,uin, "casino")) return;
int win2;
Users uss = srv.us.getUser(uin);
if(uss.room!=12)
{
proc.mq.add(uin,"Система: Игровая в (12) комнате - " + srv.us.getRoom(12).getName() + "");
return;
}
long t = System.currentTimeMillis();
if (t-uss.gametime<30000) {
proc.mq.add(uin,"Система: Пауза между запросами 30 сек...");
return;
}
if (uss.zoloto < 10) {
proc.mq.add(uin, "Бандит: У тебя даже хватает на минимальную ставку:-D");
return;
}
int number1 = (int)(Math.random() * 10);
int number2 = (int)(Math.random() * 10);
int number3 = (int)(Math.random() * 10);
int payment = uss.zoloto - 50;
srv.cq.addMsg("Бандит: " + uss.localnick + " потянул рычаг... Табло вращается... Вращается... Вращается... И выпадает комбинация  -="+number1+"="+number2+"="+number3+"=-", uss.sn, uss.room);
proc.mq.add(uin,"Бандит: Вы потянули рычаг... И выпадает комбинация  -="+number1+"="+number2+"="+number3+"=-");
uss.gametime=t;
srv.us.updateUser(uss);
if ((number1 != number2) && (number1 != number3) && (number2 != number3)) {
uss.zoloto = payment;
srv.cq.addMsg("Бандит: Ни одного совподения..."+uss.localnick+" - неудачник!!!", uss.sn, uss.room);
proc.mq.add(uin,"Бандит: Ни одного совподения... Возможно в следующий раз повезет. За игру у Вас снято: (20) золотых. ");
}
if ((number1 == number2) && (number3 != number2)) {
win2 = payment + 100;
uss.zoloto = win2;
srv.cq.addMsg("Бандит: Два числа совпали... И "+uss.localnick+" выигрывает: (100) золотых. ", uss.sn, uss.room);
proc.mq.add(uin,"Бандит: Два числа совпали... Вы выиграли (100) золотых. За игру у Вас снято: (20) золотых.");
}
if ((number2 == number3) && (number1 != number2)) {
win2 = payment + 100;
uss.zoloto = win2;
srv.cq.addMsg("Бандит: Два числа совпали... И "+uss.localnick+" выигрывает: (100) золотых. ", uss.sn, uss.room);
proc.mq.add(uin,"Бандит: Два числа совпали... Вы выиграли (100) золотых. За игру у Вас снято: (20) золотых.");
}
if ((number1 == number3) && (number1 != number2)) {
win2 = payment + 100;
uss.zoloto = win2;
srv.cq.addMsg("Бандит: Два числа совпали... И "+uss.localnick+" выигрывает: (100) золотых. ", uss.sn, uss.room);
proc.mq.add(uin,"Бандит: Два числа совпали... Вы выиграли (100) золотых. За игру у Вас снято: (20) золотых.");
}
if ((number1 == number2) && (number3 == number2)) {
int win3 = payment + 600;
uss.zoloto = win3;
srv.cq.addMsg("Бандит: Все 3 числа совпали... И "+uss.localnick+" выигрывает: (600) золотых... Какой везунчик!!!", uss.sn, uss.room);
proc.mq.add(uin,"Бандит: Все 3 числа совпали... Вы выиграли: (600) золотых. За игру у Вас снято: (20) золотых.");
}
uss.basesn = proc.baseUin;
srv.us.updateUser(uss);
}
/**
* Рулетка
* @param proc
* @param uin
* @param v
* @param mmsg
*/
public void commandRyletka(IcqProtocol proc, String uin, Vector v) {
if (!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if (!auth(proc,uin, "Ryletka")) return;
try {
int s = (Integer) v.get(0); // набранное число
int numb = (int) ((Math.random() * 19)); // случаиное время кика от 0 до 10
int num = (int) ((Math.random() * 6)); // случаиное число от 0 до 3
Users uss = srv.us.getUser(uin);
if (uss.room != 12) // номер комнаты для игры
{
proc.mq.add(uin,"Система: Игровая в (12) комнате - " + srv.us.getRoom(12).getName() + ""); // оповещение где играть
return;
}
long t = System.currentTimeMillis();
if (t-uss.gametime<30000) {
proc.mq.add(uin,"Система: Пауза между запросами 30 сек...");
return;
}
int moder_id = 0; // ид модера
String r = " проиграл(а) в рулетку"; // причина
if (s > 6) {
proc.mq.add(uin, "Система: Число должно быть от 1 до 6");
return;
}
//     srv.cq.addMsg("Русская рулетка: я загадала число: (" + num + ") , а " + uss.localnick + "|" + uss.id + "|" + " набрал: (" + s + ")", "", uss.room);
if (s == num) {
srv.cq.addMsg("Система: " + uss.localnick + " дрожащеи рукой крутит барабан револьвера.\nСистема: единственный патрон оказался в стволе,выстрел... " + uss.localnick + ", падает замертво...", "", uss.room);
proc.mq.add(uin, "Система: Единственный патрон оказался в барабане, и он тебе попался.");
// оповещаем....удаляем
proc.mq.add(uin, "Вы были выпнуты из чата на " + numb + " минут. Причина: ты проиграл(а) в рулетку!");
tkick(proc, uin, numb, moder_id, r);
} else {
int gold = uss.zoloto+5;
uss.zoloto=gold;
uss.gametime=t;
srv.us.updateUser(uss);
proc.mq.add(uin,"Система: а ты везунчик ! ты выиграл(а) 5 золотых,твои баланс = " + uss.zoloto + "");
srv.cq.addMsg("Система:" + uss.localnick + " дрожащей рукой крутит барабан револьвера.\nСистема: щелчок...,стирая холодный пот со лба " + uss.localnick + " забирает свои кровные 5 золотых!", "", uss.room);
}
} catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin, "Ошибка " + ex.getMessage());
}
}

/**
* Покупака должности
* @param proc
* @param uin
* @param v
* @param mmsg
*/
public void commandDoljnost(IcqProtocol proc, String uin, Vector v) {
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "doljnost")) return;

try{
String d = "";
String dol = (String)v.get(0);
Users uss = srv.us.getUser(uin);
if(uss.room!=7)
{
proc.mq.add(uin,"Система: Магазин в (7) комнате - " + srv.us.getRoom(7).getName() + "");
return;
}
if(dol.equals("1"))
{
if(uss.zoloto < 5000)
{
proc.mq.add(uin,"Система: Ваш баланс (" + uss.zoloto + ") золотых, у вас недостаточно средств для покупки.");
return;
}
if(uss.prestypnost < 5)
{
proc.mq.add(uin,"Система: У вас должно быть <5 очков преступонсти и <10 очков авторитет(a).");
return;
}
if(uss.avtopitet < 10)
{
proc.mq.add(uin,"Система: У вас должно быть <5 очков преступонсти и <10 очков авторитет(а).");
return;
}
if(!testUserGroup("vip"))
{
proc.mq.add(uin,"Лавочник: Скажи внятно:)");
return;
}
uss.group = "vip";
boolean f = srv.us.setUserPropsValue(uss.id, "group", "vip") &&
srv.us.setUserPropsValue(uss.id, "grant", "") &&
srv.us.setUserPropsValue(uss.id, "revoke", "");
srv.us.clearCashAuth(uss.id);
int gold = uss.zoloto-5000;
uss.zoloto=gold;
proc.mq.add(uin,"Лавочник: Покупка успешно завершена, ваш баланс: (" + uss.zoloto + ") золотых.");
srv.cq.addMsg("Лавочник: [" + uss.id + "]" + uss.localnick + " купил(а) должность: [Вип]", uss.sn, uss.room);
}
else if(dol.equals("2"))
{
if(uss.zoloto < 7000)
{
proc.mq.add(uin,"Система: Ваш баланс (" + uss.zoloto + ") золотых, у вас недостаточно средств для покупки.");
return;
}
if(uss.prestypnost < 10)
{
proc.mq.add(uin,"Система: У вас должно быть <10 очков преступонсти и <25 очков авторитет(a).");
return;
}
if(uss.avtopitet < 25)
{
proc.mq.add(uin,"Система: У вас должно быть <10 очков преступонсти и <25 очков авторитет(а).");
return;
}
if(!testUserGroup("killer"))
{
proc.mq.add(uin,"Лавочник: Скажи внятно:)");
return;
}
uss.group = "killer";
boolean f = srv.us.setUserPropsValue(uss.id, "group", "killer") &&
srv.us.setUserPropsValue(uss.id, "grant", "") &&
srv.us.setUserPropsValue(uss.id, "revoke", "");
srv.us.clearCashAuth(uss.id);
int gold = uss.zoloto-7000;
uss.zoloto=gold;
proc.mq.add(uin,"Лавочник: Покупка успешно завершена, ваш баланс: (" + uss.zoloto + ") золотых.");
srv.cq.addMsg("Лавочник: [" + uss.id + "]" + uss.localnick + " купил(а) должность: [Киллер]", uss.sn, uss.room);
}
else if(dol.equals("3"))
{
if(uss.zoloto < 20000)
{
proc.mq.add(uin,"Система: Ваш баланс (" + uss.zoloto + ") золотых, у вас недостаточно средств для покупки.");
return;
}
if(uss.prestypnost < 30)
{
proc.mq.add(uin,"Система: У вас должно быть <30 очков преступонсти и <50 очков авторитет(a).");
return;
}
if(uss.avtopitet < 50)
{
proc.mq.add(uin,"Система: У вас должно быть <30 очков преступонсти и <50 очков авторитет(а).");
return;
}
if(!testUserGroup("moder"))
{
proc.mq.add(uin,"Лавочник: Скажи внятно:)");
return;
}
uss.group = "moder";
boolean f = srv.us.setUserPropsValue(uss.id, "group", "moder") &&
srv.us.setUserPropsValue(uss.id, "grant", "") &&
srv.us.setUserPropsValue(uss.id, "revoke", "");
srv.us.clearCashAuth(uss.id);
int gold = uss.zoloto-20000;
uss.zoloto=gold;
proc.mq.add(uin,"Лавочник: Покупка успешно завершена, ваш баланс: " + uss.zoloto + " золотых.");
srv.cq.addMsg("Лавчоник: [" + uss.id + "]" + uss.localnick + " купил(а) должность: [модер]", uss.sn, uss.room);
}
else if(dol.equals("4"))
{
if(uss.zoloto < 35000)
{
proc.mq.add(uin,"Система: Ваш баланс (" + uss.zoloto + ") золотых, у вас недостаточно средств для покупки.");
return;
}
if(uss.prestypnost < 60)
{
proc.mq.add(uin,"Система: У вас должно быть <60 очков преступонсти и <120 очков авторитет(a).");
return;
}
if(uss.avtopitet < 120)
{
proc.mq.add(uin,"Система: У вас должно быть <60 очков преступонсти и <120 очков авторитет(а).");
return;
}
if(!testUserGroup("admin"))
{
proc.mq.add(uin,"Лавочник: Скажи внятно:)");
return;
}
uss.group = "admin";
boolean f = srv.us.setUserPropsValue(uss.id, "group", "admin") &&
srv.us.setUserPropsValue(uss.id, "grant", "") &&
srv.us.setUserPropsValue(uss.id, "revoke", "");
srv.us.clearCashAuth(uss.id);
int gold = uss.zoloto-35000;
uss.zoloto=gold;
proc.mq.add(uin,"Лавочник: Покупка успешно завершена, ваш баланс: (" + uss.zoloto + ") золотых.");
srv.cq.addMsg("Лавчоник: [" + uss.id + "]" + uss.localnick + " купил(а) должность: [Админ]", uss.sn, uss.room);
}
else
{
proc.mq.add(uin,"-=ДОЛЖНОСТЬ=-\n(1) - [Вип] - (5000) золотых.\n(2) - [Киллер] - (7000) золотых\n(3) - [Модер] - (20000) золотых\n(4) - [Админ] - (35000) золотых");
}

} catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin,"Ошибка "+ex.getMessage());
}
}

/**
* Рация
* @param proc
* @param uin
* @param v
* @param tmsg
*/
public void commandOpChat(IcqProtocol proc, String uin, Vector v) {
if (!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if (!auth(proc,uin, "racia")) return;
String smsg = (String)v.get(0);
if ((smsg.equals("")) || (smsg.equals(" "))) return;
Enumeration e = srv.cq.uq.keys();
while (e.hasMoreElements()) {
String i = (String)e.nextElement();
Users us = srv.us.getUser(i);
if (srv.us.authorityCheck(i, "racia")){
srv.getIcqProcess(us.basesn).mq.add(us.sn, "Оператор: " + srv.us.getUser(uin).localnick + "[ID = " + us.id + "]: " + smsg);
}
}
}

public void commandOFFMail(IcqProtocol proc, String uin, Vector v) {
// Проверим полномочия
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "OFF")) return;

try{
Users us = srv.us.getUser(uin);
// Проверка по базе есть ли они вообще
if((srv.us.CountPM(us.id)==0)){
proc.mq.add(uin,"Печкин: У вас нет непрочитанных сообщений");
return;
}
String s = "Сообщения оставленные вам:\n";
try {
PreparedStatement pst = (com.mysql.jdbc.PreparedStatement)srv.us.db.getDb().prepareStatement("SELECT user_id2, msg, time FROM info where user_id=" + us.id + " and type='OFFLINE'");
ResultSet rs = pst.executeQuery();
if(rs.next()){
s += "[ID=" + srv.us.getUser(rs.getInt(1)).id + "] "+ srv.us.getUser(rs.getInt(1)).localnick + " (" + rs.getTimestamp(3) + ") \n" + rs.getString(2) + '\n';
}
rs.close();
pst.close();
} catch (Exception ex) {
ex.printStackTrace();
}



// Сообщаем об успешном выполнении команды
proc.mq.add(uin,s);
try {
PreparedStatement pst1 = (com.mysql.jdbc.PreparedStatement)srv.us.db.getDb().prepareStatement("delete from `info` where user_id=" + us.id + " and type='OFFLINE'");
pst1.execute();
pst1.close();
} catch (Exception ex) {
ex.printStackTrace();
}
} catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin,"Ошибка "+ex.getMessage());
}
}


/**
* Отправка сообщений забаненым и кикнутым юзерам происходит изредка
*/
private void infrequentSend(IcqProtocol proc, String uin, String msg){
if(radm.testRnd(20))
proc.mq.add(uin, msg);
}

/**
* отправка сообщения во все комнаты
*  
*/
public void commandSend(IcqProtocol proc, String uin, Vector v) {
if (!isChat(proc, uin) && !psp.testAdmin(uin)) return;
if (!auth(proc, uin, "allroom_mesage")) return;
try {
String smsg = (String) v.get(0);
if (smsg.equals("") || smsg.equals(" ")) {
return;
}
Set<Integer> rid = new HashSet();
Enumeration<String> e = srv.cq.uq.keys();
while (e.hasMoreElements()) {
String i = e.nextElement();
Users us = srv.us.getUser(i);
if (us.state == UserWork.STATE_CHAT) {
rid.add(us.room);
}
}
for (int i : rid) {
//если SYSTEM MESSAGE не устраивает- меняем на свое.
srv.cq.addMsg("\nОБЪЯВЛЕНИЕ: " + smsg + "\n", uin, i);
}
proc.mq.add(uin, "Система: Сообщение отправленно*YES*");
} catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin, "Ошибка " + ex.getMessage());
}
}

/**
* отправка сообщения во все комнаты
* 
*/
public void commandBanroom(IcqProtocol proc, String uin, Vector v) {
if (!isChat(proc, uin) && !psp.testAdmin(uin)) return;
if (!auth(proc, uin, "banroom")) return;
try{
//Согласно шаблону, оба аргумента должны быть числами
int i1 = (Integer)v.get(0);
int i2 = (Integer)v.get(1);
// Находим юзера
Users u = srv.us.getUser(i1);
// Проверяем есть ли такой юзер ваще?
if(u.id==0){
proc.mq.add(uin,"Система: Пользователь не найден");
return;
}
if(u.state!=UserWork.STATE_CHAT){
proc.mq.add(uin,"Система: Этого пользователя нет в чате.");
return;
}
// Переводим в комнату
if(u.room==i2){
proc.mq.add(uin,"Система: Пользователь уже сидит в этой комнате");
return;
} else {
u.room=i2;
srv.us.updateUser(u);
srv.cq.changeUserRoom(u.sn, i2);
// Оповещаем целевую комнату
srv.cq.addMsg("Система: " + u.localnick + " заперт в комнате " + u.room, u.sn, u.room);
// Оповещаем юзера
srv.getIcqProcess(u.basesn).mq.add(u.sn,"Система: Ты заперт в комнате " + i2);
// Лишаем юзера прав на комнаты
srv.us.revokeUser(i1, "room");
}
// Сообщаем об успешном выполнении команды
proc.mq.add(uin,"Система: Пользователь " + u.localnick + " успешно заперт в комнате " + i2);
} catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin,"Ошибка "+ex.getMessage());
}
}


/**
* предложить на бракосочетание
*
*/
public void commandPredlozhit(IcqProtocol proc, String uin, Vector v) {
int id = (Integer)v.get(0);
Users uss = srv.us.getUser(uin);  //Парень
Users u = srv.us.getUser(id);  //Девушка
if (uss.room!=10)
{
proc.mq.add(uin,"Система: Загс в (10) комнате - " + srv.us.getRoom(10).getName());
return;
}
if (u.id==0) {
proc.mq.add(uin, "Ошибка: такого пользователя не существует.");
return;
}
if (u.state!=UserWork.STATE_CHAT){
proc.mq.add(uin,"Система: Этого пользователя нет в чате.");
return;
}
if (u.room!=10)
{
proc.mq.add(uin,"Система: Девушка тоже должна быть в (10) комнате");
return;
}
if (u.birthmonth > 0) {
proc.mq.add(uin, "Священник: Она уже замужем  .");
return;
}
if (u.birthmonth < 0) {
proc.mq.add(uin, "Священник: Ей уже предложили выйти замуж.");
return;
}
if (uss.id==id) {
proc.mq.add(uin, "Священник: Женишься на самом себе?! Ну ты псих.");
return;
}
Users user=null;
if (uss.birthmonth>0) {
user = srv.us.getUser(uss.birthmonth);
if (user.id!=0 && user.birthmonth==uss.id) {
proc.mq.add(uin, "Священник: Ты уже женат! ");
return;
}
if (user.id==0) user=null;
else if (user.birthmonth!=-uss.id) user=null;
}
uss.birthmonth = id;
u.birthmonth = -uss.id;
if (user!=null) {
user.birthmonth = 0;
srv.us.updateUser(user);
}
srv.us.updateUser(u);
srv.us.updateUser(uss);
proc.mq.add(uin, "Священик: Ты предложил пользователю [ID="+id+"] "+u.localnick+" выйти за тебя замуж!");
srv.getIcqProcess(u.basesn).mq.add(u.sn, "Священик: Пользователь ["+uss.id+"] "+uss.localnick+" хочет жениться на тебе! Напиши команду !согласна или !отказать");
srv.cq.addMsg("Система: Пользователь [ID="+uss.id+"] "+uss.localnick+" предложил пользователю [ID="+id+"] "+u.localnick+" выйти за него замуж!\nСвященик: Кажеться намечаеться свадьба!!! Бегом в 10 комнату!!! Бухать!!!", uin, uss.room);
}

/**
* сменить оружие
*
*/
public void commandArsenal(IcqProtocol proc, String uin, Vector v) {
try{
String dol = (String)v.get(0);
Users uss = srv.us.getUser(uin);
if(dol.equals("1"))
{
uss.nazorujie= "Огнемет";
srv.us.updateUser(uss);
proc.mq.add(uin,"Лавочник: Вы сменили оружие на Огнемет.");
}
else if(dol.equals("2"))
{
uss.nazorujie= "Ледомет";
srv.us.updateUser(uss);
proc.mq.add(uin,"Лавочник: Вы сменили оружие на Ледомет.");
}
else if(dol.equals("3"))
{
uss.nazorujie= "Заморозка";
srv.us.updateUser(uss);
proc.mq.add(uin,"Лавочник: Вы сменили оружие на Заморозка.");
}
else
{
proc.mq.add(uin,"-=АРСЕНАЛ=-\n(1) - Огнемет.\n(2) - Ледомет.\n(3) - Заморозка.");
}
} catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin,"Ошибка "+ex.getMessage());
}
}

/**
* сменить защиту
*
*/
public void commandSchit(IcqProtocol proc, String uin, Vector v) {
try{
String dol = (String)v.get(0);
Users uss = srv.us.getUser(uin);
if(dol.equals("1"))
{
uss.nazzachita= "Огненый щит";
srv.us.updateUser(uss);
proc.mq.add(uin,"Лавочник: Вы сменили щит на Огненый щит.");
}
else if(dol.equals("2"))
{
uss.nazzachita= "Ледяной щит";
srv.us.updateUser(uss);
proc.mq.add(uin,"Лавочник: Вы сменили щит на Ледяной щит.");
}
else if(dol.equals("3"))
{
uss.nazzachita= "Стальной щит";
srv.us.updateUser(uss);
proc.mq.add(uin,"Лавочник: Вы сменили щит на Стальной щит.");
}
else
{
proc.mq.add(uin,"-=ЩИТ=-\n(1) - Огненый щит.\n(2) - Ледяной щит.\n(3) - Стальной щит.");
}
} catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin,"Ошибка "+ex.getMessage());
}
}

/**
* покупка оружия
*
*/
public void commandOryjie(IcqProtocol proc, String uin, Vector v) {
if (!isChat(proc, uin) && !psp.testAdmin(uin)) return;
if (!auth(proc, uin, "orujie")) return;
Users user=srv.us.getUser(uin);
int amount=(Integer)v.get(0);
if (amount<=0) {
proc.mq.add(uin, "Ошибка: Неверное количество оружия, оно должно быть положительным.");
return;
}
if(user.room!=7)
{
proc.mq.add(uin,"Система: Магазин в (7) комнате - " + srv.us.getRoom(7).getName() + "");
return;
}
int cost=amount*250;
if (user.zoloto<cost) {
proc.mq.add(uin, "Лавочник: У Вас недостаточно золотых для покупки. Нужно "+cost+", а у Вас "+user.zoloto+".");
return;
}
user.zoloto-=cost;
user.orujie+=amount;
srv.us.updateUser(user);
proc.mq.add(uin,"Лавочник: Вы купили ("+amount+") оружия, для "+user.nazorujie+".");
srv.cq.addMsg("Лавчоник: [" + user.id + "]" + user.localnick + " купил(а) ("+amount+") для "+user.nazorujie+". ", user.sn, user.room);
}

/**
* покупка защиты
*
*/
public void commandZachita(IcqProtocol proc, String uin, Vector v) {
if (!isChat(proc, uin) && !psp.testAdmin(uin)) return;
if (!auth(proc, uin, "zach")) return;
Users user=srv.us.getUser(uin);
int amount=(Integer)v.get(0);
if(user.room!=7)
{
proc.mq.add(uin,"Система: Магазин в (7) комнате - " + srv.us.getRoom(7).getName() + "");
return;
}
if (amount<=0) {
proc.mq.add(uin, "Ошибка: Неверное количество защиты, оно должно быть положительным.");
return;
}
int cost=amount*250;
if (user.zoloto<cost) {
proc.mq.add(uin, "Лавочник: У Вас недостаточно золотых для покупки. Нужно "+cost+", а у Вас "+user.zoloto+".");
return;
}
user.zoloto-=cost;
user.zachita+=amount;
srv.us.updateUser(user);
proc.mq.add(uin,"Лавочник: Вы купили ("+amount+") защиты, для "+user.nazzachita+".");
srv.cq.addMsg("Лавчоник: [" + user.id + "]" + user.localnick + " купил(а) ("+amount+") для "+user.nazzachita+". ", user.sn, user.room);
}
/**
* выжегание охраны
*
*/
public void commandFire(IcqProtocol proc, String uin, Vector v) {
int s = (Integer)v.get(0);
Users us = srv.us.getUser(s);
Users uss = srv.us.getUser(uin);
if(uss.room!=12 && uss.room!=5 && uss.room!=7)
{
proc.mq.add(uin,"Система: Игровая в (12) комнате - " + srv.us.getRoom(12).getName() + "");
return;
}
long t = System.currentTimeMillis();
if (t-uss.gametime<30000) {
proc.mq.add(uin,"Система: Выжигать охрану можно 1 раз в 30 сек...");
return;
}
if(us.id==0)
{
proc.mq.add(uin,"Ошибка: Такой пользователь ещё не зарегистрировался в чате.");
return;
}
if(us.room!=uss.room)
{
proc.mq.add(uin,"Система: Ты должен быть в одной комнате с тем, на кого нападаешь.");
return;
}
if(!uss.nazorujie.equals("Огнемет"))
{
proc.mq.add(uin,"Система: У тебя " + uss.nazorujie + ", а надо чтоб был Огнемет");
return;
}
if(us.state!=UserWork.STATE_CHAT)
{
proc.mq.add(uin,"Система: Этого пользователя нет в чате.");
return;
}
if(us.zoloto < 500)
{
proc.mq.add(uin,"Система: У [" + us.id + "]" + us.localnick + " нет золотых,что ж ты делаешь? Эх...");
return;
}
if (uss.orujie<=0) {
proc.mq.add(uin,"Ошибка: У Вас нет оружия! Купите его с помощью команды !оружие");
return;
}
if (us.hpoxp==0) {
proc.mq.add(uin,"Система: Что ты собираешься выжигать, травку!?");
return;
}
uss.orujie--;
srv.us.updateUser(uss);
if (us.nazzachita.equals("Ледяной щит") && us.zachita>0) {
us.zachita--;
srv.us.updateUser(us);
srv.getIcqProcess(us.basesn).mq.add(us.sn,"Система: Вам пытались выжечь охрану, но Вас спас Ледяной щит, у вас осталось: (" + us.zachita + ").");
proc.mq.add(uin,"Система: У [ID="+us.id+"] "+us.localnick+" есть Ледяной щит. Нападение не удалось!");
return;
}
us.hpoxp-=500;
if (us.hpoxp<0) us.hpoxp=0;
srv.us.updateUser(us);
uss.gametime=t;
srv.us.updateUser(uss);
srv.getIcqProcess(us.basesn).mq.add(us.sn,"Система: Вам выжег охрану: [ID=" + uss.id + "]" + uss.localnick + ", здоровье охраны: (" + us.hpoxp + ")");
proc.mq.add(uin,"Система: Вы выжгли охрану: [ID=" + us.id + "]" + us.localnick + ", здоровье его(ее) охраны: (" + us.hpoxp + ")");
}
/**
* !Butilochka
* @param proc
* @param uin
*/
public void commandbutilochka(IcqProtocol proc, String uin){
if (!onlineAndAuthorized(proc, uin, "Butilochka")) return;
Vector<Users> users=new Vector();
Users uss = srv.us.getUser(uin);
if(uss.room!=12)
{
proc.mq.add(uin,"Система: Игровая в (12) комнате - " + srv.us.getRoom(12).getName() + "");
return;
}
long t = System.currentTimeMillis();
if (t-uss.gametime<30000) {
proc.mq.add(uin,"Система: Крутить бутылочку можно 1 раз в 30 сек...");
return;
}
Enumeration e = srv.cq.uq.keys();
while (e.hasMoreElements()) {
String i = (String) e.nextElement();
Users us = srv.us.getUser(i);
if ((us.state==UserWork.STATE_CHAT)&&(us.room==uss.room)&&(us.id!=0))
users.add(us);
}
if (users.isEmpty()) {
proc.mq.add(uin,"Система: В комнате нет пользователей.");
return;
}
int k = r.nextInt(users.size());
String s = psp.loadText(psp.getTextDirectory()+"butilochka.txt");
String[] ss = s.split("<end>");
int R = r.nextInt(ss.length);
Users u = users.get(k);
// Оповещаем чат
srv.cq.addMsg("Система: " + uss.localnick + " вертит бутылочку. Бутылочка крутится.... крутится... и указывает на.... указывает на " + u.localnick+ " [ID=" +u.id+ "]", uss.sn, uss.room);
srv.cq.addMsg("Система: Теперь " + uss.localnick + " должен(должна) " +ss[R] +" "+ u.localnick+ " [ID=" +u.id+ "]", uss.sn, uss.room);
proc.mq.add(uin,"Система: ты должен(должна) "+ss[R] +" "+ u.localnick+ " [ID=" +u.id+ "]");
uss.gametime=t;
srv.us.updateUser(uss);
}
/**
* фразы в бутылку:)
*
*/
public void commandcbut(IcqProtocol proc, String uin, List v) throws Exception {
if (!onlineAndAuthorized(proc, uin, "addbutilochka")) return;
String text = (String)v.get(0);
Users uss = srv.us.getUser(uin);
if (uss.room!=12) {
proc.mq.add(uin,"Фразы можно добавлять только в комнате, где проходит сама игра.");
return;
}
if (text.equals("")) {
proc.mq.add(uin,"Система: Вы не указали фразу...");
return;
}
//Указываем файл с фразами.
String directory=psp.getTextDirectory();
File dir=new File(directory);
dir.mkdirs();
dir=null;
OutputStreamWriter ow = new OutputStreamWriter(new FileOutputStream(directory+"butilochka.txt",true),"windows-1251");
ow.write(text+"<end>");
ow.close();
//Оповещаем чат.
srv.cq.addMsg("Система: " + uss.localnick + "[ID=" + uss.id + "] добавил фразу " + text + " в игру бутылочка", uin, uss.room);
//Оповещаем об успешном выполнении команды.
proc.mq.add(uin,"Система: Ваша фраза была успешно добавлена в игру бутылочка.");
}
/**
* Перевод с кошелька на кошелек.
*/
public void commandPerevod(IcqProtocol proc, String uin, Vector v) {
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "perevod")) return;
int s = (Integer)v.get(0);
int a = (Integer)v.get(1);
Users us = srv.us.getUser(s);
Users uss = srv.us.getUser(uin);
if(uss.room!=5)
{
proc.mq.add(uin,"Система: Банк в (5) комнате - " + srv.us.getRoom(5).getName() + "");
return;
}
if(us.id==0)
{
proc.mq.add(uin,"Система: Такой пользователь ещё не зарегестрировался в чате.");
return;
}
if(uss.id==s)
{
proc.mq.add(uin,"Система: Переводить себе деньги нельзя.");
return;
}
if(a==0)
{
proc.mq.add(uin,"Система: Вы не ввели сумму перевода.");
return;
}
if(uss.zoloto<500)
{
proc.mq.add(uin,"Система: У вас нет золотых на минимальный перевод.");
return;
}
if(a<500)
{
proc.mq.add(uin,"Банкир: Минимальный перевод: (500) золотых.");
return;
}
if(a > uss.vbanke)
{
proc.mq.add(uin,"Банкир: Ваш баланс: " + uss.zoloto + " золотых, у вас недостаточно средств для перевода золотых из банка");
return;
}
srv.getIcqProcess(uss.basesn).mq.add(uss.sn,"Банкир: Перевод на сумму: (" + a + "), успешно переведен юзеру: [ID=" + us.id + "]" + us.localnick + ".");
int gold = us.zoloto+a;
us.zoloto=gold;
srv.us.updateUser(us);
int gold2 = uss.zoloto-a;
uss.zoloto=gold2;
srv.us.updateUser(uss);
srv.getIcqProcess(us.basesn).mq.add(us.sn,"Банкир: Вам поступил перевод на сумму: (" + a + "), от юзера: [ID=" + uss.id + "]" + uss.localnick + ".");
}
/**
* Перевод золотых в банк.
*/
public void commandVbank(IcqProtocol proc, String uin, Vector v) {
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "vbank")) return;
int a = (Integer)v.get(0);
Users uss = srv.us.getUser(uin);
if(uss.room!=5)
{
proc.mq.add(uin,"Система: Банк в (5) комнате - " + srv.us.getRoom(5).getName() + "");
return;
}
if(a==0)
{
proc.mq.add(uin,"Система: Вы не ввели желаеммую сумму, которую хотите перевести в банк.");
return;
}
if(uss.zoloto == 499)
{
proc.mq.add(uin,"Система: У вас закончились золотые.");
return;
}
if(a > uss.zoloto)
{
proc.mq.add(uin,"Система: Ваш баланс: " + uss.zoloto + " золотых, у вас недостаточно средств для перевода золотых в банк");
return;
}
if(a < 500)
{
proc.mq.add(uin,"Система: Минимальная сумма перевода в банк (500) золотых.");
return;
}
proc.mq.add(uin,"Банкир: Перевод в банк на сумму: (" + a + ") золотых, успешно выполнен.");
int gold2 = uss.zoloto-a;
uss.zoloto=gold2;
int gold3 = uss.vbanke+a;
uss.vbanke=gold3;
srv.us.updateUser(uss);
}
/**
* Перевод золотых из банк.
*/
public void commandIzbank(IcqProtocol proc, String uin, Vector v) {
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "izbank")) return;
int a = (Integer)v.get(0);
Users uss = srv.us.getUser(uin);
if(uss.room!=5)
{
proc.mq.add(uin,"Система: Банк в (5) комнате - " + srv.us.getRoom(5).getName() + "");
return;
}
if(a==0)
{
proc.mq.add(uin,"Система: Вы не ввели желаеммую сумму, которую хотите перевести в банк.");
return;
}
if(uss.vbanke == 499)
{
proc.mq.add(uin,"Банкир: У вас закончились золотые");
return;
}
if(a > uss.vbanke)
{
proc.mq.add(uin,"Банкир: Ваш баланс: " + uss.zoloto + " золотых, у вас недостаточно средств для перевода золотых из банка");
return;
}
if(500 > a)
{
proc.mq.add(uin,"Банкир: Минимальная сумма снятия денег (500) золотых.");
return;
}
proc.mq.add(uin,"Банкир: Перевод из банка на сумму: (" + a + ") золотых, успешно выполнен.");
int gold2 = uss.vbanke-a;
uss.vbanke=gold2;
int gold3 = uss.zoloto+a;
uss.zoloto=gold3;
srv.us.updateUser(uss);
}
/**
* Анекдоты.
*/
public void commandAnek(IcqProtocol proc, String uin, Vector v) {
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "anek")) return;
try {
int R = (int) ((Math.random()*100));
String s =  MainProps.getStringFromHTTP("http://anekdotov.net/anekdot/random/" + R + ".html?");
String[] ss = s.split("</td>");
ss = ss[3].split("'>");
ss = ss[1].split("<INPUT type");
ss[0] = ss[0].replace("<BR>","");
ss[0] = ss[0].replace("<br>","");
proc.mq.add(uin,ss [0]);
} catch (Exception ex) {
ex.printStackTrace();
Log.talk("Error save msg: " + ex.getMessage());
proc.mq.add(uin,"Обшибка " + ex.getMessage());
}
}
/**
* Баш.
*/
public void commandBash(IcqProtocol proc, String uin, Vector v) {
String s =  MainProps.getStringFromHTTP("http://bash.org.ru/rss/");
String[] ss = s.split("CDATA");
int R = (int) ((Math.random()*ss.length-1)+1);
ss = ss[R].split("]]></description>");
ss[0] = ss[0].replace("\"","");
ss[0] = ss[0].replace("&quot","\n");
ss[0] = ss[0].replace("[","");
ss[0] = ss[0].replace("<BR>","\n");
ss[0] = ss[0].replace("<br>","\n");
ss[0] = ss[0].replace("<","<");
ss[0] = ss[0].replace(">",">");
proc.mq.add(uin,ss [0]);
}
/**
* анкета.
*/
public void commandAnketa(IcqProtocol proc, String uin, Vector v) {
int id = (Integer)v.get(0);
Users uss = srv.us.getUser(uin);
if (id==0) id=uss.id;
Users us = srv.us.getUser(id);
if (id==0) id=uss.id;
{
proc.mq.add(uin,"Анкета:\nid = " + us.id + "\nНик: " + us.localnick + "\nАлкоголь: " + us.bar + "\nКомната: " + us.room + "\nЗолото: " + us.zoloto + "\nВ банке: " + us.vbanke + "\nАвторитет: " + us.avtopitet + "\nПреступность: " + us.prestypnost + "\nОхрана: " + us.nazoxp + " (" + us.hpoxp + ") \nОружие: " + us.nazorujie + " (" + us.orujie + ")\nЗащита: " + us.nazzachita + " (" + us.zachita + ")\nОтветов: " + us.vopr + "");
}
}

/**
* выжегание охраны
*
*/
public void commandAce(IcqProtocol proc, String uin, Vector v) {
int s = (Integer)v.get(0);
int uron = 350 + r.nextInt(300);
Users us = srv.us.getUser(s);
Users uss = srv.us.getUser(uin);
if(uss.room!=12 && uss.room!=5 && uss.room!=7)
{
proc.mq.add(uin,"Система: Игровая в (12) комнате - " + srv.us.getRoom(12).getName() + "");
return;
}
if(us.id==0)
{
proc.mq.add(uin,"Ошибка: Такой пользователь ещё не зарегистрировался в чате.");
return;
}
if(us.room!=uss.room)
{
proc.mq.add(uin,"Система: Ты должен быть в одной комнате с тем, на кого нападаешь.");
return;
}
if(!uss.nazorujie.equals("Ледомет"))
{
proc.mq.add(uin,"Система: У тебя " + uss.nazorujie + ", а надо чтоб был Ледомет");
return;
}
if(us.state!=UserWork.STATE_CHAT)
{
proc.mq.add(uin,"Система: Этого пользователя нет в чате.");
return;
}
if(us.zoloto < 500)
{
proc.mq.add(uin,"Система: У [" + us.id + "]" + us.localnick + " нет золотых,что ж ты делаешь? Эх...");
return;
}
if (uss.orujie<=0) {
proc.mq.add(uin,"Ошибка: У Вас нет оружия! Купите его с помощью команды !оружие");
return;
}
if (us.hpoxp==0) {
proc.mq.add(uin,"Система: Что ты собираешься замораживать, травку!?");
return;
}
uss.orujie--;
srv.us.updateUser(uss);
if (us.nazzachita.equals("Огненый щит") && us.zachita>0) {
us.zachita--;
srv.us.updateUser(us);
srv.getIcqProcess(us.basesn).mq.add(us.sn,"Система: Вам пытались заморозить охрану, но Вас спас Огненый щит, у вас осталось: (" + us.zachita + ").");
proc.mq.add(uin,"Система: У [ID="+us.id+"] "+us.localnick+" есть Огненый щит. Нападение не удалось!");
return;
}
us.hpoxp-=uron;
if (us.hpoxp<0) us.hpoxp=0;
srv.us.updateUser(us);
srv.getIcqProcess(us.basesn).mq.add(us.sn,"Система: Тебе заморозил охрану: [ID=" + uss.id + "]" + uss.localnick + ", здоровье охраны: (" + us.hpoxp + ")\nСистема: Он вам нанес урон,в размере: (-" + uron + ")");
proc.mq.add(uin,"Система: Ты заморозил охрану: [ID=" + us.id + "]" + us.localnick + ", здоровье его(ее) охраны: (" + us.hpoxp + ")\nСистема: Вы нанесли ему урон, в размере: (-" + uron + ")");
}
/**
* !Богачи
* @param proc
* @param uin
*/
private void commandBagach(IcqProtocol proc, String uin, Vector v){
String s = "20-ка самых богатых в чате:\n------------\n";
try{
PreparedStatement pst = (PreparedStatement) srv.us.db.getDb().prepareStatement("SELECT id, localnick, zoloto FROM users WHERE zoloto > 0 ORDER BY zoloto DESC LIMIT 0,20");
ResultSet rs = pst.executeQuery();
for(int i=0;i<20;i++){
if(rs.next()){
s += " [" + rs.getInt(1) + "] - " + rs.getString(2) + " (" + rs.getInt(3) + ") - золотых\n";
} else {
break;
}
}
rs.close();
pst.close();
} catch (Exception ex){
ex.printStackTrace();
}
proc.mq.add(uin,s);
}

/**
* !умники
* @param proc
* @param uin
*/
private void commandYmniki(IcqProtocol proc, String uin, Vector v){
String s = "20-ка самых умных в чате:\n------------\n";
try{
PreparedStatement pst = (PreparedStatement) srv.us.db.getDb().prepareStatement("SELECT id, localnick, vopr FROM users WHERE vopr > 0 ORDER BY vopr DESC LIMIT 0,20");
ResultSet rs = pst.executeQuery();
for(int i=0;i<20;i++){
if(rs.next()){
s += " [" + rs.getInt(1) + "] - " + rs.getString(2) + " (" + rs.getInt(3) + ") - ответов\n";
} else {
break;
}
}
rs.close();
pst.close();
} catch (Exception ex){
ex.printStackTrace();
}
proc.mq.add(uin,s);
}

/**
* !мажоры
* @param proc
* @param uin
*/
private void commandMa(IcqProtocol proc, String uin, Vector v){
String s = "5-ка мажорных в чате:\n------------\n";
try{
PreparedStatement pst = (PreparedStatement) srv.us.db.getDb().prepareStatement("SELECT id, localnick, avtopitet FROM users WHERE avtopitet > 0 ORDER BY avtopitet DESC LIMIT 0,5");
ResultSet rs = pst.executeQuery();
for(int i=0;i<20;i++){
if(rs.next()){
s += " [" + rs.getInt(1) + "] - " + rs.getString(2) + " (" + rs.getInt(3) + ") - очков авторитета\n";
} else {
break;
}
}
rs.close();
pst.close();
} catch (Exception ex){
ex.printStackTrace();
}
proc.mq.add(uin,s);
}

/**
* !кенты
* @param proc
* @param uin
*/
private void commandKent(IcqProtocol proc, String uin, Vector v){
String s = "5-ка кентов в чате:\n------------\n";
try{
PreparedStatement pst = (PreparedStatement) srv.us.db.getDb().prepareStatement("SELECT id, localnick, prestypnost FROM users WHERE prestypnost > 0 ORDER BY prestypnost DESC LIMIT 0,5");
ResultSet rs = pst.executeQuery();
for(int i=0;i<20;i++){
if(rs.next()){
s += " [" + rs.getInt(1) + "] - " + rs.getString(2) + " (" + rs.getInt(3) + ") - очков преступности\n";
} else {
break;
}
}
rs.close();
pst.close();
} catch (Exception ex){
ex.printStackTrace();
}
proc.mq.add(uin,s);
}
/**
* Игра кости
* @param proc
* @param uin
*/
public void commandKosti(IcqProtocol proc, String uin, Vector v){
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "kosti")) return;
Users uss = srv.us.getUser(uin);
int s = (int) ((Math.random()*6));
int num = (int) ((Math.random()*6)); // случаиное число от 0 до 6
int ss = (int) ((Math.random()*6));
int numm = (int) ((Math.random()*6)); // случаиное число от 0 до 6
if(uss.room!=12)
{
proc.mq.add(uin,"Система: Игровая комната [12] - " + srv.us.getRoom(12).getName() + "");
return;
}
long t = System.currentTimeMillis();
if (t-uss.gametime<30000) {
proc.mq.add(uin,"Система: Пауза между запросами 30 сек...");
return;
}
srv.cq.addMsg("Кости: Я бросил кости, у меня выпало: [" + num + "][" + numm + "] , а у " + uss.localnick + " выпало: [" + s + "][" + ss + "]", uss.sn, uss.room);
if(s+ss<num+numm)
{
srv.cq.addMsg("Кости: [" + uss.id + "]" + uss.localnick + " проиграл(а)", uss.sn, uss.room);
proc.mq.add(uin,"Кости: Я бросил кости, у меня выпало: [" + num + "][" + numm + "] , а у тебя выпало: [" + s + "][" + ss + "]\nТы проиграл(а) 50 золотых, Твой баланс: " + uss.country);
int gold = uss.zoloto-50;
uss.zoloto=gold;
srv.us.updateUser(uss);
}
else
{
int gold = uss.zoloto+50;
uss.zoloto=gold;
srv.us.updateUser(uss);
proc.mq.add(uin,"Кости: Ты получаеш БОНУС!!! 100 золотых,твой баланс = " + uss.country);
srv.cq.addMsg("Кости: БОНУС!!! " + uss.localnick + "получает бонус 100 золотых.", uss.sn, uss.room);
}
}

/**
* Установка пароля на комнату
* @param proc
* @param uin
*/
public void commandSetpass(IcqProtocol proc, String uin, Vector v) {
if (!isChat(proc, uin) && !psp.testAdmin(uin)) return;
if (!auth(proc, uin, "setpass")) return;
String s = (String) v.get(0);
int room = srv.us.getUser(uin).room;
Rooms r = srv.us.getRoom(room);
r.setPass(s);
srv.us.saveRoom(r, s);
Log.info("Установлен пароль на комнату " + room + ": " + s);
proc.mq.add(uin, "Система: Пароль " + s + " на комнату успешно установлен.");
}
/**
* Покупка комнаты
* @param proc
* @param uin
*/
public void commandKomnata(IcqProtocol proc, String uin, Vector v) {
Users uss = srv.us.getUser(uin);
int room = (Integer)v.get(0);
String s = (String)v.get(1);
if(uss.room!=7)
{
proc.mq.add(uin,"Система: Магазин в (7) - комнате " + srv.us.getRoom(7).getName());
return;
}
if(uss.zoloto < 10000)
{
proc.mq.add(uin,"Система: Ваш баланс: " + uss.country + " золотых, у вас недостаточно средств для покупки комнаты.");
return;
}
if(srv.us.checkRoom(room)){
proc.mq.add(uin,"Система: Такая комната уже существует!");
return;
}
Rooms r = new Rooms();
r.setId(room);
r.setName(s);
srv.us.createRoom ( r );
int gold = uss.zoloto-10000;
uss.zoloto=gold;
srv.us.updateUser(uss);
proc.mq.add(uin,"Система: комната (" + room + ") - "+s+" успешно создана!");
srv.cq.addMsg("Система: [ID=" + uss.id + "] " + uss.localnick + " купил(а) комнату ("+room+") -"+s, uss.sn, uss.room);
}

/**
* Игра наперсток
* @author bezzzdelnick
* @param proc
* @param uin
*/
public void commandHaperstok(IcqProtocol proc, String uin, Vector v) {
int s = (Integer)v.get(0);
int stavka = (Integer)v.get(1);// набранное число
Users uss = srv.us.getUser(uin);
int num = (int) ((Math.random()*3)); // случаиное число от 0 до 3
if(uss.room!=12)
{
proc.mq.add(uin,"Система: Игровая в (12) комнате - " + srv.us.getRoom(12).getName());
return;
}
long t = System.currentTimeMillis();
if (t-uss.gametime<30000) {
proc.mq.add(uin,"Система: Пауза между запросами 30 сек...");
return;
}
if(s>3)
{
proc.mq.add(uin,"Шуллер: Число должно быть от 0 до 3");
return;
}
if(uss.zoloto <10)
{
proc.mq.add(uin,"Шуллер: У тебя нету золотых на минимальную ставку:-D");
return;
}
if(stavka <10)
{
proc.mq.add(uin,"Шуллер: У тебя нету золотых на минимальную ставку:-D");
return;
}
if(stavka >1000)
{
proc.mq.add(uin,"Шуллер: Ого... а если я проиграю,то мне не чем будет отдовать тебе выигрыш.");
return;
}
if(s==num)
{
int uroven = uss.zoloto+stavka*2;
uss.zoloto=uroven;
srv.us.updateUser(uss);
uss.gametime=t;
srv.us.updateUser(uss);
srv.cq.addMsg("Шуллер: Колечко было здесь (" + num + "), выигрыш " + uss.localnick + ": (" + stavka*2 + ") золотых.", "", uss.room);
proc.mq.add(uin,"Шуллер: Колечко было в : (" + num + ") твой выигрыш: (" + stavka*2 + ") золотых.");
}
if(s!=num){
int uroven = uss.zoloto-stavka;
uss.zoloto=uroven;
srv.us.updateUser(uss);
uss.gametime=t;
srv.us.updateUser(uss);
srv.cq.addMsg("Шуллер: Колечко было здесь (" + num + "), проигрыш " + uss.localnick + ": (" + stavka + ") золотых.", "", uss.room);
proc.mq.add(uin,"Шуллер: А колечко было здесь (" + num + "), твой проигрыш: (" + stavka + ") золотых;-).");
}
}


/**
* Выпустить
* @param proc
* @param uin
*/
public void commandUBanRoom(IcqProtocol proc, String uin, Vector v) {
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "banroom")) return;
int i1 = (Integer)v.get(0);
Users u = srv.us.getUser(i1);
if(u.id==0){
proc.mq.add(uin,"Система: Пользователь не найден");
return;
}
srv.us.grantUser(i1, "room");
if(u.state==UserWork.STATE_CHAT){
srv.getIcqProcess(u.basesn).mq.add(u.sn,"Система: Тебе разрешено выходить за пределы этой комнаты");
}
// Сообщаем об успешном выполнении команды
proc.mq.add(uin,"Система: Пользователю " + u.localnick + " возвращены права на переход по комнатам");
}

/**
* Изменить ник
* @param proc
* @param uin
*/
public void commandChnNick(IcqProtocol proc, String uin, Vector v) {
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "chnick")) return;
int i = (Integer)v.get(0);
String nick = (String)v.get(1);
Users u = srv.us.getUser(i);
if(u.id==0){
proc.mq.add(uin,"Система: Пользователь не найден");
return;
}
if(i==1){
proc.mq.add(uin,"Система: Запрещено менять ник главному админу!");
return;
}
String oldNick = u.localnick;
u.localnick=nick;
srv.us.updateUser(u);
srv.us.db.event(u.id, uin, "REG", 0, "", nick);
if(u.state==UserWork.STATE_CHAT){
srv.cq.addMsg("Система: У пользователя " + oldNick + " ник изменен на " + nick, "", u.room);
}
proc.mq.add(uin,"Система: Ник успешно изменен");
}
/**
* БАР
* @param proc
* @param uin
*/
public void commandBar(IcqProtocol proc, String uin, Vector v) {
if (!isChat(proc, uin) && !psp.testAdmin(uin)) return;
if (!auth(proc, uin, "bar")) return;
try{
int tovar = (Integer)v.get(0);
int zoloto;
int bar=0;
int i = getRND(5)+50;
String st = "";
Users us = srv.us.getUser(uin);
if(us.room!=2)
{
proc.mq.add(uin,"Система: Бар в (2) комнате - " + srv.us.getRoom(2).getName());
return;
}
if((tovar==0)||(tovar>20)) {
String[] s = psp.loadText("./text/bar.txt").split("<br>");
for (int e = 0; e < s.length; e++) {
proc.mq.add(uin, s[e]);
}
return;
}
if(((tovar>=1) && (tovar<=14)) && (us.bar == 100)) {
proc.mq.add(uin, "Система: Вам уже достаточно, вы пьяны на 100%");
return;
}
String t = "Вино белое сухое;Вино красное;Вино полусладкое;Виски;Водка;Джин-Тоник;Коктейль Индиана Джус;Коньяк;Кровавая Мэри;Мартини;Пиво;Самогонка;Спирт;Ягуар;Кефир;Кока-Кола;Молочный коктейль;Томатный сок;Фрэш;Яблочный сок";
String[] ss = t.split(";");
if(us.zoloto<i) {
proc.mq.add(uin,"Бармен: У вас недостаточно золотых на покупку " + ss[tovar-1] + "");
return;
}
if((tovar>=1) && (tovar<=14)) {
if(us.bar==0) {
us.bartime = System.currentTimeMillis()+60*60000;
srv.us.updateUser(us);
}
bar = us.bar+25;
} else {
if(us.bar !=0) {
bar = us.bar-25;
}
}
zoloto = us.zoloto-i;
us.bar = bar;
us.zoloto = zoloto;
srv.us.updateUser(us);
if(us.bar==0) {
us.bartime = System.currentTimeMillis();
srv.us.updateUser(us);
st = "Система: Вы трезвы";
} else {
st = "Система: Вы пьяны на "+us.bar+"%";
}
proc.mq.add(uin, "Бармен: Вы заказали " + ss[tovar-1] + ", с вас " + i+st);
srv.cq.addMsg("Бармен: Пользователь "+us.localnick+" заказал(а) " + ss[tovar-1] + "", us.sn, us.room);
} catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin,"Ошибка "+ex.getMessage());
}
}
public String getBar(String uin, String mmsg){
if(srv.us.getUser(uin).bar==25) {
String s = "ета... "+mmsg;
mmsg = s;
}
if(srv.us.getUser(uin).bar==50) {
mmsg = mmsg.replace("п","б");
mmsg = mmsg.replace("в","ф");
mmsg = mmsg.replace("к","г");
mmsg = mmsg.replace("т","д");
mmsg = mmsg.replace("ш","ж");
mmsg = mmsg.replace("с","з");
mmsg = mmsg.replace("о","а");
mmsg = mmsg.replace("и","е");
}
if(srv.us.getUser(uin).bar==75) {
mmsg = mmsg.replace("  "," ");
String[] msg = mmsg.split(" ");
mmsg = "";
for(int i1=0;i1<msg.length;i1++) {
int t;
int m;
String s = ";";
String sa = "";
int len = msg[i1].length();
if(len==1) {
sa = msg[i1];
} else {

for(int i=0;i<len;i++) {
s +=Integer.toString(i)+";";
}
for(int i=0;i<len;i++) {
t = getRND(len - 1);
s=s.replace(";"+Integer.toString(t)+";",";");
s +=Integer.toString(t)+";";
}
String[] l = s.split(";");
for(int i=0;i<len;i++) {
m = Integer.parseInt(l[i+1]);
System.out.println(m);
sa += msg[i1].charAt(m);
}
}
mmsg +=sa+" ";
}
}
if(srv.us.getUser(uin).bar==100) {
mmsg = mmsg.replace("п","ббббббб");
mmsg = mmsg.replace("в","ффффффф");
mmsg = mmsg.replace("к","ггггггг");
mmsg = mmsg.replace("т","дддддддд");
mmsg = mmsg.replace("ш","жжжжжжжж");
mmsg = mmsg.replace("с","зззззззз");
mmsg = mmsg.replace("о","аааааааа");
mmsg = mmsg.replace("и","ееееееее");
mmsg = mmsg.replace("ы","ыкккккк......");
}
return mmsg;
}

/**
* удалить комнату
* @param proc
* @param uin
*/
public void commandDeleteRoom(IcqProtocol proc, String uin, Vector v) {
if (!isChat(proc, uin) && !psp.testAdmin(uin)) return;
if (!auth(proc, uin, "wroom")) return;
int room = (Integer) v.get(0);
Users uss = srv.us.getUser(uin);
if (!srv.us.checkRoom(room)) {
proc.mq.add(uin, "Такой комнаты не существует!");
return;
}
srv.cq.addMsg("Была удалена комната " + srv.us.getRoom(room).getName() + "[" + room + "] пользователем " + uss.localnick + "[" + uss.id + "]", uin, uss.room);
srv.cq.addMsg("Была удалена комната " + srv.us.getRoom(room).getName() + "[" + room + "] пользователем " + uss.localnick + "[" + uss.id + "]", uin, 0);
proc.mq.add(uin, "Комната " + room + " была успешно удалена");
Rooms r = new Rooms();
r.setId(room);
srv.us.deleteRoom(r);
}

/**
* Покупка золотых через смс
* @param proc
* @param uin
* @param v
* @param mmsg
*/
public void commandSmszoloto(IcqProtocol proc, String uin, List v) {
try {
if (!onlineAndAuthorized(proc,uin,null)) return;
BufferedReader ww = new BufferedReader(new InputStreamReader(new FileInputStream(psp.getTextDirectory()+"pass.txt"),"windows-1251"));
String f1 = ww.readLine();
ww.close();
if (f1==null) f1 = "";
Users u = srv.us.getUser(uin);
String pass = (String)v.get(0);
String[] ss = f1.split(";");
pass = pass.trim();
if(pass.length()==0)
{
proc.mq.add(uin,"Ошибка: пустой пароль.");
return;
}
for (int i=0; i<ss.length;i++)
{
if (pass.equals(ss[i].trim()))
{
u.zoloto+=1000;
srv.us.updateUser(u);
String newList = "";
for (int j = 0; j<ss.length; j++) {
if (i!=j) {
if (newList.length()!=0) newList+=";";
newList+=ss[j];
}
}
OutputStreamWriter A = new OutputStreamWriter(new FileOutputStream(psp.getTextDirectory()+"pass.txt",false),"windows-1251");
A.write(newList);
A.close();
//Оповестим
Log.talk("Пароль: "+pass);
proc.mq.add(uin,"СМС: Вы успешно ввели пароль и купили (1000) золотых.");
return;
}
}
proc.mq.add(uin,"Ошибка: неверный пароль.");
}
catch (Exception ex)
{
ex.printStackTrace();
Log.talk("Ошибка покупки золотых: " + ex.getMessage());
proc.mq.add(uin,"Произошла ошибка: " + ex.getMessage());
}
}
/**
* Перетащить в другую комнату
* @param proc
* @param uin
* @param v
* @param mmsg
*/
public void commandBanother(IcqProtocol proc, String uin, List v) {
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "banother")) return;
int i1 = (Integer)v.get(0);
int i2 = (Integer)v.get(1);
Users u = srv.us.getUser(i1);
if(u.id==0){
proc.mq.add(uin,"Система: Пользователь не найден");
return;
}
if(u.state!=UserWork.STATE_CHAT){
proc.mq.add(uin,"Система: Этого пользователя нет в чате.");
return;
}
if(u.room==i2){
proc.mq.add(uin,"Система: Пользователь уже сидит в этой комнате");
return;
} else {
u.room=i2;
srv.us.updateUser(u);
srv.cq.changeUserRoom(u.sn, i2);
srv.cq.addMsg("Система: " + u.localnick + " перетащен в комнату " + u.room, u.sn, u.room);
srv.getIcqProcess(u.basesn).mq.add(u.sn,"Система: Вжжжжжж.... тыдыщщьь... тебя перетащили в комнату (" + i2 + ")");
}
proc.mq.add(uin,"Система: Пользователь " + u.localnick + " успешно перетащен в комнату (" + i2 + ")");
}
/**
* !голос
* @param proc
* @param uin
* @param v
*/
public void commandGolos(IcqProtocol proc, String uin, Vector v){
int s = (Integer)v.get(0); // набранный ид
String dol = (String)v.get(1); // + или - ??
Users us = srv.us.getUser(s);
Users uss = srv.us.getUser(uin);
long t = System.currentTimeMillis();
if (t-uss.golostime<86400000*3) {
proc.mq.add(uin,"Система: Голосовать за пользователя можно 1 раз в 3 дня");
return;
}
if(us.id==0)
{
proc.mq.add(uin,"Система: Такой пользователь ещё не зарегестрировался в чате");
return;
}
if(uss.id==s)
{
proc.mq.add(uin,"Система: Голосовать против или за самого себя нельзя!");
return;
}
if(dol.equals("+")){
proc.mq.add(uin,"Система: Ты увеличил(а) авторитет пользователю [ID=" + us.id + "] " + us.localnick + "");
us.avtopitet=+1;
srv.us.updateUser(us);
uss.golostime=t;
srv.us.updateUser(uss);
srv.getIcqProcess(us.basesn).mq.add(us.sn,"Система: Теперь у тебя авторитет (" + us.avtopitet + "). Тебе увеличил(а) авторитет [ID=" + uss.id + "] " + uss.localnick + "");
return;
} else if (dol.equals("-")){
proc.mq.add(uin,"Система: Ты уменьшил(а) авторитет пользователю [ID=" + us.id + "] " + us.localnick + "");
us.avtopitet=-1;
srv.us.updateUser(us);
uss.golostime=t;
srv.us.updateUser(uss);
srv.getIcqProcess(us.basesn).mq.add(us.sn,"Система: Теперь у тебя авторитет (" + us.avtopitet + "). Тебе уменьшил(а) авторитет [ID=" + uss.id + "] " + uss.localnick + "");
return;
}
else proc.mq.add(uin,"Система: Нужно указать '+' или '-'.");
}
/**
* !напасть
* @param proc
* @param uin
* @param v
*/
public void commandNapadenie(IcqProtocol proc, String uin, List v) {
if (!onlineAndAuthorized(proc, uin, "napadenie")) return;
int s = (Integer)v.get(0);
Users us = srv.us.getUser(s);
Users uss = srv.us.getUser(uin);
if(uss.room!=12 && uss.room!=5 && uss.room!=7)
{
proc.mq.add(uin,"Мент: Здесь нельзя нападать.");
return;
}
long t = System.currentTimeMillis();
if (t-uss.napadtime<30000) {
proc.mq.add(uin,"Система: Нападать можно 1 раз в 30 сек...");
return;
}
if(us.id==0)
{
proc.mq.add(uin,"Мент: Такой пользователь ещё не зарегестрировался в чате.");
return;
}
if(us.room!=uss.room)
{
proc.mq.add(uin,"Мент: Ты должен быть в одной комнате с тем на кого нападаешь.");
return;
}
if(us.state!=UserWork.STATE_CHAT)
{
proc.mq.add(uin,"Система: Этого пользователя нет в чате.");
return;
}
if(us.zoloto < 500)
{
proc.mq.add(uin,"Мент: У [ID=" + us.id + "] " + us.localnick + " нет золотых,чтож ты делаеш? Эх...");
return;
}
int damage = ((uss.prestypnost-1)/4)+1;
if (damage<1) damage = 1;
else if (damage>10000) damage = 10000;
us.hpoxp-=damage;
if (us.hpoxp>0) {
srv.us.updateUser(us);
uss.gametime=t;
srv.us.updateUser(uss);
proc.mq.add(uin,"Смотрящий: Ты нарвался на охрану " + us.localnick + ".\nНападение не получилось.\nЗдоровье охраны осталось: (" + us.hpoxp +").");
srv.getIcqProcess(us.basesn).mq.add(us.sn,"Смотрящий: На тебя совершил нападение [ID=" + uss.id + "]" + uss.localnick + ".\nЗдоровье твоей охраны (" + us.hpoxp + ").");
return;
}
us.hpoxp = 0;
int gold1 = us.zoloto;
us.zoloto=0;
srv.us.updateUser(us);
srv.getIcqProcess(us.basesn).mq.add(us.sn,"Смотрящий: На тебя совершил нападение [ID=" + uss.id + "] " + uss.localnick + " и похитил (" + gold1 + ") золотых.");
int uroven = uss.prestypnost+1;
uss.prestypnost=uroven;
int gold = uss.zoloto+gold1;
uss.zoloto=gold;
srv.us.updateUser(uss);
proc.mq.add(uin,"Смотрящий: Нападение успешно завершено.\nТы отнял (" + gold1 + ") золотых.\nТвой баланс: (" + uss.zoloto + ") золотых.\nТвой уровень преступности: (" + uss.prestypnost + ").");
}
/**
* !казино
* @param proc
* @param uin
* @param v
*/
public void commandKazino(IcqProtocol proc, String uin, List v) {
try{
Users uss = srv.us.getUser(uin);
if(uss.room!=12)
{
proc.mq.add(uin,"Система: Игровая в (12) комнате - " + srv.us.getRoom(12).getName());
return;
}
long t = System.currentTimeMillis();
if (t-uss.gametime<30000) {
proc.mq.add(uin,"Система: Пауза между запросами 30 сек...");
return;
}
if (uss.zoloto < 10)
{
proc.mq.add(uin, "Система: Ну ты вообще бомж... Золотых на минимальную ставку не хватает");
return;
}
int num1 = (int)(Math.random() * 4.0D);
int num2 = (int)(Math.random() * 4.0D);
int num3 = (int)(Math.random() * 4.0D);
int n1 = 0;
int n2 = 0;
int n3 = 0;
if (num1 == 0) n1 = 50;
if (num1 == 1) n1 = 100;
if (num1 == 2) n1 = 300;
if (num1 == 3) { n1 = 500;
}
if (num2 == 0) n2 = 50;
if (num2 == 1) n2 = 100;
if (num2 == 2) n2 = 300;
if (num2 == 3) { n2 = 500;
}
if (num3 == 0) n3 = 50;
if (num3 == 1) n3 = 100;
if (num3 == 2) n3 = 300;
if (num3 == 3) n3 = 500;
if ((n1 == n2) && (n2 == n3) && (n3 == n1))
{
uss.zoloto += n3;
srv.us.updateUser(uss);
uss.gametime=t;
srv.us.updateUser(uss);
proc.mq.add(uin, "Джокер: выпало (" + n1 + ")(" + n2 + ")(" + n3 + ") ,выигрыш " + n3 + " золотых.");
srv.cq.addMsg("Джокер: выпало (" + n1 + ")(" + n2 + ")(" + n3 + ") ,выигрыш " + uss.localnick + " = " + n3 + " золотых.", uss.sn, uss.room);
return;
}
uss.zoloto -= 10;
srv.us.updateUser(uss);
uss.gametime=t;
srv.us.updateUser(uss);
proc.mq.add(uin, "Джокер: выпало (" + n1 + ")(" + n2 + ")(" + n3 + ") ,проигрыш 10 золотых.");
srv.cq.addMsg("Джокер: выпало (" + n1 + ")(" + n2 + ")(" + n3 + ") , " + uss.localnick + " проиграл(а) 10 золотых.", uss.sn, uss.room);
return;
}
catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin, "Ошибка " + ex.getMessage());
}
}
/**
* !admin
* @param proc
* @param uin
*/
public void commandAdmin(IcqProtocol proc, String uin, List v) {
if(!isChat(proc,uin) && !psp.testAdmin(uin)) return;
if(!auth(proc,uin, "admin")) return;
String lst = "";
Enumeration e = srv.cq.uq.keys();
while(e.hasMoreElements()){
String i = (String) e.nextElement();
Users us = srv.us.getUser(i);
if (srv.us.getUserGroup(us.id).equals("admin")) {
lst = lst + us.id+" - "+us.localnick+" , ["+us.room+"]"+srv.us.getRoom(us.room).getName()+"; \n";
}
}
proc.mq.add(uin,"Администрация онлайн:\n "+lst);
}
/**
* Покупка преступности через смс
* @param proc
* @param uin
* @param v
* @param mmsg
*/
public void commandSmspre(IcqProtocol proc, String uin, List v) {
try {
if (!onlineAndAuthorized(proc,uin,null)) return;
BufferedReader ww = new BufferedReader(new InputStreamReader(new FileInputStream(psp.getTextDirectory()+"passpre.txt"),"windows-1251"));
String f1 = ww.readLine();
ww.close();
if (f1==null) f1 = "";
Users u = srv.us.getUser(uin);
String pass = (String)v.get(0);
String[] ss = f1.split(";");
//Если пользователь ввел пустой пароль
pass = pass.trim();
if(pass.length()==0)
{
proc.mq.add(uin,"Ошибка: пустой пароль.");
return;
}
for (int i=0; i<ss.length;i++)
{
if (pass.equals(ss[i].trim()))
{
u.prestypnost+=40;
srv.us.updateUser(u);
String newList = "";
for (int j = 0; j<ss.length; j++) {
if (i!=j) {
if (newList.length()!=0) newList+=";";
newList+=ss[j];
}
}
OutputStreamWriter A = new OutputStreamWriter(new FileOutputStream(psp.getTextDirectory()+"passpre.txt",false),"windows-1251");
A.write(newList);
A.close();
//Оповестим
Log.talk("Пароль: "+pass);
proc.mq.add(uin,"СМС: Вы успешно ввели пароль и купили (40) преступности.");
return;
}
}
proc.mq.add(uin,"Ошибка: неверный пароль.");
}
catch (Exception ex)
{
ex.printStackTrace();
Log.talk("Ошибка покупки преступности: " + ex.getMessage());
proc.mq.add(uin,"Произошла ошибка: " + ex.getMessage());
}
}
/**
* Покупка преступности через смс
* @param proc
* @param uin
* @param v
* @param mmsg
*/
public void commandSmsavto(IcqProtocol proc, String uin, List v) {
try {
if (!onlineAndAuthorized(proc,uin,null)) return;
BufferedReader ww = new BufferedReader(new InputStreamReader(new FileInputStream(psp.getTextDirectory()+"passavto.txt"),"windows-1251"));
String f1 = ww.readLine();
ww.close();
if (f1==null) f1 = "";
Users u = srv.us.getUser(uin);
String pass = (String)v.get(0);
String[] ss = f1.split(";");
//Если пользователь ввел пустой пароль
pass = pass.trim();
if(pass.length()==0)
{
proc.mq.add(uin,"Ошибка: пустой пароль.");
return;
}
for (int i=0; i<ss.length;i++)
{
if (pass.equals(ss[i].trim()))
{
u.avtopitet+=20;
srv.us.updateUser(u);
String newList = "";
for (int j = 0; j<ss.length; j++) {
if (i!=j) {
if (newList.length()!=0) newList+=";";
newList+=ss[j];
}
}
OutputStreamWriter A = new OutputStreamWriter(new FileOutputStream(psp.getTextDirectory()+"passavto.txt",false),"windows-1251");
A.write(newList);
A.close();
//Оповестим
Log.talk("Пароль: "+pass);
proc.mq.add(uin,"СМС: Вы успешно ввели пароль и купили (20) авторитета.");
return;
}
}
proc.mq.add(uin,"Ошибка: неверный пароль.");
}
catch (Exception ex)
{
ex.printStackTrace();
Log.talk("Ошибка покупки автоитета: " + ex.getMessage());
proc.mq.add(uin,"Произошла ошибка: " + ex.getMessage());
}
}
/**
* !здать
* @param proc
* @param uin
* @param v
* @param mmsg
*/
public void commandZoloto(IcqProtocol proc, String uin, List v) {
Users uss = srv.us.getUser(uin);
if(uss.id==1){
int i = (Integer)v.get(0);
int bal = (Integer)v.get(1);
Users u = srv.us.getUser(i);
if(u.id==0){
proc.mq.add(uin,"Система: Пользователь не найден");
return;
}
u.zoloto+=bal;
srv.us.updateUser(u);
proc.mq.add(uin,"Система: Ты прибавил ему ("+bal+") золотых.");
proc.mq.add(u.sn,"Система: Вам прибавили ("+bal+") золотых.");
}
else
proc.mq.add(uin,"Система: У вас нет доступа к команде!");
}
/**
* !пдать
* @param proc
* @param uin
* @param v
* @param mmsg
*/
public void commandPres(IcqProtocol proc, String uin, List v) {
Users uss = srv.us.getUser(uin);
if(uss.id==1){
int i = (Integer)v.get(0);
int bal = (Integer)v.get(1);
Users u = srv.us.getUser(i);
if(u.id==0){
proc.mq.add(uin,"Система: Пользователь не найден");
return;
}
u.prestypnost+=bal;
srv.us.updateUser(u);
proc.mq.add(uin,"Система: Ты прибавил ему ("+bal+") преступности.");
proc.mq.add(u.sn,"Система: Вам прибавили ("+bal+") преступности.");
}
else
proc.mq.add(uin,"Система: У вас нет доступа к команде!");
}
/**
* !адать
* @param proc
* @param uin
* @param v
* @param mmsg
*/
public void commandAvto(IcqProtocol proc, String uin, List v) {
Users uss = srv.us.getUser(uin);
if(uss.id==1){
int i = (Integer)v.get(0);
int bal = (Integer)v.get(1);
Users u = srv.us.getUser(i);
if(u.id==0){
proc.mq.add(uin,"Система: Пользователь не найден");
return;
}
u.avtopitet+=bal;
srv.us.updateUser(u);
proc.mq.add(uin,"Система: Ты прибавил ему ("+bal+") авторитета.");
proc.mq.add(u.sn,"Система: Вам прибавили ("+bal+") авторитета.");
}
else
proc.mq.add(uin,"Система: У вас нет доступа к команде!");
}
/**
* !тюрьма
* @param proc
* @param uin
* @param v
* @param mmsg
*/
public void commandBanRoom(IcqProtocol proc, String uin, Vector v)
{
if ((!isChat(proc, uin)) && (!this.psp.testAdmin(uin))) {
return;
}
if (!auth(proc, uin, "ban_room"))
return;
try
{
int id = ((Integer)v.get(0)).intValue();
int room = 4;
int t = ((Integer)v.get(1)).intValue();
Users u = this.srv.us.getUser(id);
String sn = this.srv.us.getUser(id).sn;
if (this.psp.testAdmin(sn)) {
proc.mq.add(uin, "Система: Очень наивный человек, не закрыть админа *NO* ");
return;
}
if (u.id == 0) {
proc.mq.add(uin, "Система: Пользователь не найден.");
return;
}
if (u.state != 2) {
proc.mq.add(uin, "Система: Этого пользователя нет в чате.");
return;
}
u.room = room;
this.srv.cq.changeUserRoom(u.sn, room);
this.srv.cq.addMsg("Тюремщик: [ID=" + u.id + "] "+ u.localnick + " принимайте новенького, попал за оплошность. Заперт тут на: (" + testBanRoom(u.sn) + ") минут.", u.sn, u.room);
this.srv.us.revokeUser(id, "room");
u.lastbanroom = (System.currentTimeMillis() + t * 60000);
this.srv.us.updateUser(u);
proc.mq.add(uin, "Система: Пользователь " + u.localnick + " успешно заперт в комнате (" + room + ") на (" + testBanRoom(u.sn) + ") минут.");
this.srv.getIcqProcess(u.basesn).mq.add(u.sn, "Система: Ты заперт в комнате (" + room + ") на (" + testBanRoom(u.sn) + ") минут.");
} catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin, "Ошибка " + ex.getMessage());
}
}
public int testBanRoom(String sn) {
long tc = this.srv.us.getUser(sn).lastbanroom;
long t = System.currentTimeMillis();
return (tc > t) ? (int)(tc - t) / 60000 : 0;
}
/**
* !отрезветь
* @param proc
* @param uin
* @param v
* @param mmsg
*/
public void commandTrezv(IcqProtocol proc, String uin, String tmsg, Vector v)
{
if ((!isChat(proc, uin)) && (!psp.testAdmin(uin))) {
return;
}
if (!auth(proc, uin, "game"))
return;
try
{
Users uss = srv.us.getUser(uin);
if(uss.room!=2)
{
proc.mq.add(uin,"Система: Бар в (2) комнате - " + srv.us.getRoom(2).getName());
return;
}
long t = System.currentTimeMillis();
if (t-uss.bartime<60000*60) {
proc.mq.add(uin,"Система: Отрезвевать можно раз в 1 час.");
return;
}
if (uss.zoloto < 200) {
proc.mq.add(uin, "Бармен: Ваш баланс: (" + uss.zoloto + ") золотых, бухать надо меньше.");
return;
}
proc.mq.add(uin, "Бармен: Вы отрезвели, с вас (200) золотых.");
int gold = uss.zoloto - 200;
uss.zoloto = gold;
uss.bar=0;
srv.us.updateUser(uss);
} catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin, "Ошибка " + ex.getMessage());
}
}
/**
* Проверка, были ли входящие приватные сообщения и от кого
*/
private String testPM(String sn){
if(up.get(sn)==null)
return "";
else 
return up.get(sn);
}

public void commandXst(IcqProtocol proc, String uin, Vector v) {
if (!isChat(proc, uin) && !psp.testAdmin(uin)) {
return;
}
if (!auth(proc, uin, "xst")) {
return;
}
if (xstatus != null) {
proc.mq.add(uin, "Запущена авто смена xstatus`ов. Вы не можете сменить статус.");
return;
}
int nomer = (Integer) v.get(0);
if (nomer == 0) {
ListStatus(proc, uin);
return;
}
String text = (String) v.get(1);
if (text.equals("") || text.equals(" ")) {
proc.mq.add(uin, "Текст статуса отсутствует");
return;
}
psp.setIntProperty("icq.xstatus", nomer);
psp.setStringProperty("icq.STATUS_MESSAGE2", text);
Manager.getInstance().getService(srv.getName()).getProps().save();
if (nomer >= 1 && nomer <= 37) {
try {
for (int uins = 0; uins < srv.con.uins.count(); uins++) {
srv.con.uins.proc.get(uins).setXStatus(nomer, text);
}
proc.mq.add(uin, "Статус чата изменён успешно");
} catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin, "Произошла ошибка при смене статуса");
}
} else {
proc.mq.add(uin, "Числа должно быть от 1 до 34");
}
}

public void ListStatus(IcqProtocol proc, String uin){
String s = "Список XStatus'ов\n" ;
s+="1 - Сердитый\n";
s+="2 - Купаюсь\n";
s+="3 - Уставший\n";
s+="4 - Вечеринка\n";
s+="5 - Пью пиво\n";
s+="6 - Думаю\n";
s+="7 - Кушаю\n";
s+="8 - Телевизор\n";
s+="9 - Друзья\n";
s+="10 - Пью чай/кофе\n";
s+="11 - Слушаю музыку\n";
s+="12 - Дела\n";
s+="13 - В кино\n";
s+="14 - Развлекаюсь\n";
s+="15 - Телефон\n";
s+="16 - Играю \n";
s+="17 - Учёба \n";
s+="18 - Магазин \n";
s+="19 - Болею \n";
s+="20 - Сплю \n";
s+="21 - Отрываюсь \n";
s+="22 - В интернете \n";
s+="23 - На работе \n";
s+="24 - Печатаю \n";
s+="25 - Пикник \n";
s+="26 - КПК \n";
s+="27 - Мобильник \n";
s+="28 - Засыпаю \n";
s+="29 - Туалет \n";
s+="30 - Вопрос \n";
s+="31 - Дорога \n";
s+="32 - Сердце \n";
s+="33 - Поиск \n";
s+="34 - Дневник\n";
proc.mq.add(uin, s);
}
/**
* Свадьба
*/
public void commandSvadba(IcqProtocol proc, String uin, Vector v, String mmsg) {
if (!isChat(proc, uin) && !psp.testAdmin(uin)) return;
if (!auth(proc, uin, "svadba_razvod")) return;
try {
int i1 = (Integer) v.get(0);
int i2 = (Integer) v.get(1);
Users u = srv.us.getUser(i1);
Users uss = srv.us.getUser(i2);
if(uss.room!=1)
{
proc.mq.add(uin,"Система: Загс (1) комнате - " + srv.us.getRoom(1).getName());
return;
}
if ((u.id == 0) || (uss.id == 0)) {
proc.mq.add(uin, "Система: Пользователь не найден");
return;
}
File acu = new File("./text/" + srv.getName() + "/sva/" + i1 + ".txt");
File acu1 = new File("./text/" + srv.getName() + "/sva/" + i2 + ".txt");
if (acu.exists() || acu1.exists()) {
proc.mq.add(uin, "Система: Пользователи или один из пользователей в браке");
return;
}
if ((u.state != UserWork.STATE_CHAT) || (uss.state != UserWork.STATE_CHAT)) {
proc.mq.add(uin, "Система: Этого пользователя нет в чате.");
return;
}
srv.us.db.event(uss.id, uin, "SVADBA", u.id, "", "поженились");
srv.cq.addMsg("Система: У пользователей " + uss.localnick + " [ID=" + uss.id + "] *IN LOVE* и *IN LOVE* " + u.localnick + "[ID=" + u.id + "] " + "свадьба*IN LOVE*!", u.sn, u.room);
srv.cq.addMsg("Система: У пользователей " + uss.localnick + " [ID=" + uss.id + "] *IN LOVE* и *IN LOVE* " + u.localnick + "[ID=" + u.id + "] " + "свадьба*IN LOVE*!", uss.sn, uss.room);
srv.getIcqProcess(uss.basesn).mq.add(uss.sn, "Священник: Поздравляю у тебя свадьба, твоя невеста " + u.localnick + " [ID=" + u.id + "]");
srv.getIcqProcess(u.basesn).mq.add(u.sn, "Священник: Поздравляю у тебя свадьба, твой жених " + uss.localnick + " [ID=" + uss.id + "]");
OutputStreamWriter ow1 = new OutputStreamWriter(new FileOutputStream("./text/" + srv.getName() + "/sva/" + i2 + ".txt", true), "windows-1251");
OutputStreamWriter ow = new OutputStreamWriter(new FileOutputStream("./text/" + srv.getName() + "/sva/" + i1 + ".txt", true), "windows-1251");
ow.write("_жена_" + uss.localnick + "");
ow.close();
ow1.write("_муж_" +u.localnick+"");
ow1.close();
proc.mq.add(uin, "Пользователи " + uss.localnick + "*IN LOVE* " + uss.id + " *IN LOVE* и " + u.localnick + "*IN LOVE* " + u.id + " *IN LOVE* " + " обвенчались!");
} catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin, "Ошибка " + ex.getMessage());
}
}
/**
* Развод
*/
public void commandRazvod(IcqProtocol proc, String uin, Vector v, String mmsg) {
if (!isChat(proc, uin) && !psp.testAdmin(uin)) return;
if (!auth(proc, uin, "svadba_razvod")) return;
try {
int i1 = (Integer) v.get(0);
int i2 = (Integer) v.get(1);
Users u = srv.us.getUser(i1);
Users uss = srv.us.getUser(i2);
if(uss.room!=1)
{
proc.mq.add(uin,"Система: Загс (1) комнате - " + srv.us.getRoom(1).getName());
return;
}
if ((u.id == 0) || (uss.id == 0)) {
proc.mq.add(uin, "Система: Пользователи не найдены");
return;
}
File acu = new File("./text/" + srv.getName() + "/sva/" + i1 + ".txt");
File acu1 = new File("./text/" + srv.getName() + "/sva/" + i2 + ".txt");
if ((!acu.exists()) || (!acu1.exists())) {
proc.mq.add(uin, "Система: Пользователи не были в браке");
return;
}
acu.delete();
acu1.delete();
srv.us.db.event(uss.id, uin, "RAZVOD", u.id, "", "развелись");
srv.cq.addMsg("Система: Пользователи " + uss.localnick + "*IN LOVE*" + uss.id + "*IN LOVE* и " + u.localnick + "*IN LOVE*" + u.id + "*IN LOVE* развелись!", u.sn, u.room);
srv.cq.addMsg("Система: Пользователи " + uss.localnick + "*IN LOVE*" + uss.id + "*IN LOVE* и " + u.localnick + "*IN LOVE*" + u.id + "*IN LOVE* развелись!", uss.sn, uss.room);
proc.mq.add(uin, "Священник: Брак распался...");
} catch (Exception ex) {
ex.printStackTrace();
proc.mq.add(uin, "Ошибка " + ex.getMessage());
}
}
/**
* Покупка смаила
* Автор bezzzdelnick
*/
public void commandSmailik(IcqProtocol proc, String uin, Vector v, String mmsg) {
int s = (Integer)v.get(0); // набранное число
Users uss = srv.us.getUser(uin);
if(uss.room!=7)
{
proc.mq.add(uin,"Система: Магазин в (7) комнате - " + srv.us.getRoom(7).getName() + "");
return;
}
if(uss.zoloto < 500)
{
proc.mq.add(uin,"Система: Ваш баланс: (" + uss.zoloto + "), не достаточно средств для покупки смаила.");
return;
}
String smail = "";
switch (s){
case 1:
smail = "O:-)";
break;
case 2:
smail = ":-)";
break;
case 3:
smail = ":-(";
break;
case 4:
smail = ";-)";
break;
case 5:
smail = ":-P";
break;
case 6:
smail = "8-)";
break;
case 7:
smail = ":-D";
break;
case 8:
smail = ":-[";
break;
case 9:
smail = "=-O";
break;
case 10:
smail = ":-*";
break;
case 11:
smail = ":'(";
break;
case 12:
smail = ":-X";
break;
case 13:
smail = ">:o";
break;
case 14:
smail = ":-|";
break;
case 15:
smail = ":-/";
break;
case 16:
smail = "*JOKINGLY*";
break;
case 17:
smail = "]:->";
break;
case 18:
smail = "[:-}";
break;
case 19:
smail = "*KISSED*";
break;
case 20:
smail = ":-!";
break;
case 21:
smail = "*TIRED*";
break;
case 22:
smail = "*STOP*";
break;
case 23:
smail = "*KISSING*";
break;
case 24:
smail = "@}->--";
break;
case 25:
smail = "*THUMBS UP*";
break;
case 26:
smail = "*DRINK*";
break;
case 27:
smail = "*IN LOVE*";
break;
case 28:
smail = "@=";
break;
case 29:
smail = "*HELP*";
break;
case 30:
smail = "%)";
break;
case 31:
smail = "*OK*";
break;
case 32:
smail = "*WASSUP*";
break;
case 33:
smail = "*SORRY*";
break;
case 34:
smail = "*BRAVO*";
break;
case 35:
smail = "*ROFL*";
break;
case 36:
smail = "*PARDON*";
break;
case 37:
smail = "*NO*";
break;
case 38:
smail = "*CRAZY*";
break;
case 39:
smail = "*DONT_KNOW*";
break;
case 40:
smail = "*DANCE*";
break;
case 41:
smail = "*YAHOO*";
break;
case 42:
smail = "*HI*";
break;
case 43:
smail = "*BYE*";
break;
case 44:
smail = "*YES*";
break;
case 45:
smail = ";D";
break;
case 46:
smail = "*WALL*";
break;
case 47:
smail = "*WRITE*";
break;
case 48:
smail = "*SCRATCH*";
break;
case 49:
smail = "\\m/";
break;
default:
proc.mq.add(uin,"(1) - O:-) (2) - :-) (3) - :-( (4) - ;-) (5) - :-P (6) - 8-) (7) - :-D (8) - :-[ (9) - =-O (10) - :-* (11) - :'( (12) - :-X (13) - >:o (14) - :-| (15) - :-\\ (16) - *JOKINGLY* (17) - ]:-> (18) - [:-} (19) - *KISSED* (20) - :-! (21) - *TIRED* (22) - *STOP* (23) - *KISSING*(24) - @}->-- (25) - *THUMBS UP* (26) - *DRINK* (27) - *IN LOVE* (28) - @= (29) - *HELP* (30) - %) (31) - *OK* (32) - *WASSUP* (33) - *SORRY* (34) - *BRAVO* (35) - *ROFL* (36) - *PARDON* (37) - *NO* (38) - *CRAZY* (39) - *DONT_KNOW* (40) - *DANCE* (41) - *YAHOO* (42) - *HI* (43) - *BYE* (44) - *YES* (45) - ;D (46) - *WALL* (47) - *WRITE* (48) - *SCRATCH* (49) - \\m/");
return;
}
int gold = uss.zoloto-500;
uss.zoloto=gold;
srv.cq.addMsg("Лавочник: [ID=" + uss.id + "] " + uss.localnick + " купил(а) в ник смаил: " + smail + ".", uss.sn, uss.room);
String nicks = uss.localnick + "" + smail;
uss.localnick=nicks;
srv.us.updateUser(uss);
srv.us.db.event(uss.id, uin, "REG", 0, "", nicks);
proc.mq.add(uin,"Лавочник: Покупка успешно завершена, ваш баланс: " + uss.zoloto + " золотых.");
}
/**
* !магазин
* Автор bezzzdelnick
*/
public void commandMagazin(IcqProtocol proc, String uin, Vector v, String mmsg) {
   Users uss = srv.us.getUser(uin);
    if(uss.room!=7)
{
proc.mq.add(uin,"Система: Магазин в (7) комнате - " + srv.us.getRoom(7).getName() + "");
return;
}
proc.mq.add(uin,"Добро пожаловать в наш игровой магазин.\n" +
"У нас в наличии есть 5 команд.\n"+
"!должность (номер) - покупка должности\n" +
"!смайлик (номер) - покупка смаила в ник(стоимость 500 золотых)\n" +
"!купить (номер) (название) - купить комнату(стоимость 10000 золотых)\n" +
"!оружие (кол-во) - купить оружие(1=500 золотых)\n" +
"!защита (кол-во) - купить защиту против оружия(1=500 золотых)\n" +
"(C)BEZZZDELNICK CORPORATION\n");
}
/**
* !свадьбы
* Автор bezzzdelnick
*/
public void commandSvadbaHist(IcqProtocol proc, String uin) {
    if ((!isChat(proc, uin)) && (!psp.testAdmin(uin))) return;
    if (!auth(proc, uin, "svadba_razvod")) return; try
    {
      proc.mq.add(uin, srv.us.getSvadbaHist());
    } catch (Exception ex) {
      ex.printStackTrace();
      proc.mq.add(uin, ex.getMessage());
    }
  }
/**
* разводы
* Автор bezzzdelnick
*/
  public void commandRazvodHist(IcqProtocol proc, String uin) {
    if ((!isChat(proc, uin)) && (!psp.testAdmin(uin))) return;
    if (!auth(proc, uin, "svadba_razvod")) return; try
    {
      proc.mq.add(uin, srv.us.getRazvodHist());
    } catch (Exception ex) {
      ex.printStackTrace();
      proc.mq.add(uin, ex.getMessage());
    }
  }
  /**
* чит
* Автор bezzzdelnick
*/
public void commandChit(IcqProtocol proc, String uin, Vector v, String mmsg) {
int s = (Integer)v.get(0);
Users uss = srv.us.getUser(uin);
switch (s){
case 1:
proc.mq.add(uin,"--------\n1) *НЕВИДИМОСТЬ*\n--------\nвы можете стать невидимым,смотреть список невидимок.\n!спрятаться,!показаться,!невидимки.\nвас невидно по запросу +тут и +все.\n--------\n(с)BEZZZDELNICK CORPORATION");
break;
case 2:
proc.mq.add(uin,"--------\n2) *СТАВКА*\n--------\nделаите ставки и выигрываите.\nугадать цвет вернуть 50% ставки.\nугадать число выиграть двоиную ставку.\nугадать число и цвет ваш выигрыш увеличиться в 2 раз от ставки.\n--------\n(c)BEZZZDELNICK CORPORATION");
break;
case 3:
proc.mq.add(uin,"--------\n3) *РУЛЕТКА*\n--------\nв русской рулетке нужно стараться писать число чтоб\nоно не совпало с числом системы.\nесли число совпадает то вас выкинет из чата на время от 0 до 60 минут.\nесли число не совпало то вы получаете 5 золотых.\n--------\n(c)BEZZZDELNICK CORPORATION");
break;
case 4:
proc.mq.add(uin,"--------\n4) *РЫЧАГ*\n--------\nсмысл игры ,при совпадении 2 чисел вы получаете 100 золотых.\nесли все 3 комбинации пральны то вы получаете 600 золотых.\nза каждый раз набрав команды у вас онимают 50 золотых, даже если вы выиграли.\n--------\n(c)BEZZZDELNICK CORPORATION");
break;
case 5:
proc.mq.add(uin,"--------\n5) *НАПЕРСТКИ*\n--------\nвы должны угадать наперсток под которым шарик.\nв игре три наперстка,ставить можно от 10 до 1000 золотых.\nпри верном ответе вы получаете двоиную ставку.\nпример: !наперстки 2 500\n----------\n(с)BEZZZDELNICK CORPORATION");
break;
case 6:
proc.mq.add(uin,"--------\n6) *КАЗИНО*\n-------\nсмысл игры везение если совпадают три цифры в ячеиках\nнапример (500)(500)(500) то ваш выигрыш равен числу в ячеике.\nв данном случае это 500 - золотых\n----------\n(с)BEZZZDELNICK CORPORATION");
break;
case 7:
proc.mq.add(uin,"-------\n7) *ГОЛОСОВАНИЕ И АВТОРИТЕТ*\n-------\nвы можете раз в тридня отдать свои голос за наиболее\nдостоиного юзера,каждыи ваш голос добавляет авторитет юзеру.\nавторитет можно как повышать так и понижать.\nставя + или - обдумываите ,от вас зависит сможет ли юзер стать \nмодером или админом.\nнабрав минусовои авторитет админ или модер лишаеться должности.\n----------\n(с)BEZZZDELNICK CORPORATION");
break;
case 8:
proc.mq.add(uin,"-------\n8) *доп оружие*\n------\n!заморозка <ID> - замораживает на 3 минуты.\n!ледомет <ID> - замораживает охрану.\n!огнемет <ID> - выжигает охрану.\nОгненый щит - Спасает от ледомета.\nЛедяной щит - спасает от огнемета.\nСтальнои щит - спасает от заморозки.\nвы в любои момент можете сменить оружие.\n*Секретное оружие*\nдоступно для юзеров с уровнем более 1000\n!базука - урон 50 расход заряда 5.\nтитановый щит расход брони 5 \nспасает от базуки.\n----------\n(с)BEZZZDELNICK CORPORATION");
break;
case 9:
proc.mq.add(uin,"------\n9) *НАПАСТЬ*\n------\nвы также можете грабить деньги у других пользователей\nдля этого нужно насколько максимальна преступность\nчтобы наносить максимальный урон\nнападать можно только в 5 7 и 12 комнатах.\n----------\n(с)BEZZZDELNICK CORPORATION");
break;
case 10:
proc.mq.add(uin,"------\n10) *ДОЛЖНОСТЬ*\n------\nвы также можете покупать должность в нашем чате\nно есть одно но...\nчтобы купить определенную должность у вас должно быть\nопределенное кол-во авторитета и преступности.\n----------\n(с)BEZZZDELNICK CORPORATION");
break;
case 11:
proc.mq.add(uin,"------\n11) *КОСТИ*\n------\nИгра на везение. \nСистема сама за вас подбирает числа\nесли ваши числа в сумме будут больше чем у системы.\nто вы выигрываете 50 золотых.\nесли нет,то отдаете.\n----------\n(с)BEZZZDELNICK CORPORATION");
break;
case 12:
proc.mq.add(uin,"------\n12) *СМАИЛИК*\n------\nНекоторые юзеры хотят поставить в ник смаилик.\nНо этого не получиться.\nт.к. система эти смаилы точнее только ихнию часть убирает.\nчтобы поставить смаил в ник его нужно купить в магазине.\n----------\n(с)BEZZZDELNICK CORPORATION");
break;
case 13:
proc.mq.add(uin,"------\n13) *ОХРАНА*\n------\nохрана нужна для того чтобы защитить свои золотые\nот злостных юзеров.\nони всегда будут пытаться украсть у вас деньги.\nно если у вас золотых ставноиться больше чем 500\nто вам нужно купить охрану.\n----------\n(с)BEZZZDELNICK CORPORATION");
break;
case 14:
proc.mq.add(uin,"------\n14) *МИЛЛИОНЕР*(в доработке)\n------\nИгра по мотивам всем известной телепередачи\nкто хочет стать миллионерам.\n----------\n(с)BEZZZDELNICK CORPORATION");
break;
default:
proc.mq.add(uin,"Правила и прохождения игр от (30|07|2010) mod by bezzzdelnick\n-----------------\n1) *НЕВИДИМОСТЬ*\n--------\n2) *СТАВКА*\n--------\n3) *РУЛЕТКА*\n--------\n4) *РЫЧАГ*\n--------\n5) *НАПЕРСТКИ*\n--------\n6) *КАЗИНО*\n-------\n7) *ГОЛОСОВАНИЕ И АВТОРИТЕТ*\n-------\n8) *доп оружие*\n------\n9) *НАПАСТЬ*\n------\n10) *ДОЛЖНОСТЬ*\n------\n11) *КОСТИ*\n------\n12) *СМАИЛИК*\n------\n13) *ОХРАНА*\n------\n14) *МИЛЛИОНЕР*(в доработке)\n----------\n(с)BEZZZDELNICK CORPORATION");
return;
}
}
/**
* спрятаться
* Автор bezzzdelnick
*/
  public void commandInvise(IcqProtocol proc, String uin) {
    if ((!isChat(proc, uin)) && (!psp.testAdmin(uin))) return;
    if (!auth(proc, uin, "invise")) return; try
    {
      Users u = srv.us.getUser(uin);
      srv.us.grantUser(u.id, "invisible");
      proc.mq.add(uin, "Система: Вы спрятались.");
    } catch (Exception ex) {
      ex.printStackTrace();
      proc.mq.add(uin, "Ошибка " + ex.getMessage());
    }
  }
  /**
* скрылись
* Автор bezzzdelnick
*/
  public void commandScrilis(IcqProtocol proc, String uin) {
    if (!auth(proc, uin, "invise")) return;
    try
    {
      String lst = "";
      Enumeration e = srv.cq.uq.keys();
      while (e.hasMoreElements()) {
        String i = (String)e.nextElement();
        Users us = srv.us.getUser(i);
        if ((srv.us.authorityCheck(us.id, "invisible")) && (us.state == 2)) {
          lst = lst + "[ID=" + us.id + "] - " + us.localnick + " (" + us.room + ")" + "\n";
        }
      }
      proc.mq.add(uin, "[ид=  ] - ник (комната)\n" + lst);
    } catch (Exception ex) {
      ex.printStackTrace();
      proc.mq.add(uin, "Ошибка " + ex.getMessage());
    }
  }
/**
* показаться
* Автор bezzzdelnick
*/
  public void commandUinvise(IcqProtocol proc, String uin) {
    if ((!isChat(proc, uin)) && (!psp.testAdmin(uin))) return;
    if (!auth(proc, uin, "invise")) return; try
    {
      Users u = srv.us.getUser(uin);
      srv.us.revokeUser(u.id, "invisible");
      proc.mq.add(uin, "Система: Вы показались.");
    } catch (Exception ex) {
      ex.printStackTrace();
      proc.mq.add(uin, "Ошибка " + ex.getMessage());
    }
  }
  private void newQuestion(IcqProtocol proc, String uin, int level)
  {
    if (level < 1) level = 1;
    if (level > 15) level = 15;
    String s = "Внимание, вопрос №" + level + ":\n";
    Questions quest = getQuestion(level);

    String[] answers = quest.getAnswers().split(";");
    s = s + quest.getQuestion() + "\n";
    for (int i = 0; i < answers.length; ++i) {
      s = s + Integer.toString(i + 1) + ") " + answers[i] + "\n";
    }
    s = s + "Время на раздумье 3 минуты";

    proc.mq.add(uin, s);
    this.gameMap.put(uin, new GameExtend(uin, quest, level, 180000L));
  }

  public void commandGame(IcqProtocol proc, String uin, Vector v)
  {
    if ((!isChat(proc, uin)) && (!psp.testAdmin(uin))) return;
    if (!auth(proc, uin, "game")) return;
    String p1 = (String)v.get(0);
    String p2 = (String)v.get(1);

    if (srv.us.getUser(uin).room != psp.getIntProperty("game.millionroom")) {
      proc.mq.add(uin, "Система: Игра \"Кто хочет стать миллионером\" в (" + psp.getIntProperty("game.millionroom") + ") комнате -"  + srv.us.getRoom(psp.getIntProperty("game.millionroom")).getName());
      return;
    }
    if (!this.gameMap.containsKey(uin)) {
      if (this.srv.us.getCountGame(srv.us.getUser(uin).id) > psp.getIntProperty("game.maxGameCount")) {
        proc.mq.add(uin, "Система: Вы не можете играть больше " + psp.getIntProperty("game.maxGameCount") + " раз в день");
        return;
      }
        if ((p1.equalsIgnoreCase("new")) || (p1.equalsIgnoreCase("вход"))) {
          this.srv.us.db.event(this.srv.us.getUser(uin).id, uin, "GAME", 0, "", "начал игру");
          proc.mq.add(uin, "Система: Игра началась.");
          newQuestion(proc, uin, 1);
          return;
        }

    if ((p1.equals("new")) || (p1.equalsIgnoreCase("вход"))) {
      proc.mq.add(uin, "Система: Игра уже идет. Вы не можете начать новую игру.");
      return;
    }
    int answer = 0;
    try
    {
      answer = Integer.parseInt(p1);
    } catch (NumberFormatException e) {
      proc.mq.add(uin, "Система: Ошибка в команде");
      return;
    }
    if (checkanswer(proc, uin, answer))
      newQuestion(proc, uin, ((GameExtend)this.gameMap.get(uin)).getLevel() + 1);
  }
    }

  public void commandAnswer(IcqProtocol proc, String uin, Vector v)
  {
    if (!this.gameMap.containsKey(uin)) {
      proc.mq.add(uin, "Система: Вы еще не начали новую игру.");
      return;
    }
    if (this.srv.us.getUser(uin).room != this.psp.getIntProperty("game.millionroom")) {
proc.mq.add(uin, "Система: Игра \"Кто хочет стать миллионером\" в (" + psp.getIntProperty("game.millionroom") + ") комнате -"  + srv.us.getRoom(psp.getIntProperty("game.millionroom")).getName());
      return;
    }
    String p1 = (String)v.get(0);

    int answer = 0;
    try
    {
      answer = Integer.parseInt(p1);
    } catch (NumberFormatException e) {
      proc.mq.add(uin, "Ошибка в команде");
      return;
    }

    if (checkanswer(proc, uin, answer))
      newQuestion(proc, uin, ((GameExtend)this.gameMap.get(uin)).getLevel() + 1);
  }

  public boolean checkanswer(IcqProtocol proc, String uin, int answer)
  {
    if (((GameExtend)this.gameMap.get(uin)).isExpire()) {
      proc.mq.add(uin, "Система: Вы не уложились в отведенное время. Игра окончена.");
      proc.mq.add(uin, "Система: У вас золотых: (" + srv.us.getUser(uin).zoloto + ")");
      this.gameMap.remove(uin);
      return false;
    }
    if (!((GameExtend)this.gameMap.get(uin)).getQuestion().checkCorrectAnswer(answer)) {
      proc.mq.add(uin, "Система: Вы не правильно ответили на вопрос. Игра окончена.");
   proc.mq.add(uin, "Система: У вас золотых: (" + srv.us.getUser(uin).zoloto + ")");
      this.gameMap.remove(uin);
      return false;
    }

    proc.mq.add(uin, "Система: Поздравляю, вы правильно ответили на поставленный вопрос!");

    if ((((GameExtend)this.gameMap.get(uin)).getLevel() == 5) || (((GameExtend)this.gameMap.get(uin)).getLevel() == 10)) {
      proc.mq.add(uin, "Система: Несгораемая сумма. Вы набрали " + ((GameExtend)this.gameMap.get(uin)).getLevel() + " золотых");
      this.srv.us.getUser(uin).zoloto += 5000;
      this.srv.us.updateUser(this.srv.us.getUser(uin));
    }

    if (((GameExtend)this.gameMap.get(uin)).getLevel() == 15) {
      proc.mq.add(uin, "Система: Поздравляю, вы правильно ответили на все вопросы!\nИгра окончена.");
      this.srv.us.getUser(uin).zoloto += 10000000;
      this.gameMap.remove(uin);
      this.srv.us.updateUser(this.srv.us.getUser(uin));
      proc.mq.add(uin, "Система: У вас золотых: (" + srv.us.getUser(uin).zoloto + ")");
      return false;
    }
    return true;
  }

  public Questions getQuestion(int level) {
    Random r = new Random();
    Questions quest;
    do
      quest = this.srv.us.getQuestions(r.nextInt(this.srv.us.getCountQuestions()) + 1);
    while (quest.getDifficultyLevel() != level);

    return quest;
  }
   public void commandMoroz(IcqProtocol proc, String uin, Vector v){
if ((!(isChat(proc, uin))) && (!(psp.testAdmin(uin)))) {return;}
if (!(auth(proc, uin, "zamorozka"))) {return;}
int i1 = ((Integer)v.get(0)).intValue();
Users us = srv.us.getUser(i1);
Users uss = srv.us.getUser(uin);
if(us.id==0)
{
proc.mq.add(uin,"Ошибка: Такой пользователь ещё не зарегистрировался в чате.");
return;
}
if(us.room!=uss.room)
{
proc.mq.add(uin,"Система: Ты должен быть в одной комнате с тем, на кого нападаешь.");
return;
}
if (us.icetime>System.currentTimeMillis()){
proc.mq.add(uin,"Система: Дождитесь окончания таимера предыдущей заморозки.");
return;
}
if(!uss.nazorujie.equals("Заморозка"))
{
proc.mq.add(uin,"Система: У тебя " + uss.nazorujie + ", а надо чтоб была Заморозка");
return;
}
if(us.state!=UserWork.STATE_CHAT)
{
proc.mq.add(uin,"Система: Этого пользователя нет в чате.");
return;
}
if (uss.orujie<=0) {
proc.mq.add(uin,"Ошибка: У Вас нет оружия! Купите его с помощью команды !оружие");
return;
}
uss.orujie--;
if (us.nazzachita.equals("Стальной щит") && us.zachita>0) {
us.zachita--;
srv.us.updateUser(uss);
srv.getIcqProcess(us.basesn).mq.add(us.sn,"Система: Вас пытались заморозить, но Вас спас Стальной щит, у вас осталось: (" + us.zachita + ") Стальных щитов.");
proc.mq.add(uin,"Система: У [ID="+us.id+"] "+us.localnick+" есть Стальной щит. Нападение не удалось!");
return;
}
int ztime = 3; //Время заморозки в минутах
us.icetime = System.currentTimeMillis() + ztime*60000;
srv.us.updateUser(us);
srv.getIcqProcess(us.basesn).mq.add(us.sn,"Система: Тебя заморозил(а): [ID=" + uss.id + "] " + uss.localnick + ", на "+ztime+" минуты.");
proc.mq.add(uin,"Система: Заморозка активирована.");
}

public void commandStavka(IcqProtocol proc, String uin, Vector v)
  {
    if ((!isChat(proc, uin)) && (!psp.testAdmin(uin))) return;
    if (!auth(proc, uin, "europe")) return;
      int stavka = ((Integer)v.get(0)).intValue();
      int num = ((Integer)v.get(1)).intValue();
      String rez = (String)v.get(2);
      Users uss = srv.us.getUser(uin); {
long t = System.currentTimeMillis();
if (t-uss.napadtime<30000) {
proc.mq.add(uin,"Система: Пауза между запросами 30 сек...");
return;
        }
if(uss.room!=12)
{
proc.mq.add(uin,"Система: Игровая в (12) комнате - " + srv.us.getRoom(12).getName());
return;
}
      String[][] chg = { { "0", "ZERRO" }, { "32", "красное" }, { "15", "черное" }, { "19", "красное" }, { "4", "черное" }, { "21", "красное" }, { "2", "черное" }, { "25", "красное" }, { "17", "черное" }, { "34", "красное" }, { "6", "черное" }, { "27", "красное" }, { "13", "черное" }, { "36", "красное" }, { "11", "черное" }, { "30", "красное" }, { "8", "черное" }, { "23", "красное" }, { "10", "черное" }, { "5", "красное" }, { "24", "черное" }, { "16", "красное" }, { "33", "черное" }, { "1", "красное" }, { "20", "черное" }, { "14", "красное" }, { "31", "черное" }, { "9", "красное" }, { "22", "черное" }, { "18", "красное" }, { "29", "черное" }, { "7", "красное" }, { "28", "черное" }, { "12", "красное" }, { "35", "черное" }, { "3", "красное" }, { "26", "черное" } };
      int i = (int)(Math.random() * chg.length);
      if ((stavka == 0) || (num == 0)) {
        proc.mq.add(uin, "Крупье: не указан параметр. Наберите !ставка сумма число");
        return;
      }
      if (uss.zoloto < stavka) {
        proc.mq.add(uin, "Крупье: ваш баланс: " + uss.zoloto + " " + psp.getStringProperty("valuta.chat") + " , у вас недостаточно средств для игры.");
        return;
      }
      if ((stavka < 500) || (stavka > 1000000)) {
        proc.mq.add(uin, "Крупье: минимальная ставка (500) максимальная (1000000)");
        return;
      }
      if (num > chg.length) {
        proc.mq.add(uin, "Крупье: на нашеи рулетке нет таких чисел.");
        return;
      }
      int b = Integer.parseInt(chg[i][0]);
      if ((b == 0) && (chg[i][1].equals("ZERRO"))) {
        proc.mq.add(uin, "Крупье: \"ZERRO\" ставка не изменилась.");
        return;
      }

      if ((b == num) && (chg[i][1].equals(rez))) {
        int itog = stavka * 2;
        int gold = uss.zoloto + itog;
        uss.zoloto = gold;
        srv.us.updateUser(uss);
        uss.gametime=t;
srv.us.updateUser(uss);
        proc.mq.add(uin, "Крупье: выпало \"" + chg[i][0] + " " + chg[i][1] + "\" ваш выигрыш (" + itog + ")");
        srv.cq.addMsg("Крупье: " + uss.localnick + " делает ставку " + stavka + " на " + num + " " + rez + ", выпало \"" + chg[i][0] + " " + chg[i][1] + "\" выигрыш составил (" + itog + ")", uss.sn, uss.room);
        return;
      }
      if (chg[i][1].equals(rez)) {
        int itog2 = stavka / 2;
        int gold = uss.zoloto + itog2;
        uss.zoloto = gold;
        srv.us.updateUser(uss);
        uss.gametime=t;
srv.us.updateUser(uss);
        proc.mq.add(uin, "Крупье: выпало \"" + chg[i][0] + " " + chg[i][1] + "\" ваш выигрыш (" + itog2 + ")");
        srv.cq.addMsg("Крупье: " + uss.localnick + " делает ставку " + stavka + " на " + num + " " + rez + ", выпало \"" + chg[i][0] + " " + chg[i][1] + "\" выигрыш составил (" + itog2 + ")", uss.sn, uss.room);
        return;
      }
      if (b == num) {
        int itog3 = stavka;
        int gold = uss.zoloto + itog3;
        uss.zoloto = gold;
        srv.us.updateUser(uss);
        uss.gametime=t;
srv.us.updateUser(uss);
        proc.mq.add(uin, "Крупье: выпало \"" + chg[i][0] + " " + chg[i][1] + "\" ваш выигрыш (" + itog3 + ")");
        srv.cq.addMsg("Крупье: " + uss.localnick + " делает ставку " + stavka + " на " + num + " " + rez + ", выпало \"" + chg[i][0] + " " + chg[i][1] + "\" выигрыш составил (" + itog3 + ")", uss.sn, uss.room);
        return;
      }
      int gold = uss.zoloto - stavka;
      uss.zoloto = gold;
      srv.us.updateUser(uss);
      uss.gametime=t;
srv.us.updateUser(uss);
      proc.mq.add(uin, "Крупье: выпало \"" + chg[i][0] + " " + chg[i][1] + "\" вы проиграли.");
      srv.cq.addMsg("Крупье: " + uss.localnick + " делает ставку " + stavka + " на " + num + " " + rez + ", выпало \"" + chg[i][0] + " " + chg[i][1] + "\", " + stavka + " уходит в пользу чата.", uss.sn, uss.room);
      return;
    }
  }


public void commandUin(IcqProtocol proc, String uin, Vector v) {
if(!isChat(proc,uin)) return;
if(!auth(proc,uin, "uin")) return;
    int no = (Integer)v.get(0);
    Users uss = srv.us.getUser(no);
             if(uss == null){
                 proc.mq.add(uin,"Система: Такого пользователя не существует в нашем чате.");
                 return;
             }
             if(!srv.cq.testUser(uss.sn)){
                 proc.mq.add(uin,"Система: Пользователь сейчас не в чате");
                 return;
    }
     srv.getIcqProcess(uss.basesn).mq.add(uss.sn,"Система: Пользователь " + srv.us.getUser(uin).localnick + " оставил вам свой номер Аси и попросил чтобы вы ему написали вот сюда: (uin: " + srv.us.getUser(uin).sn + ")");
     proc.mq.add(uin,"Система: Ваше секретное сообщение успешно отправлено куда надо.");
}
  public void commandZat(IcqProtocol proc, String uin, Vector v, String mmsg)
  {
    if ((!isChat(proc, uin)) && (!this.psp.testAdmin(uin))) return;
    if (!auth(proc, uin, "uchat")) return; try
    {
      int id = ((Integer)v.get(0)).intValue();
      String prichina = (String)v.get(1);
      Users uss = srv.us.getUser(uin);
      if (id == 0) {
        proc.mq.add(uin, "Система: Нет такого пользователя.");
        return;
      }
      Users us = srv.us.getUser(id);
      if (us.id == 0) {
        proc.mq.add(uin, "Система: Пользователь не найден.");
        return;
      }
      if (us.state == 2) {
        proc.mq.add(uin, "Система: Пользователь уже в чате.");
        return;
      }
      if (us.state == -1) {
        proc.mq.add(uin, "Система: Нельзя затащить забаненого пользователя.");
        return;
      }
      goChat(srv.getIcqProcess(us.basesn), us.sn);
      if (floodMap.containsKey(us.sn)) {
        FloodElement e = (FloodElement)floodMap.get(us.sn);
        e.addMsg("!чат");
        this.floodMap.put(us.sn, e);
      } else {
        FloodElement e = new FloodElement(psp.getIntProperty("chat.floodTimeLimit") * 1000);
        e.addMsg("!чат");
        floodMap.put(us.sn, e);
      }
      srv.getIcqProcess(us.basesn).mq.add(us.sn, "Система: Тебя затащил(а) в чат пользователь " + uss.localnick + " [ID=" + uss.id + "], за: " + prichina + ".");
      proc.mq.add(uin, "Система: Пользователь " + us.localnick + " [ID=" + us.id + "] затащен в чат.");
    srv.cq.addMsg("", uss.sn, uss.room);
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }
public void commandForOwner(IcqProtocol proc, String uin){
   String s = psp.loadText("./text/help3.txt");
     String[] ss = s.split("<br>");
     for(int i=0;i<ss.length;i++){
          proc.mq.add(uin,ss[i]);
     }
    }
/**
* Запоминание источника нового входящего сообщения
*/
private void setPM(String sn, String from_sn){
up.put(sn,from_sn);
}

 public String testNick(String sn, String nick){
        if (psp.testAdmin(sn)) return nick; // Админам можно любой ник
        String[] ss = psp.getStringProperty("chat.badNicks").split(";");
        String nick1 = radm.changeChar(nick.toLowerCase()).toLowerCase();
        String nickLower = nick.toLowerCase();
        for (int i=0;i<ss.length;i++) {
            if (nickLower.indexOf(ss[i])>=0 || nick1.indexOf(ss[i])>=0) return null;
        }
        String s = psp.getStringProperty("chat.badSymNicks");
        Log.talk("Недопустимые символы: "+s);
        for (int i=0; i<s.length(); i++){
            nick=nick.replace(Character.toString(s.charAt(i)),"");
        }
        if (nick.length()==0) return null;
        return nick;
    }
/**
* Вывод списка объектов полномочий
*/
public String listAuthObjects(){
String s="Объекты полномочий:\n";
for(String c:authObj.keySet()){
s += c + " - " + authObj.get(c)+"\n";
}
//        for(int i=0;i<AUTH_OBJECTS.length;i++){
//            s += AUTH_OBJECTS[i][0] + " - " + AUTH_OBJECTS[i][1] + "\n";
//        }
return s;
}

/**
* Проверка объекта на наличие в списке
*/
public boolean testAuthObject(String tst){
return authObj.containsKey(tst);
//        for(int i=0;i<AUTH_OBJECTS.length;i++){
//            if(tst.equals(AUTH_OBJECTS[i][0])) return true;
//        }
//        return false;
}

/**
* Есть такая группа?
* @param tst
* @return
*/
public boolean testUserGroup(String tst){
String[] ss = psp.getStringProperty("auth.groups").split(";");
for(int i=0;i<ss.length;i++){
if(tst.equals(ss[i])) return true;
}
return false;
}

/**
* Проверка юзера, кикнут ли он
*/
public int testKick(String sn){
long tc = srv.us.getUser(sn).lastKick;
long t = System.currentTimeMillis();
return tc>t ? (int)(tc-t)/60000 : 0;
}
/**
* Кик юзера по времени
*/
public void setKick(String sn, int min, int user_id, String r){
Users u = srv.us.getUser(sn);
if(statKick.containsKey(sn)){
KickInfo ki = statKick.get(sn);
ki.moder_id = user_id;
ki.reason = r;
ki.inc();
statKick.put(sn, ki);
} else {
KickInfo ki = new KickInfo(u.id, user_id, r, min);
statKick.put(sn, ki);
}
u.lastKick = System.currentTimeMillis() + min*60000;
srv.us.updateUser(u);
}

/**
* Список юзеров в состоянии кика
*/
public String listKickUsers(){
String r=Messages.getString("ChatCommandProc.listKickUsers.0") + "\n";
r += Messages.getString("ChatCommandProc.listKickUsers.1") + "\n";
for(Users u:srv.us.getKickList()){

r += ">>" + u.id + "-" + u.localnick + "; [" + (new Date(u.lastKick)).toString() + "]; " +
(u.lastKick-System.currentTimeMillis())/60000 + "; ";
if(statKick.containsKey(u.sn)){
KickInfo ki = statKick.get(u.sn);
if(ki.moder_id==0)
r += "0-Admin";
else
r += ki.moder_id + "-" + srv.us.getUser(ki.moder_id).localnick;
r += "; " + ki.reason + "\n";
} else 
r += '\n';
}
return r;
} 

/**
* Парсер сообщений о смене статусов
*/
public void parseStatus(IcqProtocol proc, String uin, int status) {
try{
} catch (Exception ex) {}
if(!srv.us.testUser(uin)) return; //Если в КЛ занесены посторонние юзеры
if(status>=0){
if(srv.cq.testUser(uin)) return;
if(srv.us.getUser(uin).state == UserWork.STATE_OFFLINE) 
goChat(proc, uin);
else
return; // Если вдруг он по ошибке оказался в КЛ
} else {
if(!srv.cq.testUser(uin)) return;
tempExitChat(proc, uin);
}
}

/**
* Парсер сообщений после запроса инфы юзера
*/
public void parseInfo(Users u, int type){
switch(type) {
case 1: // Основная инфа
Log.info("User: " + u.sn + ", " + u.nick);
Users uu = srv.us.getUser(u.sn);
uu.sn = u.sn;
uu.nick = u.nick;
uu.fname = u.fname;
uu.lname = u.lname;
uu.email = u.email;
srv.us.updateUser(uu);
break;
default:
}
}

/**
* Проверка молчунов
* @param uin
*/
public void testState(String uin){
long t = floodMap.get(uin).getDeltaTime();
if(t>(psp.getIntProperty("chat.autoKickTimeWarn")*60000) &&
!warnFlag.contains(uin)){
Log.info("Warning to " + uin);
//            srv.getIcqProcess(srv.us.getUser(uin).basesn).mq.add(uin,"Предупреждение! Вы слишком долго молчите и будете удалены из чата");
srv.getIcqProcess(srv.us.getUser(uin).basesn).mq.add(uin,"Предупреждение! Хватит молчать либо вы будете удалены из чата");
warnFlag.add(uin);
}
if(t>(psp.getIntProperty("chat.autoKickTime")*60000)){
Log.talk("Autokick to " + uin);
warnFlag.remove(uin);
kick(srv.getIcqProcess(srv.us.getUser(uin).basesn),uin);
}
}

/**
* Юзер - главный админ?
* @param proc
* @param uin
* @return
*/
public boolean isAdmin(IcqProtocol proc, String uin){
if(!psp.testAdmin(uin)){
//            proc.mq.add(uin,"Вы не имеете доступа к данной команде.");
proc.mq.add(uin,Messages.getString("ChatCommandProc.auth.0"));
return false;
}
return true;
}

/**
* Проверка полномочий
* @param proc
* @param uin
* @param obj
* @return
*/
public boolean auth(IcqProtocol proc, String uin, String obj){
if (srv.us.getUser(uin).icetime>System.currentTimeMillis()) {
    proc.mq.add(uin, "Система: Вы заморожены.");
    return false;
}
if(!srv.us.authorityCheck(uin, obj)){
proc.mq.add(uin,"Система: Вы не имеете доступа к данной команде.");
return false;
}
return true;
}
/**
* Тихая проверка полномочий. Не выводит сообщений.
* @param proc
* @param uin
* @param obj
* @return
*/
public boolean qauth(IcqProtocol proc, String uin, String obj){
if(!srv.us.authorityCheck(uin, obj)){
return false;
}
return true;
}


/**
* Вход в чат
* @param proc
* @param uin
*/
public void goChat(IcqProtocol proc, String uin) {
Users uss = srv.us.getUser(uin);
boolean f = false;
if(uss.localnick==null || uss.localnick.equals("") || uss.state==UserWork.STATE_NO_REG) {
proc.mq.add(uin,"Система: Прежде чем войти в чат, необходимо зарегистрироваться.");
return;
}
if (uss.state==UserWork.STATE_CHAT) return; //Юзер уже в чате
if (uss.state==UserWork.STATE_NO_CHAT) {
Log.info("Add contact " + uin);
if(proc.isNoAuthUin(uin)) proc.mq.add(uin, Messages.getString("ChatCommandProc.goChat.1"), 2);
proc.addContactList(uin);
uss.state = UserWork.STATE_CHAT;
uss.basesn = proc.baseUin;
srv.us.updateUser(uss);
srv.cq.addMsg("" + uss.localnick + "[ID = " + uss. id + "] причапал(а) к нам в чатик*YAHOO*! Всем привет,типа8-)", uss.sn, uss.room);
proc.mq.add(uin, "" + uss.localnick + " Добро пожаловать в наш игровой чат.*YAHOO* Приятного Вам общения.*HI*  Ваш [ID=" + uss.id + "] Тема: "+srv.us.getRoom(uss.room).getTopic());
String pm = "";
if (srv.us.CountPM(uss.id)!=0)proc.mq.add(uin,"Печкин: У вас имеется " + srv.us.CountPM(uss.id) + " не прочитанных сообщений, чтобы увидеть их, отправьте команду !почта");
String s=psp.getStringProperty("chat.news");
s=s.replace(";","\n-------\n");
proc.mq.add(uin, "Новости: "+s);
f = true;
}
if (uss.state==UserWork.STATE_OFFLINE) {
uss.state = UserWork.STATE_CHAT;
uss.basesn = proc.baseUin;
srv.us.updateUser(uss);
proc.mq.add(uin,"" + uss.localnick + " Ты вошел в тестовый чат, твой ид = |" + uss.id + "|, лучше выйди и не мешай;-если хош общаться сиди и тусуйся в 0 комнате;-)");
if(psp.getBooleanProperty("chat.showChangeUserStatus"))
srv.cq.addMsg("" + uss.localnick + "[ID = " + uss. id + "] причапал(а) к нам в чатик*YAHOO*! Всем привет,типа8-)", uss.sn, uss.room);
}
Log.talk(uss.localnick + "[ID=" +  uss.id  + "] причапал(а) к нам в чатиг. Всем привета, типа8-)");
srv.us.db.log(uss.id,uin,"STATE_IN",uss.localnick + "[ID=" +  uss.id  + "] причапал(а) к нам в чатиг. Всем привета, типа",uss.room);
srv.us.db.event(uss.id, uin, "STATE_IN", 0, "", uss.localnick + "[ID=" +  uss.id  + "] причапал(а) к нам в чатиг. Всем привета, типа");
srv.cq.addUser(uin,proc.baseUin, uss.room);
if(f){
if(srv.us.getCurrUinUsers(uss.basesn)>psp.getIntProperty("chat.maxUserOnUin")){
proc.mq.add(uin,""+ uss.localnick + " Ты вошел в тестовый чат, твой ид = |" + uss.id + "|, лучше выйди и не мешайесли хош общаться сиди и тусуйся в 0 комнате");
String s = srv.us.getFreeUin();
uss.basesn = s;
srv.us.updateUser(uss);
srv.cq.changeUser(uin, s);
proc.mq.add(uin, uss.localnick + " Ты вошел в тестовый чат, твой ид = |" + uss.id + "|, лучше выйди и не мешайесли хош общаться сиди и тусуйся в 0 комнате");
}
}
}

/**
* Выход из чата
* @param proc
* @param uin
*/
public void exitChat(IcqProtocol proc, String uin) {
if (!auth(proc, uin, "exit")) return;
Users uss = srv.us.getUser(uin);
if (uss.state==UserWork.STATE_CHAT ||
uss.state==UserWork.STATE_OFFLINE) {
if(!psp.getBooleanProperty("chat.NoDelContactList")){
Log.info("Delete contact " + uin);
proc.RemoveContactList(uin);
}
} else
return; // Юзера нет в чате - игнорируем команду
uss.state = UserWork.STATE_NO_CHAT;
srv.us.updateUser(uss);
Log.talk(uss.localnick + "[" + uss.id + "] учапал(а) из нашего чатига,пока! чтоли:-(");
srv.us.db.log(uss.id,uin,"STATE_OUT",uss.localnick + "[" + uss.id + "] учапал(а) из нашего чатига,пока! чтоли:-(",uss.room);
srv.us.db.event(uss.id, uin, "STATE_OUT", 0, "", uss.localnick + "[" + uss.id + "] учапал(а) из нашего чатига,пока! чтоли:-(");
srv.cq.addMsg("" + uss.localnick + "[" + uss.id + "] учапал(а) из нашего чатига,пока! чтоли:-(", uss.sn, uss.room);
proc.mq.add(uin,"" + uss.localnick + " [ID = " + uss.id + "] Вы вышли! Удачки, забегайте еще;-)");
String s=psp.getStringProperty("chat.exit");
s=s.replace(";","\n-------\n");
proc.mq.add(uin, "Новости: "+s);
srv.cq.delUser(uin);
}

/**
* Смена базового уина юзера
*/
public void changeBaseUin(String uin, String buin){
Users u = srv.us.getUser(uin);
u.basesn = buin;
srv.us.updateUser(u);
srv.cq.changeUser(uin, buin);
}

/**
* Процедура проверки на срабатывание условий флуда. Включает кик при необходимости
* @param proc
* @param uin
* @return истина, если юзер выпнут за флуд
*/
private boolean testFlood(IcqProtocol proc, String uin){
if(warnFlag.contains(uin)) warnFlag.remove(uin);
if(floodMap.containsKey(uin)){
if(floodMap.get(uin).getCount()>psp.getIntProperty("chat.floodCountLimit")){
akick(proc, uin);
return true;
}
}
if(floodMap2.containsKey(uin)) {
if(floodMap2.get(uin).getCount()>psp.getIntProperty("chat.floodCountLimit")){
akick(proc, uin);
return true;
}
}
return false;
}

/**
* КИК с записью в лог
*/
public void lkick(IcqProtocol proc, String uin, String txt, int id) {
kick(proc, uin);
srv.us.db.log(srv.us.getUser(uin).id,uin,"KICK", txt,srv.us.getUser(uin).room);
srv.us.db.event(srv.us.getUser(uin).id, uin, "KICK", id, "", txt);
}

/**
* КИК с автоматическим определением времени
*/
public void akick(IcqProtocol proc, String uin, int user_id){
int def = psp.getIntProperty("chat.defaultKickTime");
int max = psp.getIntProperty("chat.maxKickTime");
int i=def;
if(statKick.containsKey(uin)){
int t = statKick.get(uin).len;
i = t<max ? t*2 : def;
i = i>max ? max : i;
}
tkick(proc, uin, i, user_id, "");
}

public void akick(IcqProtocol proc, String uin){
akick(proc, uin, 0);
}

/**
* КИК с выставлением времени
*/
public void tkick(IcqProtocol proc, String uin, int t, int user_id, String r){
setKick(uin,t, user_id, r);
Log.talk("kick user " + uin + " on " + t + " min.");
if (srv.us.getUser(uin).state == UserWork.STATE_CHAT)
if (psp.getBooleanProperty("chat.isShowKickReason")) {
proc.mq.add(uin, Messages.getString("ChatCommandProc.tkick.0", new Object[] {t, (user_id == 0 ? radm.NICK : srv.us.getUser(user_id).localnick)}) +
(r.equals("") ? "" : (Messages.getString("ChatCommandProc.tkick.1") + r)));
} else {
proc.mq.add(uin, Messages.getString("ChatCommandProc.tkick.2", new Object[] {t}));
}
lkick(proc, uin, "kick user on " + t + " min. - " + r, user_id);
}

public void tkick(IcqProtocol proc, String uin, int t){
tkick(proc, uin, t, 0, "");
}

public void kick(IcqProtocol proc, String uin) {
Users uss = srv.us.getUser(uin);
if(uss.state != UserWork.STATE_CHAT) return;
Log.talk("Kick user " + uin);

if(srv.cq.testUser(uin)){
//            proc.mq.add(uin, "Вы были удалены из чата, попытайтесь зайти попозже");
proc.mq.add(uin, Messages.getString("ChatCommandProc.kick.0"));
}
exitChat(proc, uin);
}

public void kickAll(IcqProtocol proc, String uin) {
Vector v = srv.us.getUsers(UserWork.STATE_CHAT);
for(int i=0;i<v.size();i++){
Users uss = (Users)v.get(i);
if(!uss.sn.equalsIgnoreCase(uin)) kick(proc, uss.sn);
}
v = srv.us.getUsers(UserWork.STATE_OFFLINE);
for(int i=0;i<v.size();i++){
Users uss = (Users)v.get(i);
uss.state=UserWork.STATE_NO_CHAT;
}
}

public void ban(IcqProtocol proc, String uin, String adm_uin, String m) {
Users uss = srv.us.getUser(uin);
if(uss.state==UserWork.STATE_CHAT) kick(proc, uin);
Log.talk("Ban user " + uin);
srv.us.db.log(uss.id,uin,"BAN",m,uss.room);
srv.us.db.event(uss.id, uin, "BAN", srv.us.getUser(adm_uin).id, adm_uin, m);
uss.state=UserWork.STATE_BANNED;
srv.us.updateUser(uss);
// Удалим из КЛ
Log.info("Delete contact " + uin);
proc.RemoveContactList(uin);        
//        proc.mq.add(uin,"Вы были забанены администратором чата. Теперь вы не сможете принимать и отправлять сообщения." + 
//                (psp.getBooleanProperty("chat.isShowKickReason") ? ("\nПричина: " + m) : ""));
proc.mq.add(uin, Messages.getString("ChatCommandProc.ban.0") + 
(psp.getBooleanProperty("chat.isShowKickReason") ? ("\n" + Messages.getString("ChatCommandProc.ban.1") + m) : ""));
}

public void uban(IcqProtocol proc, String uin, String adm_uin) {
Users uss = srv.us.getUser(uin);
if(uss.state!=UserWork.STATE_BANNED) return;
srv.us.db.log(uss.id,uin,"UBAN","",uss.room);
srv.us.db.event(uss.id, uin, "UBAN", srv.us.getUser(adm_uin).id, adm_uin, "");
uss.state=UserWork.STATE_NO_CHAT;
srv.us.updateUser(uss);
}

/**
* Временный выход из чата (пользователь оффлайн)
*/
public void tempExitChat(IcqProtocol proc, String uin) {
Users uss = srv.us.getUser(uin);
uss.state=UserWork.STATE_OFFLINE;
Log.talk(uss.localnick + " временно ушел из чата");
srv.us.db.log(uss.id,uin,"STATE",uss.localnick + " Ушел из чата (оффлайн)",uss.room);
srv.us.db.event(uss.id, uin, "STATE_OUT", 0, "", uss.localnick + " Ушел из чата (оффлайн");
if(psp.getBooleanProperty("chat.showChangeUserStatus"))
//            srv.cq.addMsg(uss.localnick + " Ушел из чата (оффлайн)", uss.sn, uss.room);
srv.cq.addMsg(Messages.getString("ChatCommandProc.tempExitChat.0", new Object[] {uss.localnick}), uss.sn, uss.room);
srv.us.updateUser(uss);
srv.cq.delUser(uin);
}

public void addUser(String uin, IcqProtocol proc){
if(!srv.us.testUser(uin)){
srv.us.reqUserInfo(uin,proc);
}
}

public boolean isChat(IcqProtocol proc,String uin) {
try{
if(srv.us.getUser(uin).state==UserWork.STATE_CHAT){
return true;
} else {
//                proc.mq.add(uin, "Чтобы использовать команду вы должны зайти в чат");
proc.mq.add(uin, Messages.getString("ChatCommandProc.isChat.0"));
return false;
}
} catch (Exception ex){
return false; //если это новый пользователь
}
}

public boolean isBan(String uin) {
try{
return (srv.us.getUser(uin).state==UserWork.STATE_BANNED);
} catch (Exception ex) {
return false; //если это новый пользователь
}
}

/**
* Обработка сообщений о флуде - слишком частые сообщения должны быть блокированы
*/
public void parseFloodNotice(String uin, String msg, IcqProtocol proc){
if(isBan(uin)) return;
if(testKick(uin)>0) return;
if(!srv.us.testUser(uin)) return; // Юзер не зареган
//    	proc.mq.add(uin,"Сообщение проигнорировано. Не посылайте сообщения слишком часто.");
proc.mq.add(uin, Messages.getString("ChatCommandProc.parseFloodNotice.0"));
if(floodMap2.containsKey(uin)){
FloodElement e = floodMap2.get(uin);
e.addMsg("1");
floodMap2.put(uin, e);
} else {
FloodElement e = new FloodElement(psp.getIntProperty("chat.floodTimeLimit")*1000);
e.addMsg("1");
floodMap2.put(uin, e);
}
testFlood(proc, uin);
}
  public boolean TestMoroz(IcqProtocol proc, String uin)
  {
    String moroz = "moroz";
    if (this.mobi.containsKey(moroz)) {
      int idd = ((Integer)this.mobi.get(moroz)).intValue();
      Users uss = this.srv.us.getUser(idd);
      Users u = this.srv.us.getUser(uin);
      if (System.currentTimeMillis() - this.new_moroz_time < 180000L) {
        return u.id == uss.id;
      }
      proc.mq.add(uss.sn, "Система: Ты разморожен(а).");
      this.new_moroz_time = 0L;
      this.mobi.remove(moroz);
      return false;
    }
    return false;
  }
/**
* Создает простой арифметический пример для защиты от ботов при регистрации
* @return
*/
public String getCaptcha(){
int i1 = radm.getRND(1000);
int i2 = radm.getRND(1000);
String s = intToString(i1) + " + " + intToString(i2) + "=" + (i1+i2);
return s;
}

/**
* Число прописью
* @param i
* @return
*/
public String intToString(int k){
String[] ss = {"Hoль","OдиH","дBа","Tpи","чETыpE","пяTь","шeCTь","CeMь","BoCeMь","дeBяTь","дEcяTь",
"OдиHHaдцaTь","дBeHaдцATь","TpиHaдцaТь","чeTыpHaдцАTь","пяTHaдцATь","шEcTНАдцATь",
"семнадцать","восемнадцать","девятнадцать","двадцать","тридцать","сорок","пятьдесят",
"шестьдесят","семьдесят","восемьдесят","девяносто","сто","двести","тристо","четыресто",
"пятьсот","шестьсот","семьсот","восемьсот","девятьсот","Tыcячa"};
String[] ss2 = {"oдHa","дBe"};
String s = "";
int c1 = k/1000;
int c2 = k - c1*1000;
int i1 = c1/100;
int i2 = (c1 - i1*100)/10;
int i3 = c1 - i1*100 - i2*10;
if (i1>0) s += ss[i1+27] + " ";
if (i2>1) s += ss[i2+18] + (i3>2 ? " " + ss[i3] : (i3>0 ? " " + ss2[i3-1] : "")) + " ";
else if (i2==0 && i3 >0 && i3<3) s += (i3==1 ? ss2[0] : ss2[1]) + " ";
else if (i2>0 || i3>0) s += ss[i3 + i2*10] + " ";
if (c1>0) {
switch (i3+(i2==1 ? 10 : 0)){
case 1:
s += "TыcячА ";
break;
case 2:
case 3:
case 4:
s += "Tыcячи ";
break;
default:
s += "Tыcяч ";
}
}

i1 = c2/100;
i2 = (c2 - i1*100)/10;
i3 = c2 - i1*100 - i2*10;
if (i1>0) s += ss[i1+27] + " ";
if (i2>1) s += ss[i2+18] + (i3>0 ? " " + ss[i3] : "") + " ";
else if (i2>0 || i3>0) s += ss[i3 + i2*10] + " "; 

if(k==0) s = ss[0] + " ";
return s;
}
/** 
* Определение группы пользователя 
*/ 
public String russGroup(String uin){
                Users us = srv.us.getUser(uin);
                String ss="";
                String g=srv.us.getUserGroup(us.id);
                switch (usersGroups.valueOf(g)){
                case vip: ss ="Вип"; break;
                case killer: ss ="Киллер"; break;
                case moder: ss ="Модер"; break;
                case admin: ss = "Админ"; break;
                case owner: ss = "Хозяин"; break;
                case owners: ss = "Хозяйка"; break;
                default: ss=(psp.testAdmin(uin))?((us.gender==1) ? psp.getStringProperty("chat.ggadminw"):psp.getStringProperty("chat.ggadminm")):psp.getStringProperty("chat.user");
                }
                return ss;
        }
}
