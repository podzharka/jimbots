package ru.jimbot.modules.chat;

import ru.jimbot.util.Log;
import java.util.Random;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Enumeration;

public class RobQuiz implements Runnable {
    private String NICK = "Умник8-)";
    private long TimeRange = 1;
    private String Question = "";
    private String Answer = "";
    private ChatServer srv;
    private long cTime = System.currentTimeMillis();
    private Thread th;
    private int sleepAmount = 1000;
    private Random r = new Random();
    private int maxQuiz = 0;
    private ChatProps psp;
    private int curID;
    private int curOpen = Integer.MAX_VALUE;  //Сколько букв открыто в данный момент
    private String curHint;    //Текущая подсказка
    private int curMaxOpen;
    private int curLength;

    //Следующие 2 ограничения связаны условием "или" (если хотя бы одно выполняется, переходим к следующему вопросу)
    private int minClosed = 2; //Минимальное количество букв, которые закрыты
    private int minClosedPercent = 30;//Минимальный процент закрытых букв
    //Следующие 2 ограничения менее приоритетны, чем 2 верхних
    //Изначально открывается максимум из следующих двух значений, если это не противоречит верхним ограничениям
    private int minOpen = 1; //Минимальное количество открытых букв
    private int minOpenPercent = 20;//Минимальный процент открытых букв

    private int count() {
        return maxQuiz==0 ? (int)srv.us.db.getLastIndex("victorina") : maxQuiz;
    }

    private boolean testTime() {
        return (System.currentTimeMillis()-cTime)>TimeRange*60000;
    }

    private int getRND(int i) {
        return r.nextInt(i);
    }

    private String str1(int number, String word) {
        String end;
        int number2 = number % 100;
        if (number2>=10 && number2<=19) end = "ов";
        else {
            int lastdigit = number2 % 10;
            if (lastdigit==0 || lastdigit>=5) end = "ов";
            else if (lastdigit==1) end = "";
                 else end = "а";
        }
        return number+" "+word+end;
    }

    private boolean openChar() {
        //srv.getServerLogger().info("openChar() curOpen = "+curOpen+"; curLength = "+curLength);
        if (curOpen>=curLength) return false;
        int rand = getRND(curLength-curOpen);
        int pos = 0;
        int pos2 = -1;
        while (pos<=rand) {
            pos2++;
            if (curHint.charAt(pos2)=='*') pos++;
        }
        //srv.getServerLogger().info("rand = "+rand+"; pos = "+pos+"; pos2 = "+pos2);
        //srv.getServerLogger().info("До: curHint = "+curHint);
        curHint = curHint.substring(0, pos2)+Answer.charAt(pos2)+curHint.substring(Math.min(pos2+1,curLength));
        //srv.getServerLogger().info("После: curHint = "+curHint);
        curOpen++;
        return true;
    }

    private boolean nextHint(boolean first) {
        if (first) {
            curLength = Answer.length();
            curMaxOpen = curLength-Math.max(curLength*minClosedPercent/100,minClosed);
            if (curMaxOpen<0) curMaxOpen=0;
            int tmpOpen = Math.max(curLength*minOpenPercent/100, minOpen);
            if (tmpOpen>curMaxOpen) tmpOpen = curMaxOpen;
            curOpen = 0;
            curHint = "";
            for (int i=0;i<curLength;i++) curHint+="*";
            for (int i=0;i<tmpOpen;i++) openChar();
            return true;
        }
        openChar();
        if (curOpen>curMaxOpen) return false;
        return true;
    }

    private String PromtGenerate(/*String text*/) {
        /*String s2="";
        int len=text.length();
        int t;
        if (len>1) {
            t = getRND(len - 1);
            for (int i=0;i<t;i++) s2+="*";
            s2+=text.charAt(t);
            for (int i=t+1;i<len;i++) s2+="*";
        }
        else s2="*";*/
        return "Подсказка: "+curHint;
    }
    private String QuizQuestion(boolean forceNewQuestion) {
        if (forceNewQuestion || !nextHint(false)) {
            curID=getRND(count() - 2) +1;
            try {
                PreparedStatement pst = srv.us.db.getDb().prepareStatement("SELECT * FROM victorina WHERE id = ? LIMIT 1");
                pst.setInt(1,curID);
                ResultSet rs = pst.executeQuery();
                rs.next();
                Question = rs.getString(2);
                Answer = rs.getString(3);
                rs.close();
                pst.close();
            } catch (Exception ex) {
                Answer = "";
                curOpen = Integer.MAX_VALUE;
                return "";
            }
            nextHint(true);
        }
        return "Вопрос №" + curID + ":\r\n" + Question + "\r\n" + PromtGenerate();
    }
    private void timeEvent() {
        if (!testTime()) return;
        cTime = System.currentTimeMillis();
        int cnt=0;
        int room = psp.getIntProperty("vik.room");
        Enumeration<String> e = srv.cq.uq.keys();
        while (e.hasMoreElements()) {
            String g = e.nextElement();
            Users us = srv.us.getUser(g);
            if (us.state==UserWork.STATE_CHAT && us.room==room) {
                cnt++;
                break;
            }
        }
        if (cnt!=0) {
            String question=QuizQuestion(false);
            if (question.length()!=0) say(question);
            else {
                Answer="";
                curOpen = Integer.MAX_VALUE;
            }
        }
        else {
            Answer="";
            curOpen = Integer.MAX_VALUE;
        }
    }

    private void say(String m) {
        String s = NICK + ": " + m;
        int room = psp.getIntProperty("vik.room");
        Log.talk(s);
        srv.us.db.log(0,"viktorina","OUT", s, room);
        srv.cq.addMsg(s,"",room);
    }

    public RobQuiz(ChatServer s) {
        srv = s;
        psp = ChatProps.getInstance(srv.getName());
    }

    public void parse(String uin, String msg, int room) {
        Users uss = srv.us.getUser(uin);
        if (psp.getIntProperty("vik.room") == room && Answer.equalsIgnoreCase(msg.trim())) {
            int balls = psp.getIntProperty("vik.ball");
            uss.zoloto+=balls;
            uss.vopr+=1;
            say("Правильно ответил(а) " + uss.localnick + " и получает "+str1(balls,"золотых")+"!\nУмник8-): Ответил(а) верно на (" + uss.vopr + ") вопросов.");
            srv.us.updateUser(uss);
            cTime = System.currentTimeMillis();
            say(QuizQuestion(true));
        }
    }

    public boolean start() {
        int count;
        try {
            count=count();
        } catch (Exception ex) {
            count=1;
        }
        th = new Thread(this,srv.getName()+" - RobQuiz");
        th.setPriority(Thread.NORM_PRIORITY);
        th.start();
        return true;
    }

    public synchronized void stop() {
        th = null;
        notify();
    }

    public void run() {
        Thread me = Thread.currentThread();
        while (th == me) {
            timeEvent();
            try {
                Thread.sleep(sleepAmount);

            } catch (InterruptedException e) { break; }
        }
        th=null;
    }

}