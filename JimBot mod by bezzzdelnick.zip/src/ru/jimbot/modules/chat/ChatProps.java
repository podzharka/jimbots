/**
 * JimBot - Java IM Bot
 * Copyright (C) 2006-2009 JimBot project
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package ru.jimbot.modules.chat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Properties;

import ru.jimbot.modules.AbstractProps;
import ru.jimbot.table.UserPreference;
import ru.jimbot.util.Log;
import ru.jimbot.util.MainProps;

/**
 *
 * @author Prolubnikov Dmitry
 */
public class ChatProps implements AbstractProps {
	public static HashMap<String,ChatProps> props = new HashMap<String,ChatProps>();
    public String PROPS_FILE = "";
    private String PROPS_FOLDER = "";
    public String ENCODING = "windows-1251";
    public Properties appProps;
    public Properties langProps;
    public boolean isLoaded = false;
    private String name;
    /** Creates a new instance of ChatProps */
    public ChatProps() {
    }
    
    public static ChatProps getInstance(String name){
    	if(props.containsKey(name))
    		return props.get(name);
    	else {
    		ChatProps p = new ChatProps();
    		p.PROPS_FILE = "./services/"+name+"/"+name+".xml";
    		p.PROPS_FOLDER = "./services/"+name;
    		p.name = name;
                p.setDefault();
    		p.load();
    		props.put(name, p);
    		return p;
    	}
    }

    
    public void setDefault() {
        appProps = new Properties();
        
        setIntProperty("conn.uinCount",1);
        setStringProperty("conn.uin0","111");
        setStringProperty("conn.pass0","Password");
        
        setIntProperty("chat.pauseOut",5000);
        setBooleanProperty("chat.IgnoreOfflineMsg",true);
        setIntProperty("chat.TempKick",10); //Временный кик, минут
        setIntProperty("chat.ChangeStatusTime",60000);
        setIntProperty("chat.ChangeStatusCount",5);
        setBooleanProperty("chat.FreeReg",true); //регистрация новых пользователей без ограничений
        setIntProperty("chat.MaxMsgSize",150); //Максимальный размер одного сообщения от пользователя
        setIntProperty("chat.MaxOutMsgSize",500);
        setIntProperty("chat.MaxOutMsgCount",5);
        setIntProperty("icq.status",0/*Icq.STATUS_ONLINE*/);
        setIntProperty("icq.xstatus",0);
//        setIntProperty("icq.statusFlag",0);
        setBooleanProperty("main.StartBot",false);
        setIntProperty("bot.pauseIn",3000); //Пауза входящих сообщений
        setIntProperty("bot.pauseOut",500); //Пауза исходящих сообщений
        setIntProperty("bot.msgOutLimit",20); //Ограничение очереди исходящих сообщений
        setIntProperty("bot.pauseRestart",11*60*1000); //Пауза перед запуском упавшего коннекта
        setStringProperty("bot.adminUIN","111111;222222");
        setIntProperty("chat.autoKickTime",60);
        setIntProperty("chat.autoKickTimeWarn",58);
        setIntProperty("icq.AUTORETRY_COUNT",5);
        setStringProperty("icq.STATUS_MESSAGE1","");
        setStringProperty("icq.STATUS_MESSAGE2","");
        setBooleanProperty("chat.ignoreMyMessage", true);
        setBooleanProperty("chat.isAuthRequest", false);
        setStringProperty("chat.badNicks","admin;админ");
        setIntProperty("chat.defaultKickTime",5);
        setIntProperty("chat.maxKickTime",300);
        setIntProperty("chat.maxNickLenght",10);
        setBooleanProperty("chat.showChangeUserStatus",true);
        setBooleanProperty("chat.writeInMsgs",false);
        setBooleanProperty("chat.writeAllMsgs",true);
        setBooleanProperty("adm.useAdmin",true);
        setBooleanProperty("adm.useMatFilter",true);
        setBooleanProperty("adm.useSayAdmin",true);
        setStringProperty("adm.matString","бля;хуй;хуя;хуе;хуё;хуи;хули;пизд;сук;суч;ублюд;сволоч;гандон;ебат;ебет;ибат;ебан;ебал;ибал;пидар;пидор;залуп;муда;муди");
        setStringProperty("adm.noMatString","рубл;нибал;абля;обля;оскорбля;шибал;гибал;хулига;требля;скреба;скребе;страх;стеб;хлеб;скипидар;любля;барсук");
        setIntProperty("adm.getStatTimeout",15);
        setIntProperty("adm.maxSayAdminCount",5);
        setIntProperty("adm.maxSayAdminTimeout",10);
        setIntProperty("adm.sayAloneTime",15);
        setIntProperty("adm.sayAloneProbability",20);
        setStringProperty("auth.groups","user;vip;killer;moder;admin;owner;owners");
        setStringProperty("auth.group_user","zamorozka;ruletka;ydar;uin;love;kosti;adminsay;Adm;trenirovka;vzatka;doljnost;izbank;otrezvet;oxpana;games;anyroom;oxpaHa;Kosti;gamew;txtread;aforizm;OFF;tut;pogoda;setclan;exit;razgovor;igrstat;cupcomn;bar;room;europe;gamea;today;adminstat;Butilochka;svadba;Svadba;pmsg;chislo;podarit;Ryletka;perevod;Razvod;lastusers;vbank;orujie;bilins;napadenie;game;AdminList;Anek;balans;Status;admin;reg;svadba_razvod;ohrana;zach;casino;chit;respect;poisk");
        setStringProperty("auth.group_vip","zamorozka;ruletka;ydar;uin;poslednie;info;kosti;love;adminsay;whoinv;Adm;trenirovka;racia;kickhist;vzatka;doljnost;izbank;oxpana;otrezvet;invise;games;anyroom;oxpaHa;Kosti;gamew;exthelp;Show;txtread;aforizm;CanHide;OFF;pogoda;tut;setclan;exit;razgovor;igrstat;cupcomn;bar;room;OpChat;europe;today;gamea;adminstat;Butilochka;svadba;pmsg;chislo;podarit;Ryletka;invite;perevod;otbota;lastusers;ModList;vbank;orujie;bilins;napadenie;kickone;game;AdminList;Anek;Status;admin;reg;svadba_razvod;ohrana;zach;whouser;casino;chit;respect;poisk");
        setStringProperty("auth.group_moder","zamorozka;ruletka;allroom_mesage;ydar;uin;poslednie;info;kosti;love;adminsay;whoinv;Adm;kickhist;racia;trenirovka;vzatka;settheme;banroom;doljnost;izbank;oxpana;otrezvet;invise;games;vsem;anyroom;oxpaHa;Kosti;gamew;exthelp;txtread;aforizm;CanHide;OFF;pogoda;tut;setclan;exit;razgovor;igrstat;cupcomn;bar;room;authread;OpChat;europe;gamea;today;adminstat;Butilochka;svadba;Svadba;peretachit;pmsg;chislo;podarit;kickall;setpass;Ryletka;invite;perevod;Razvod;otbota;lastusers;ModList;vbank;orujie;bilins;kickone;napadenie;game;messeges;AdminList;Anek;balans;banother;Status;admin;reg;svadba_razvod;ohrana;zach;casino;whouser;chit;respect;warning;poisk");
        setStringProperty("auth.group_admin","zamorozka;allroom_mesage;poslednie;info;kosti;adminsay;allroom_message;kickhist;doljnost;banroom;otrezvet;invise;ban;games;oxpaHa;gamew;exthelp;txtread;Show;aforizm;OFF;uchat;setclan;exit;razgovor;igrstat;cupcomn;xstatus;bar;authread;OpChat;europe;gamea;svadba;peretachit;pmsg;podarit;Razvod;perevod;otbota;lastusers;vbank;orujie;messeges;AdminList;Anek;balans;admin;reg;svadba_razvod;zach;casino;respect;warning;ruletka;ydar;IGNOR;uin;love;whoinv;Adm;trenirovka;racia;chgkick;vzatka;settheme;izbank;oxpana;anyroom;vsem;Kosti;CanHide;pogoda;tut;room;today;adminstat;Butilochka;Svadba;chislo;kickall;setpass;invite;Ryletka;ModList;bilins;kickone;napadenie;game;Status;banother;ohrana;popolnit;whouser;chit;poisk");
        setStringProperty("auth.groups_owner","zamorozka;wroom;allroom_mesage;uin;dblnick;info;adminsay;chnick;whoinv;kickhist;racia;chgkick;settheme;doljnost;banroom;izbank;oxpana;invise;ban;anyroom;addbutilochka;Kosti;exthelp;OFF;setclan;exit;razgovor;bar;room;authread;europe;adminstat;Butilochka;pmsg;kickall;Ryletka;invite;setpass;perevod;vbank;orujie;kickone;napadenie;xst;game;banother;authwrite;reg;admin;svadba_razvod;zach;whouser;casino;uchat;ownerhelp");
        setStringProperty("auth.groups_owners","zamorozka;wroom;allroom_mesage;uin;dblnick;info;adminsay;chnick;whoinv;kickhist;racia;chgkick;settheme;doljnost;banroom;izbank;oxpana;invise;ban;anyroom;addbutilochka;Kosti;exthelp;OFF;setclan;exit;razgovor;bar;room;authread;europe;adminstat;Butilochka;pmsg;kickall;Ryletka;invite;setpass;perevod;vbank;orujie;kickone;napadenie;xst;game;banother;authwrite;reg;admin;svadba_razvod;zach;whouser;casino;uchat;ownerhelp");
        setIntProperty("chat.MaxInviteTime",24);
        setBooleanProperty("chat.NoDelContactList",false);
        setIntProperty("chat.maxUserOnUin",7);
        setStringProperty("chat.badSymNicks","");
        setStringProperty("chat.goodSymNicks","");
        setStringProperty("chat.delimiter",":");
        setStringProperty("chat.inviteDescription","Для регистрации в чате вам необходимо получить приглашение одного из пользователей.");
        setIntProperty("chat.floodCountLimit",5);
        setIntProperty("chat.floodTimeLimit",10);
        setIntProperty("chat.floodTimeLimitNoReg",20);
        setStringProperty("db.host","localhost:3306");
        setStringProperty("db.user","root");
        setStringProperty("db.pass","");
        setStringProperty("db.dbname","botdb");
        setBooleanProperty("chat.useCaptcha", false);
        setBooleanProperty("chat.isUniqueNick", false);
        setIntProperty("chat.maxNickChanged",99);
        setBooleanProperty("chat.isShowKickReason", false);
        setStringProperty("chat.news","Новостей пока что нет:)");
        setStringProperty("uin1","433598");
        setStringProperty("chat.exit","Новостей пока что нет:):)");
        setStringProperty("chat.aa","Новостей пока что нет:):)");
        setIntProperty("vik.room",10);
        setIntProperty("vik.ball",2);
        setBooleanProperty("vik.enabled",true);
        setBooleanProperty("chat.lichnoe.admin.on.off", false);
        setStringProperty("chat.lichnoe.admin","433598");
        setIntProperty("auto_status.time", 5 );
        setBooleanProperty("auto_status.on.off", false);
        setBooleanProperty("filter.on", true);
	setBooleanProperty("filter.private.on", true);
	setBooleanProperty("filter.automsg.on", true);
	setBooleanProperty("filter.mat.on", true);
	setBooleanProperty("filter.adm", true);
	setBooleanProperty("filter.replace", true);
	setStringProperty("filter.antiuin","ноль;нуль;один;два;три;четыре;пять;шесть;семь;девять;1;2;3;4;5;6;7;8;9;one;чат;заходите;заходи;пиши;добавь;odin;dva;tri;chetire;pyat;shest;sem;vosem;devyat;nol;уин;юин;uin");
	setIntProperty("filter.num",3);
	setStringProperty("filter.change","-=[Фильтр рекламы]=-");
	setStringProperty("filter.change.mat","-=[Цензура]=-");
    setIntProperty("game.maxGameCount", 5);
    setIntProperty("game.millionroom", 0);

    }
    public UserPreference[] getUserPreference(){
        UserPreference[] p = {
                        new UserPreference(UserPreference.CATEGORY_TYPE,"main", "Основные настройки",""),
            new UserPreference(UserPreference.BOOLEAN_TYPE,"main.StartBot","Запускать чат-бот",getBooleanProperty("main.StartBot")),
            new UserPreference(UserPreference.INTEGER_TYPE,"icq.AUTORETRY_COUNT","Число переподключений движка при обрыве",getIntProperty("icq.AUTORETRY_COUNT")),
            new UserPreference(UserPreference.INTEGER_TYPE,"bot.pauseIn","Пауза для входящих сообщений",getIntProperty("bot.pauseIn")),
            new UserPreference(UserPreference.INTEGER_TYPE,"bot.pauseOut","Пауза для исходящих сообщений",getIntProperty("bot.pauseOut")),
            new UserPreference(UserPreference.INTEGER_TYPE,"bot.msgOutLimit","Ограничение очереди исходящих",getIntProperty("bot.msgOutLimit")),
            new UserPreference(UserPreference.INTEGER_TYPE,"bot.pauseRestart","Пауза перед перезапуском коннекта",getIntProperty("bot.pauseRestart")),
            new UserPreference(UserPreference.STRING_TYPE,"bot.adminUIN","Админские UIN",getStringProperty("bot.adminUIN")),
            new UserPreference(UserPreference.CATEGORY_TYPE,"chat", "Настройки чата",""),
            new UserPreference(UserPreference.INTEGER_TYPE,"chat.floodCountLimit","Число повторов флуда",getIntProperty("chat.floodCountLimit")),
            new UserPreference(UserPreference.INTEGER_TYPE,"chat.floodTimeLimit","Период флуда (сек)",getIntProperty("chat.floodTimeLimit")),
            new UserPreference(UserPreference.INTEGER_TYPE,"chat.floodTimeLimitNoReg","Пауза сообщений для незареганых (сек)",getIntProperty("chat.floodTimeLimitNoReg")),
            new UserPreference(UserPreference.INTEGER_TYPE,"chat.pauseOut","Задержка очереди чата",getIntProperty("chat.pauseOut")),
            new UserPreference(UserPreference.BOOLEAN_TYPE,"chat.IgnoreOfflineMsg","Игнорировать оффлайн сообщения",getBooleanProperty("chat.IgnoreOfflineMsg")),
            new UserPreference(UserPreference.BOOLEAN_TYPE,"chat.ignoreMyMessage","Игнорировать собственные сообщения в чате",getBooleanProperty("chat.ignoreMyMessage")),
            new UserPreference(UserPreference.INTEGER_TYPE,"chat.TempKick","Временный кик (минут)",getIntProperty("chat.TempKick")),
            new UserPreference(UserPreference.INTEGER_TYPE,"chat.ChangeStatusTime","Период переподключения юзера",getIntProperty("chat.ChangeStatusTime")),
            new UserPreference(UserPreference.INTEGER_TYPE,"chat.ChangeStatusCount","Количество переподключений для блокировки юзера",getIntProperty("chat.ChangeStatusCount")),
            new UserPreference(UserPreference.BOOLEAN_TYPE,"chat.FreeReg","Свободная регистрация",getBooleanProperty("chat.FreeReg")),
            new UserPreference(UserPreference.BOOLEAN_TYPE,"chat.useCaptcha","Использовать CAPTCHA при регистрации",getBooleanProperty("chat.useCaptcha")),
            new UserPreference(UserPreference.STRING_TYPE,"chat.inviteDescription","Пояснения по поводу приглашений в чат",getStringProperty("chat.inviteDescription")),
            new UserPreference(UserPreference.INTEGER_TYPE,"chat.MaxInviteTime","Время действия приглашения (часов)",getIntProperty("chat.MaxInviteTime")),
            new UserPreference(UserPreference.INTEGER_TYPE,"chat.MaxMsgSize","Максимальный размер одного сообщения",getIntProperty("chat.MaxMsgSize")),
            new UserPreference(UserPreference.INTEGER_TYPE,"chat.MaxOutMsgSize","Максимальный размер одного исходящего сообщения",getIntProperty("chat.MaxOutMsgSize")),
            new UserPreference(UserPreference.INTEGER_TYPE,"chat.MaxOutMsgCount","Максимальное число частей исходящего сообщения",getIntProperty("chat.MaxOutMsgCount")),
            new UserPreference(UserPreference.INTEGER_TYPE,"chat.autoKickTime","Время автокика при молчании (минут)",getIntProperty("chat.autoKickTime")),
            new UserPreference(UserPreference.INTEGER_TYPE,"chat.autoKickTimeWarn","Время предупреждения перед автокиком",getIntProperty("chat.autoKickTimeWarn")),
            new UserPreference(UserPreference.BOOLEAN_TYPE,"chat.isAuthRequest","Запрашивать авторизацию у пользователей",getBooleanProperty("chat.isAuthRequest")),
            new UserPreference(UserPreference.STRING_TYPE,"chat.badNicks","Запрещенные ники",getStringProperty("chat.badNicks")),
            new UserPreference(UserPreference.INTEGER_TYPE,"chat.maxNickChanged","Число смен ника за сутки",getIntProperty("chat.maxNickChanged")),
            new UserPreference(UserPreference.INTEGER_TYPE,"chat.defaultKickTime","Время кика по умолчанию",getIntProperty("chat.defaultKickTime")),
            new UserPreference(UserPreference.INTEGER_TYPE,"chat.maxKickTime","Максимальное время кика",getIntProperty("chat.maxKickTime")),
            new UserPreference(UserPreference.INTEGER_TYPE,"chat.maxNickLenght","Максимальная длина ника в чате",getIntProperty("chat.maxNickLenght")),
            new UserPreference(UserPreference.BOOLEAN_TYPE,"chat.isUniqueNick","Уникальные ники в чате",getBooleanProperty("chat.isUniqueNick")),            
            new UserPreference(UserPreference.BOOLEAN_TYPE,"chat.showChangeUserStatus","Показывать вход-выход при падении юзеров",getBooleanProperty("chat.showChangeUserStatus")),
            new UserPreference(UserPreference.BOOLEAN_TYPE,"chat.writeInMsgs","Записывать все входящие сообщения в БД",getBooleanProperty("chat.writeInMsgs")),
            new UserPreference(UserPreference.BOOLEAN_TYPE,"chat.writeAllMsgs","Записывать сообщения в БД (отключит статистику и т.п.)",getBooleanProperty("chat.writeAllMsgs")),
            new UserPreference(UserPreference.BOOLEAN_TYPE,"chat.NoDelContactList","Не очищать контакт-лист",getBooleanProperty("chat.NoDelContactList")),            
            new UserPreference(UserPreference.INTEGER_TYPE,"chat.maxUserOnUin","Максимум юзеров на 1 уин",getIntProperty("chat.maxUserOnUin")),
            new UserPreference(UserPreference.STRING_TYPE,"chat.badSymNicks","Запрещенные символы в никах",getStringProperty("chat.badSymNicks")),
            new UserPreference(UserPreference.STRING_TYPE,"chat.goodSymNicks","Разрешенные символы в никах",getStringProperty("chat.goodSymNicks")),
            new UserPreference(UserPreference.STRING_TYPE,"chat.delimiter","Разделитель после ника",getStringProperty("chat.delimiter")),
            new UserPreference(UserPreference.BOOLEAN_TYPE,"chat.isShowKickReason","Выводить нарушителю причину кика",getBooleanProperty("chat.isShowKickReason")),
            new UserPreference(UserPreference.CATEGORY_TYPE,"adm", "Настройки Админа",""),
            new UserPreference(UserPreference.BOOLEAN_TYPE,"adm.useAdmin","Использовать Админа в чате",getBooleanProperty("adm.useAdmin")),
            new UserPreference(UserPreference.BOOLEAN_TYPE,"adm.useMatFilter","Разрешить реакцию на мат",getBooleanProperty("adm.useMatFilter")),
            new UserPreference(UserPreference.BOOLEAN_TYPE,"adm.useSayAdmin","Разрешить админу разговаривать",getBooleanProperty("adm.useSayAdmin")),
            new UserPreference(UserPreference.STRING_TYPE,"adm.matString","Слова для мата",getStringProperty("adm.matString")),
            new UserPreference(UserPreference.STRING_TYPE,"adm.noMatString","Слова исключения",getStringProperty("adm.noMatString")),
            new UserPreference(UserPreference.INTEGER_TYPE,"adm.getStatTimeout","Пауза между показами статистики",getIntProperty("adm.getStatTimeout")),
            new UserPreference(UserPreference.INTEGER_TYPE,"adm.maxSayAdminCount","Максимум обращений к админу для одного человека",getIntProperty("adm.maxSayAdminCount")),
            new UserPreference(UserPreference.INTEGER_TYPE,"adm.maxSayAdminTimeout","Время сброса статистики обращений",getIntProperty("adm.maxSayAdminTimeout")),
            new UserPreference(UserPreference.INTEGER_TYPE,"adm.sayAloneTime","Время молчания, через которое админ заговорит",getIntProperty("adm.sayAloneTime")),
            new UserPreference(UserPreference.INTEGER_TYPE,"adm.sayAloneProbability","Вероятность разговора админа в тишине (1 к ...)",getIntProperty("adm.sayAloneProbability")),
            new UserPreference(UserPreference.CATEGORY_TYPE,"db", "Настройки mySQL",""),
            new UserPreference(UserPreference.STRING_TYPE,"db.host","Хост БД",getStringProperty("db.host")),
            new UserPreference(UserPreference.STRING_TYPE,"db.user","Пользователь",getStringProperty("db.user")),
            new UserPreference(UserPreference.PASS_TYPE,"db.pass","Пароль",getStringProperty("db.pass")),
            new UserPreference(UserPreference.STRING_TYPE,"db.dbname","Название базы данных",getStringProperty("db.dbname")),
                   };
        return p;
    }

    public UserPreference[] getUINPreference(){
        UserPreference[] p = new UserPreference[uinCount()*2+1];
        p[0] = new UserPreference(UserPreference.CATEGORY_TYPE,"conn", "Настройки UINов для подключения","");
        for(int i=0;i<uinCount();i++){
            p[i*2+1] = new UserPreference(UserPreference.STRING_TYPE,"conn.uin" + i,"UIN" + i,getProperty("conn.uin" + i,""));
            p[i*2+2] = new UserPreference(UserPreference.PASS_TYPE,"conn.pass" + i,"Password" + i,getProperty("conn.pass" + i, ""));
        }
        return p;
    }
    public UserPreference[] getFilterPreference(){
		UserPreference[] p = {
			new UserPreference(UserPreference.BOOLEAN_TYPE,"filter.on","Включить фильтр рекламы в сообщениях",getBooleanProperty("filter.on")),
			new UserPreference(UserPreference.BOOLEAN_TYPE,"filter.private.on","Включить фильтр рекламы в личных сообщениях",getBooleanProperty("filter.private.on")),
			new UserPreference(UserPreference.BOOLEAN_TYPE,"filter.automsg.on","Удалять сообщения автоответчика",getBooleanProperty("filter.automsg.on")),
			new UserPreference(UserPreference.BOOLEAN_TYPE,"filter.mat.on","Включить фильтр мата в сообщениях",getBooleanProperty("filter.mat.on")),
			new UserPreference(UserPreference.BOOLEAN_TYPE,"filter.adm","Уведомлять гл. админов о рекламе",getBooleanProperty("filter.adm")),
			new UserPreference(UserPreference.BOOLEAN_TYPE,"filter.replace","Включить замену текста рекламы",getBooleanProperty("filter.replace")),
			new UserPreference(UserPreference.STRING_TYPE,"filter.antiuin","Слова проверки на наличие рекламы:",getStringProperty("filter.antiuin")),
			new UserPreference(UserPreference.INTEGER_TYPE,"filter.num","Количество совпадений слов для блокировки сообщения",getIntProperty("filter.num")),
			new UserPreference(UserPreference.STRING_TYPE,"filter.change","Текст, которым заменять рекламные сообщения:",getStringProperty("filter.change")),
			new UserPreference(UserPreference.STRING_TYPE,"filter.change.mat","Текст, которым заменять нецензурные сообщения:",getStringProperty("filter.change.mat")),
			};
		return p;
	}

        public UserPreference[] NewUserPreference1() {
        UserPreference[] p = {
new UserPreference(UserPreference.CATEGORY_TYPE, "game", "НАСТРОЙКИ ИГРЫ МИЛЛИОНЕР", ""),
 new UserPreference(UserPreference.INTEGER_TYPE, "game.maxGameCount", "Число игр за сутки:", Integer.valueOf(getIntProperty("game.maxGameCount"))),
 new UserPreference(UserPreference.INTEGER_TYPE, "game.millionroom", "Комната для игры", Integer.valueOf(getIntProperty("game.millionroom"))),
 new UserPreference(UserPreference.CATEGORY_TYPE,"victorina", "НАСТРОЙКИ ВИКТОРИНЫ",""),
 new UserPreference(UserPreference.BOOLEAN_TYPE, "vik.enabled", "Включить викторину", Boolean.valueOf(getBooleanProperty("vik.enabled"))),
 new UserPreference(UserPreference.INTEGER_TYPE,"vik.ball","Баллов за правильный ответ",getIntProperty("vik.ball")),
 new UserPreference(UserPreference.INTEGER_TYPE,"vik.room","Комната викторины",getIntProperty("vik.room")),
        };
		return p;
	}

          public UserPreference[] getAdmPreference() {
        UserPreference[] p = {



        };
		return p;
	}

         public UserPreference[] NewUserPreference() {
        UserPreference[] p = {
            new UserPreference(UserPreference.CATEGORY_TYPE,"chat.lichnoe.admin", "НАСТРОЙКИ СООБЩЕНИЕ АДМИНУ",""),
            new UserPreference(UserPreference.BOOLEAN_TYPE,"chat.lichnoe.admin.on.off","Включить админ сообщения",getBooleanProperty("chat.lichnoe.admin.on.off")),
            new UserPreference(UserPreference.STRING_TYPE,"chat.lichnoe.admin","Куда присылать админ сообщения",getStringProperty("chat.lichnoe.admin")),
            new UserPreference(UserPreference.CATEGORY_TYPE,"chat.news", "НАСТРОЙКИ РЕКЛАМЫ",""),
            new UserPreference(UserPreference.STRING_TYPE,"chat.news","Новости чата при входе.",getStringProperty("chat.news")),
            new UserPreference(UserPreference.STRING_TYPE,"chat.aa","Новости чата при +все и +тут.",getStringProperty("chat.aa")),
            new UserPreference(UserPreference.STRING_TYPE,"chat.exit","Новости чата при выходе.",getStringProperty("chat.exit")),
            new UserPreference(UserPreference.CATEGORY_TYPE,"uin.schpion", "НАСТРОЙКИ ПРИВАТА",""),
            new UserPreference(UserPreference.STRING_TYPE,"uin1","UIN для контроля привата",getStringProperty("uin1")),
            new UserPreference(UserPreference.CATEGORY_TYPE,"bot", "НАСТРОЙКА СТАТУСА ЧАТА(ДЕЙСТВУЕТ ПОСЛЕ ПЕРЕЗАГРУЗКИ)",""),
            new UserPreference(UserPreference.INTEGER_TYPE,"icq.status","ICQ статус",getIntProperty("icq.status")),
            new UserPreference(UserPreference.INTEGER_TYPE,"icq.xstatus","x-статус (0-34)",getIntProperty("icq.xstatus")),
            new UserPreference(UserPreference.STRING_TYPE,"icq.STATUS_MESSAGE1","Сообщение x-статуса 1",getStringProperty("icq.STATUS_MESSAGE1")),
            new UserPreference(UserPreference.STRING_TYPE,"icq.STATUS_MESSAGE2","Сообщение x-статуса 2",getStringProperty("icq.STATUS_MESSAGE2")),
            new UserPreference(UserPreference.BOOLEAN_TYPE,"auto_status.on.off","Включить/Выключить авто смену x-status`ов",getBooleanProperty("auto_status.on.off")),
            new UserPreference(UserPreference.INTEGER_TYPE,"auto_status.time","Интервал смены x-status`ов",getIntProperty("auto_status.time")),
       };
		return p;
	}


    public boolean isAutoStart(){
    	return getBooleanProperty("main.StartBot");
    }
    
	public boolean testAdmin(String uin) {
		String s = getStringProperty("bot.adminUIN");
		if(s.equals("")) return false;
		if(uin.equals("0") || uin.equals(s)) return true;
		return false;
	}
    
		public String getAdmin(){
		return getStringProperty("bot.adminUIN");
	}
    
    public String getChatRules(){
        return loadText("./text/rules.txt");
    }
    
    public String getHelp1(){
        return loadText("./text/help1.txt");
    }
    
    public String getHelp2(){
        return loadText("./text/help2.txt");
    }
        public String getHelp3(){
        return loadText("./text/help3.txt");
    }
                public String getGames(){
        return loadText("./text/games.txt");
    }
    public String loadText(String fname){
        String s = "";
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(fname),"windows-1251"));
            while (r.ready()) {
                s += r.readLine() + "\n";
            }
            r.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return s;
    }

    public final void load() {
        File file = new File(PROPS_FILE);
        setDefault();
        try {
            FileInputStream fi = new FileInputStream(file);
//            appProps.load(fi);
            appProps.loadFromXML(fi);
            fi.close();
            Log.info("Load preferences ok");
        } catch (Exception ex) {
            ex.printStackTrace();
            Log.error("Error opening preferences: ");
        }
    }
    
    public final void save() {
        File file = new File(PROPS_FILE);
        File dir = new File(this.PROPS_FOLDER);
        try {
        	if(!dir.exists())
        		dir.mkdirs();
            FileOutputStream fo = new FileOutputStream(file);
//            appProps.store(fo,"jImBot properties");
            appProps.storeToXML(fo, "jImBot properties");
            fo.close();
            Log.info("Save preferences ok");
        } catch (Exception ex) {
            ex.printStackTrace();
            Log.error("Error saving preferences: ");
        }
    }
    
    public int uinCount(){
        return getIntProperty("conn.uinCount");
    }
    
    public String getUin(int i){
        return getStringProperty("conn.uin"+i);
    }
    
    public String getPass(int i){
        return getStringProperty("conn.pass"+i);
    }    
    
    /**
     * Изменение уина
     * @param i
     * @param uin
     * @param pass
     */
    public void setUin(int i, String uin, String pass){
    	setStringProperty("conn.uin"+i, uin);
    	if(!pass.equals("")) setStringProperty("conn.pass"+i, pass);
    }
    /**
* Авто создание конфига
* @param name
*/ 
public void AddXmlConfig (String name){
String Xml = "./services/" + name + "/" + name + ".xml";
File NEW = new File(Xml);
try {
FileOutputStream fo = new FileOutputStream(NEW);
appProps.storeToXML(fo, "jImBot properties");
fo.close();
Log.info(name + ".xml был создан автоматически!");
} catch (Exception ex) {
ex.printStackTrace();
Log.error("Error saving preferences: ");
}
}
    /**
     * Добавление нового уина в настройки
     * @param uin - уин
     * @param pass - пароль
     * @return - порядковый номер нового уина
     */
    public int addUin(String uin, String pass){
    	int c = uinCount();
    	setIntProperty("conn.uinCount", c+1);
    	setStringProperty("conn.uin"+c, uin);
    	setStringProperty("conn.pass"+c, pass);
    	return c;
    }
    
    /**
     * Удаление уина из настроек
     * @param c
     */
    public void delUin(int c) {
    	// Сдвигаем элементы после удаленного
    	for(int i=0; i<(uinCount()-1); i++){
    		if(i>=c){
    			setStringProperty("conn.uin"+i, getUin(i+1));
    			setStringProperty("conn.pass"+i, getPass(i+1));
    		}
    	}
    	//Удаляем самый последний элемент
    	appProps.remove("conn.uin"+(uinCount()-1));
    	appProps.remove("conn.pass"+(uinCount()-1));
    	setIntProperty("conn.uinCount", uinCount()-1);
    }
    
    public void registerProperties(Properties _appProps) {
        appProps = _appProps;
    }
    
    public String getProperty(String key) {
        return appProps.getProperty(key);
    }
    
    public String getStringProperty(String key) {
        return appProps.getProperty(key);
    }
    
    public String getProperty(String key, String def) {
        return appProps.getProperty(key,def);
    }
    
    public void setProperty(String key, String val) {
        appProps.setProperty(key,val);
    }
    
    public void setStringProperty(String key, String val) {
        appProps.setProperty(key,val);
    }
    
    public void setIntProperty(String key, int val) {
        appProps.setProperty(key,Integer.toString(val));
    }
    
    public void setBooleanProperty(String key, boolean val) {
        appProps.setProperty(key, val ? "true":"false");
    }
    
    public int getIntProperty(String key) {
        return Integer.parseInt(appProps.getProperty(key));
    }
    
    public boolean getBooleanProperty(String key) {
        return Boolean.valueOf(appProps.getProperty(key)).booleanValue();
    }

	public Properties getProps() {
		return appProps;
	}
            /**
     * Возвращает путь к папке текущего сервиса
     * @return Путь к папке текущего сервиса. Заканчивается слешем.
     */
    public String getServiceDirectory() {
        return MainProps.servicesDirectory+name+"/";
    }

    /**
     * Возвращает путь к папке текстов текущего сервиса
     * @return Путь к папке текстов текущего сервиса. Заканчивается слешем.
     */
    public String getTextDirectory() {
        return getServiceDirectory()+MainProps.serviceTextDirectory;
    }


}
