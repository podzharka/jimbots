package ru.jimbot.modules.chat;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import ru.jimbot.util.Log;

public class GameWork
{
  public DBChat db;
  private ConcurrentHashMap<Integer, Questions> qc = new ConcurrentHashMap();

  public GameWork(DBChat _db) {
    this.db = _db;
  }

  public void fillCash()
  {
    ResultSet rst = null;
    Statement stmt = null;
    String query = "select id, question, answers, correct_answer, difficulty_level from questions";
    try {
      stmt = this.db.getDb().createStatement(1005, 1007);
      Log.debug("EXEC: " + query);
      rst = stmt.executeQuery(query);
      while (rst.next()) {
        Questions q = new Questions();
        q.setId(rst.getInt(1));
        q.setQuestion(rst.getString(2));
        q.setAnswers(rst.getString(3));
        q.setCorrectAnswer(rst.getInt(4));
        q.setDifficultyLevel(rst.getInt(5));
        this.qc.put(Integer.valueOf(q.getId()), q);
      }

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
        	if(stmt!=null) try{stmt.close();} catch(Exception e) {};

    }
  }

  public Questions getQuestion(int id)
  {
    if (!this.qc.containsKey(Integer.valueOf(id))) return null;
    return (Questions)this.qc.get(Integer.valueOf(id));
  }

  public boolean checkQuestion(int id) {
    return this.qc.containsKey(Integer.valueOf(id));
  }

  public int getCountQuestions() {
    return this.qc.size();
  }

  public Set<Integer> getQuestions() {
    return this.qc.keySet();
  }
}