/**
 * JimBot - Java IM Bot
 * Copyright (C) 2006-2009 JimBot project
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package ru.jimbot.modules.chat;

import java.sql.Types;

import ru.jimbot.db.DBObject;

/**
 *
 * @author Prolubnikov Dmitry
 */
public class Users extends DBObject {
    public int id = 0;
    public String sn = "";
    public String nick="";
    public String localnick = "";
    public String fname="";
    public String lname="";
    public String email="";
    public String city="";
    public String homepage="";
    public int gender= 0;
    public int birthyear= 0;
    public int birthmonth= 0;
    public int birthday= 0;
    public int age= 0;
    public int country= 0;
    public int language=0;
    public int state = 0;
    public String basesn="";
    public long createtime=0;
    public int room = 0;
    public long lastKick = System.currentTimeMillis();
    public long gametime = System.currentTimeMillis();
    public long bartime = System.currentTimeMillis();
    public long golostime = System.currentTimeMillis();
    public long napadtime = System.currentTimeMillis();
    public long lastbanroom = System.currentTimeMillis();
    public long icetime = System.currentTimeMillis();
    public String group = "user";
public int zoloto=100;
public int hpoxp=0;
public int avtopitet=0;
public int prestypnost=0;
public int vbanke=0;
public int bar=0;
public int orujie=0;
public int vopr=0;
public int zachita=0;
public int hp=0;
public int iznos=0;
public int clansman=0;
public String nazorujie="";
public String nazzachita="";
public String nazoxp="";
public String clangroup="";

    /** Creates a new instance of Users */
    public Users() {
        init();
        createtime = System.currentTimeMillis();
        gametime = System.currentTimeMillis();
        bartime = System.currentTimeMillis();
        golostime = System.currentTimeMillis();
        napadtime = System.currentTimeMillis();
        lastbanroom = System.currentTimeMillis();
        icetime = System.currentTimeMillis();
    }
    
    public Users (int _id, 
            String _sn,
            String _nick,
            String _localNick,
            String _fname,
            String _lname,
            String _email,
            String _city,
            String _homepage,
            String _nazorujie,
            String _nazzachita,
            String _nazoxp,
            String _clangroup,
            int _gender,
            int _birthYear,
            int _birthMonth,
            int _birthDay,
            int _age,
            int _country,
            int _zoloto,
            int _hpoxp,
            int _avtopitet,
            int _prestypnost,
            int _vbanke,
            int _bar,
            int _orujie,
            int _vopr,
            int _zachita,
            int _hp,
            int _iznos,
            int _clansman) {
        id = _id;
        sn = _sn;
        nick = _nick;
        localnick = _localNick;
        fname = _fname;
        lname = _lname;
        email = _email;
        city = _city;
        homepage = _homepage;
        gender = _gender;
        birthyear = _birthYear;
        birthmonth = _birthMonth;
        birthday = _birthDay;
        age = _age;
        country = _country;
        age = _age;
        zoloto = _zoloto;
        hpoxp = _hpoxp;
        avtopitet = _avtopitet;
        prestypnost = _prestypnost;
        vbanke = _vbanke;
        bar = _bar;
        orujie = _orujie;
        vopr = _vopr;
        zachita = _zachita;
        hp = _hp;
        iznos = _iznos;
    }    
    
    private void init(){
        fields = new String[] {"id","sn","nick","localnick","fname","lname",
            "email","city","homepage","gender","birthyear","birthmonth","birthday",
            "age","country","language","state","basesn","createtime", "room", "lastkick",
			"gametime","zoloto","hpoxp","avtopitet","prestypnost","vbanke",
                        "bar","orujie","vopr","zachita","hp","iznos","nazorujie","nazzachita",
                        "nazoxp","bartime","golostime","clansman","clangroup","napadtime","lastbanroom","icetime"};
        types = new int[] {Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
            Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
            Types.INTEGER, Types.INTEGER,Types.INTEGER,Types.INTEGER,Types.INTEGER,
            Types.INTEGER,Types.INTEGER,Types.INTEGER,Types.VARCHAR,Types.TIMESTAMP,
			Types.TIMESTAMP,Types.INTEGER, Types.TIMESTAMP,Types.INTEGER,Types.INTEGER,
			Types.INTEGER,Types.INTEGER,Types.INTEGER,Types.INTEGER,Types.INTEGER,Types.INTEGER,
			Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.TIMESTAMP,Types.TIMESTAMP,
        Types.INTEGER,Types.VARCHAR,Types.TIMESTAMP,Types.TIMESTAMP,Types.TIMESTAMP};
        tableName="users";        
    }
    
    public String getInfo(){
        String s = "Инфо о id = " + id + '\n';
        s += "UIN="+sn+'\n';
        s += "Ник в чате=" + localnick + '\n';
        s += "Ник в ICQ="+nick+'\n';
        s += "fname="+fname+'\n';
        s += "lname="+lname+'\n';
        s += "email="+email+'\n';
        s += "city="+city+'\n';
        s += "homepage="+homepage+'\n';
        s += "gender="+gender+'\n';
        s += "birthYear="+birthyear+'\n';
        s += "birthMonth="+birthmonth+'\n';
        s += "birthDay="+birthday+'\n';
        s += "age="+age;
        if(state==-1) s += "\nПользователь париться в бане.";
        return s;
    }    
    
    public String[] getFields(){
        return fields;
    }
    
    public int[] getTypes(){
        return types;
    }
    
    public String getTableName(){
        return this.tableName;
    }
}
