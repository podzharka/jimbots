package javax.servlet.http;

import java.util.EventObject;

public class HttpSessionBindingEvent extends EventObject {
    private String name;

    public HttpSessionBindingEvent(HttpSession session, String name) {
	super(session);
	this.name = name;
    }

    public String getName() {
	return name;
    }

    public HttpSession getSession() {
	return (HttpSession) getSource();
    }
}