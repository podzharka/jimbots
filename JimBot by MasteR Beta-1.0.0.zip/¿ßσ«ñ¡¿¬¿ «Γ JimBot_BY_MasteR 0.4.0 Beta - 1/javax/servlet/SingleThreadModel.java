package javax.servlet;

public interface SingleThreadModel {
}