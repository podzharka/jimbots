package ru.jimbot;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.MissingResourceException;
import java.util.Properties;
import java.util.ResourceBundle;

public class Messages { // ����� ���������� ��������������� ���������� ���������

    private static final String BUNDLE_NAME = "ru.jimbot.messages";

    private static final ResourceBundle RESOURCE_BUNDLE = getNewBundle();

    private static ResourceBundle getNewBundle(){
    	ResourceBundle bundle = null;
    	InputStream stream = null;
    	try {
    	stream = Messages.class.getResourceAsStream("/ru/jimbot/messages.xml");
        if (stream != null) {
            BufferedInputStream bis = new BufferedInputStream(stream);
            bundle = new XMLResourceBundle(bis);
            bis.close();
        }
    	} catch (Exception e) {
            e.printStackTrace();
    	}
        return bundle;
    }

    private Messages() {
    }

    public static synchronized String getString(String key) {
        try {
            return RESOURCE_BUNDLE.getString(key);
        } catch (MissingResourceException e) {
            return '!' + key + '!';
        }
    }

    public static synchronized String getString(String key, Object[] arg) {
        try {
            return java.text.MessageFormat.format(RESOURCE_BUNDLE.getString(key), arg);
        } catch (MissingResourceException e) {
            return '!' + key + '!';
        }
    }

    private static class XMLResourceBundle extends ResourceBundle {
        private Properties props;
        XMLResourceBundle(InputStream stream) throws IOException {
            props = new Properties();
            props.loadFromXML(stream);
        }
        protected Object handleGetObject(String key) {
            return props.getProperty(key);
        }
        @Override
        public Enumeration<String> getKeys() {
            return null;
        }
    }
}