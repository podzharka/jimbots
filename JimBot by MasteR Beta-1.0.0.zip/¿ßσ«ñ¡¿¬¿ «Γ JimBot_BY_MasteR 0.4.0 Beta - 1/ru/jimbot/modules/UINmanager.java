package ru.jimbot.modules;

import java.util.Vector;
import ru.jimbot.protocol.IcqProtocol;

public class UINmanager {
    AbstractConnection con;
    public Vector<String> icq = new Vector<String>();
    private Vector<String> pass = new Vector<String>();
    public Vector<IcqProtocol> proc = new Vector<IcqProtocol>(); // ������ �� �������
    public boolean ignoreOfflineMsg=false;
    

    public UINmanager(String[] ic, String[] ps, AbstractConnection c, boolean ignore, AbstractProps props) {
        ignoreOfflineMsg = ignore;
        con = c;
        for(int i=0;i<ic.length;i++){
            icq.add(ic[i]);
            pass.add(ps[i]);
            IcqProtocol iprot = new IcqProtocol(props);
            iprot.screenName = ic[i];
            iprot.baseUin = ic[i];
            iprot.password = ps[i];
            iprot.server = con.server;
            iprot.port = con.port;
            iprot.proxyHost = con.proxy[0];
            iprot.useProxy = !con.proxy[0].equals("");
            try{
                iprot.proxyPort = Integer.parseInt(con.proxy[1]);
            } catch (Exception ex){
                iprot.proxyPort=0;
            }
            iprot.proxyUser = con.proxy[2];
            iprot.proxyPass = con.proxy[3];
            proc.add(iprot);
        }
    }

    public void start() {
        for(int i=0;i<count();i++){
            ((IcqProtocol)proc.get(i)).connect();
        }
    }

    public void stop() {
        for(int i=0;i<count();i++){
            ((IcqProtocol)proc.get(i)).disconnect();
        }        
    }

    public int count(){
        return icq.size();
    }

    public boolean getState(int i) {
        return ((IcqProtocol)proc.get(i)).isOnLine();
    }

    public String getUin(int i){
        return (String)icq.get(i);
    }
}