package ru.jimbot.modules;

import java.util.HashMap;
import java.util.Vector;
import java.util.concurrent.ConcurrentLinkedQueue;
import ru.jimbot.modules.chat.Users;
import ru.jimbot.protocol.IcqProtocol;
import ru.jimbot.util.Log;

public class MsgInQueue implements Runnable { // ������� �������� ���������
    Vector<MsgReceiver> receivers; // ������ ��������, ���������� ��������� � ��� �������
    AbstractCommandProcessor cmd;
    ConcurrentLinkedQueue <MsgQueueElement> q;
    private Thread th;
    int sleepAmount = 100;
    public boolean ignoreOffline = true;
    private HashMap<String,Long> flood = new HashMap<String,Long>(); // ���� ��� - ����� ���������� ���������
        
    public MsgInQueue(AbstractCommandProcessor c) {
        cmd = c;
        receivers = new Vector<MsgReceiver>();
        q = new ConcurrentLinkedQueue<MsgQueueElement>();
    }

    private boolean testFlood(String uin){ // �������� �� ���� �������� ���������. ������� ������ �� ������ �������� � �������
    	long i = cmd.getServer().getProps().getIntProperty("bot.pauseIn");
    	long c = System.currentTimeMillis();
    	if(flood.containsKey(uin)){
            if((c-flood.get(uin))<i){
                flood.put(uin, c);
                return true;
            } else {
                flood.put(uin, c);
                return false;
            }
    	} else {
            flood.put(uin, c);
            return false;
    	}
    }

    public void start(){
        th = new Thread(this,"msg_in");
        th.setPriority(Thread.NORM_PRIORITY);
        th.start();
    }

    public synchronized void stop() {
        th = null;
        receivers = new Vector<MsgReceiver>();
        notify();
    }

    private void parseMsg(){
        try{
            if(q.size()==0) return;
            MsgQueueElement m = q.poll();
            if(m.type==MsgQueueElement.TYPE_TEXT){
                cmd.parse(m.proc,m.sn,m.msg);
            } else if(m.type==MsgQueueElement.TYPE_STATUS){
                cmd.parseStatus(m.proc, m.sn, Integer.parseInt(m.msg));
            }else if(m.type==MsgQueueElement.TYPE_FLOOD_NOTICE){
            	cmd.parseFloodNotice(m.sn, m.msg, m.proc);
            } else {
                cmd.parseInfo(m.u, m.info_type);
            }
        } catch(Exception ex) {
            ex.printStackTrace();
        }
    }

    public void run() {
        Thread me = Thread.currentThread(); 
        while (th == me) {
            parseMsg();
            try {
                Thread.sleep(sleepAmount);
            } catch (InterruptedException e) { break; }             
        }
        th=null;
    }

    public void addReceiver(IcqProtocol ip){
        receivers.add(new MsgReceiver(this,ip));
    }

    public void addMsg(IcqProtocol proc, String sn, String msg, boolean isOffline){
        if(isOffline && ignoreOffline) {
            Log.info("OFFLINE: " + sn + " - " + msg);
            return;
        }
        MsgStatCounter.getElement(proc.baseUin).addMsgCount();
        if(!testFlood(sn))
            q.add(new MsgQueueElement(sn, msg, proc));
        else {
            Log.flood("FLOOD from " + sn + ">> " + msg);
            MsgQueueElement e = new MsgQueueElement(sn,msg,proc);
            e.type = MsgQueueElement.TYPE_FLOOD_NOTICE;
            q.add(e);
        }
    }

    public void addStatus(IcqProtocol proc, String sn, String st){
        Log.info("ADD status in queue");
        MsgQueueElement m = new MsgQueueElement(sn, st, proc);
        m.type = MsgQueueElement.TYPE_STATUS;
        q.add(m);
    }

    public void addInfo(Users u, int type){
        MsgQueueElement m = new MsgQueueElement(u, type);
        q.add(m);
    }

    public int size(){
    	return q.size();
    }
}