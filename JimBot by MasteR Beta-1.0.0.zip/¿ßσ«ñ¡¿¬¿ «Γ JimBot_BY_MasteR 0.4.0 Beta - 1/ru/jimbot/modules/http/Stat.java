package ru.jimbot.modules.http;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import ru.jimbot.modules.anek.AnekServer;
import ru.jimbot.modules.chat.ChatServer;
import ru.jimbot.util.Log;

public class Stat extends HttpServlet { // ������� ���������� ������ ����
    private static ChatServer chat = null;
    private static AnekServer anek = null;
    private static long start = 0;

    public static void setAnek(AnekServer anek) {
        Stat.anek = anek;
        start = System.currentTimeMillis();
    }

    public static void setChat(ChatServer chat) {
        Stat.chat = chat;
        start = System.currentTimeMillis();
    }

    @Override
    public void init() throws ServletException {
        Log.http("init Stat");
    }

    @Override
    public void destroy() {
        Log.http("destroy Stat");
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setContentType("text/html");
        HttpConnection con = new HttpConnection(request, response);
        con.print(SrvUtil.HTML_HEAD+"<TITLE>JimBot ����������</TITLE></HEAD>"+SrvUtil.BODY);
        con.print("<H1><FONT COLOR=\"#004000\">" +
                  SrvUtil.encodeHTML("���� �� ������ ��� ���������, ������ HTTP ������ JimBot �������� ��������� :)") + 
                  "</FONT></H1>");
        con.print("</BODY></HTML>");
        con.send();
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
//        response.setContentType("text/html");
//        HttpConnection con = new HttpConnection(request, response);
//        con.print(SrvUtil.HTML_HEAD+"<TITLE>Welcome to ChatBot HTTP Server</TITLE></HEAD>"+SrvUtil.BODY);
//        con.print("</BODY></HTML>");
//        con.send();
    }
}
