package ru.jimbot.modules.http;

import java.io.IOException;

interface Printable {
    void print(HttpConnection con) throws IOException;
}