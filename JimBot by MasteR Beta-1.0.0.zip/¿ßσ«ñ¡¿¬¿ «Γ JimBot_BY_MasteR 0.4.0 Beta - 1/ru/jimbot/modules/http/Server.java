package ru.jimbot.modules.http;

import java.io.File;
import java.io.FileInputStream;
import java.util.Hashtable;
import java.util.Properties;
import org.garret.httpserver.JHttpServer;
import ru.jimbot.util.Log;

public class Server {
    static JHttpServer server;
    
    public static void startServer(String args[]) throws Exception {
        File propsFile;
        String cfgFileName = System.getProperty("config");
        if (cfgFileName != null) {
            propsFile = new File(cfgFileName);
            if (!propsFile.exists()) {
                Log.error("Configuration file " + propsFile + " doesn't exit");
                System.exit(1);
            }
        } else {
            propsFile = new File(JHttpServer.JHTTP_SERVER_PROPS_FILE_NAME);
        }
        Properties serverProperties;
        if (propsFile.exists()) {
            serverProperties = new Properties();
            FileInputStream stream = new FileInputStream(propsFile);
            serverProperties.load(stream);
            stream.close();
        } else {
            serverProperties = System.getProperties();
        }
        Hashtable servletMapping = new Hashtable();
        for (int i = 0; i < args.length; i += 2) {
            String path = args[i];
            if (!path.startsWith("/")) {
                path = "/" + path;
            }
            if (path.endsWith("/")) {
                path = path.substring(0, path.length() - 1);
            }
            servletMapping.put(path, args[i + 1]);
        }
        server = new JHttpServer(servletMapping, serverProperties);
        Log.info("HTTP ������ �������...");
    }

    public static void stopServer() {
        try {
            System.out.println("Shutdown server");
            server.shutdown();
        } catch (Exception ex) {
            System.err.println(ex.getMessage());
        }
    }
}