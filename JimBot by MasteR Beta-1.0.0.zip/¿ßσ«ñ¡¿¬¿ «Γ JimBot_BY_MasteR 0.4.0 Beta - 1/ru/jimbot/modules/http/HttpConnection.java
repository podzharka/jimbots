package ru.jimbot.modules.http;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.garret.httpserver.JHttpServletRequest;
import org.garret.httpserver.JHttpServletResponse;

public class HttpConnection {
    JHttpServletRequest request;
    JHttpServletResponse response;
    PrintWriter writer;
    OutputStream os;
    Hashtable newParams;
    int length;

    public void print(String s) throws IOException {
        length += s.length();
        PrintStream ps = new PrintStream(os,false,"windows-1251");
        ps.print(s);
    }

    public String get(String name) {
        if (newParams != null) {
            String val = (String)newParams.get(name);
            if (val != null) {
                return val;
            }
        }
        return request.getParameter(name);
    }

    public void addPair(String name, String val) {
        if (newParams == null) {
            newParams = new Hashtable();
        }
        newParams.put(name, val);
    }

    public String getURI() {
        return request.getRequestURI();
    }

    public void send() throws IOException {
        response.setContentType("text/html; charset=\"windows-1251\"");
        response.setContentLength(length);
        response.flushBuffer();
    }

    public HttpConnection(HttpServletRequest request, HttpServletResponse response) throws IOException {
        this.request = (JHttpServletRequest)request;
        this.response = (JHttpServletResponse)response;
        response.setContentType("text/html; charset=\"windows-1251\"");
        response.setLocale(new Locale("ru","RU",""));
        os = response.getOutputStream();
    }
}