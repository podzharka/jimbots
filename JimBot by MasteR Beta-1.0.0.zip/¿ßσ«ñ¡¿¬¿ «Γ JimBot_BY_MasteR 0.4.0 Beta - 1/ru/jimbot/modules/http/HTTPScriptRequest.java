package ru.jimbot.modules.http;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import ru.jimbot.modules.WorkScript;
import ru.jimbot.util.Log;

public class HTTPScriptRequest extends HttpServlet{

    @Override
    public void init() throws ServletException {
        Log.http("init script servlet");
    }

    @Override
    public void destroy() {
        Log.http("destroy script servlet");
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setContentType("text/html");
        HttpConnection con = new HttpConnection(request, response);
        String name = con.getURI().split("/")[1];
        con = WorkScript.getInstance("").startHTTPScript(name, con);
        con.send();
    }
}