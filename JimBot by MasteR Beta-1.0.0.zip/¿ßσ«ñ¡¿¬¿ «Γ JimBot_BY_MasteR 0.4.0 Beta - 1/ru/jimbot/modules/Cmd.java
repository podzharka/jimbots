package ru.jimbot.modules;

public class Cmd { // ������ ��������� �������
public int cmd = -1;
public String param = "";
public String cmd_name = "";
public String script = "";

    public Cmd(){
    }

    public Cmd(String name, String param, int id, String scr) {
        cmd_name = name;
        this.param = param;
        cmd = id;
        script = scr;
    }

    public Cmd(String name, String param, int id) {
        cmd_name = name;
        this.param = param;
        cmd = id;
    }
}