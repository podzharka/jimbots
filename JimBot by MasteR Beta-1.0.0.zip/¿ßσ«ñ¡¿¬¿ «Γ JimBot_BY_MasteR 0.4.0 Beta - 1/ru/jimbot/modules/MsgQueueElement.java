package ru.jimbot.modules;

import ru.jimbot.modules.chat.Users;
import ru.jimbot.protocol.IcqProtocol;

public class MsgQueueElement { // ������� ������� ���������
    public static final int TYPE_TEXT = 0;
    public static final int TYPE_STATUS = 1;
    public static final int TYPE_INFO = 2;
    public static final int TYPE_FLOOD_NOTICE = 3;
    public String sn = "";
    public String to_sn = "";
    public String msg = "";
    public Users u;
    public int info_type = 0;
    public long time = 0;
    public int type = 0;
    public IcqProtocol proc;
    
    public MsgQueueElement(String _sn, String _msg) {
        sn = _sn;
        msg = _msg;
        time = System.currentTimeMillis();
    }

    public MsgQueueElement(Users u, int i){
        this.u = u;
        this.info_type = i;
        time = System.currentTimeMillis();
        type = TYPE_INFO;
    }

    public MsgQueueElement(String _sn, String fsn, String _msg) {
        sn = _sn;
        to_sn = fsn;
        msg = _msg;
        time = System.currentTimeMillis();
    }

    public MsgQueueElement(String _sn, String _msg, IcqProtocol pr) {
        sn = _sn;
        msg = _msg;
        time = System.currentTimeMillis();
        proc = pr;
    }
}