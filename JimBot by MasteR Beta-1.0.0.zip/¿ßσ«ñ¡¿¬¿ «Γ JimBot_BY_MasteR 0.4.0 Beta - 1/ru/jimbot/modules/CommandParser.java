package ru.jimbot.modules;

import java.util.HashMap;
import java.util.Vector;

public class CommandParser {
    private HashMap<String, Cmd> cmd;
    
    public CommandParser(HashMap<String, Cmd> cmd) {
        this.cmd = cmd;
    }

    public int parseCommand(String s){ // ���������� ��� �������, ��� -1 ���� �� �������
        String s1 = "";
        try{
            s1 = s.trim().split(" ")[0];
            s1 = s1.toLowerCase();
        } catch (Exception e) {}
        if(cmd.containsKey(s1))
        return cmd.get(s1).cmd;
        else
        return -1;
    }

    public Cmd parseCommand2(String s){ // ���������� �������� �������
        String s1 = "";
        try{
            s1 = s.trim().split(" ")[0];
            s1 = s1.toLowerCase();
        } catch (Exception e) {}
        if(cmd.containsKey(s1))
        return cmd.get(s1);
        else
        return new Cmd();
    }

    public Vector parseArgs(String s){ // ���������� ������ ���������� �������
        Vector v = new Vector();
        Cmd c = parseCommand2(s);
        if(c.cmd==-1) return v;
        String arg = c.param;
        if(arg.equals("")) return v;
        for(int i=0;i<arg.split(" ").length;i++){
            if(i>=(s.split(" ").length-1)){
                if(arg.split(" ")[i].equals("$s") || arg.split(" ")[i].equals("$c"))
                v.add("");
                else
                v.add(0);
            } else {
                if(arg.split(" ")[i].equals("$c"))
                v.add(s.split(" ")[i+1]);
                else if(arg.split(" ")[i].equals("$n"))
                v.add(parseN(s.split(" ")[i+1]));
                else
                v.add(parseS(i+1,s));
            }
        }
        return v;
    }

    private String parseS(int c, String s){
        int k=0,i=0;
        for(i=0;i<s.length();i++){
            if(s.charAt(i)==' ') k++;
            if(k>=c) break;
        }
        return s.substring(i+1);
    }

    private int parseN(String s){
        try{
            return Integer.parseInt(s);
        } catch (Exception ex) {}
        return 0;
    }
}