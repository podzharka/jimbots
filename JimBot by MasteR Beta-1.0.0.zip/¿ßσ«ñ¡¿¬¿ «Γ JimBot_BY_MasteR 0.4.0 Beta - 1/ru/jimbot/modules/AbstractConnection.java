package ru.jimbot.modules;

public class AbstractConnection {
    public UINmanager uins;
    public String[] proxy = new String[] {"","","",""};
    public String server="";
    public int port;
    public AbstractServer srv;
    
    public AbstractConnection() {
    }
}