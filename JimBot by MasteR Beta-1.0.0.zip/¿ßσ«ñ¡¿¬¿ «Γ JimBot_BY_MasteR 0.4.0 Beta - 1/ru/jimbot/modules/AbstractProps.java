package ru.jimbot.modules;

import java.util.Properties;
import ru.jimbot.table.UserPreference;

public interface AbstractProps {
    public void setDefault();
    public UserPreference[] getFilterPreference();
    public UserPreference[] getRatingPreference();
    public UserPreference[] getBDPreference();
    public UserPreference[] getUserPreference();
    public UserPreference[] getShopPreference();
    public UserPreference[] getAdmPreference();
    public UserPreference[] getGamePreference();
    public UserPreference[] getUINPreference();
    public Properties getProps();
    public void load();
    public void save();
    public void registerProperties(Properties _appProps);
    public String getProperty(String key);
    public String getStringProperty(String key);
    public void setStringProperty(String key, String val);
    public void setIntProperty(String key, int val);
    public void setBooleanProperty(String key, boolean val);
    public int getIntProperty(String key);
    public boolean getBooleanProperty(String key);
    public int uinCount();
    public String getUin(int i);
    public String getPass(int i);
    public int addUin(String uin, String pass);
    public void delUin(int c);
    public void setUin(int i, String uin, String pass);
    public boolean isAutoStart();
    public String[] getAdmins();
}