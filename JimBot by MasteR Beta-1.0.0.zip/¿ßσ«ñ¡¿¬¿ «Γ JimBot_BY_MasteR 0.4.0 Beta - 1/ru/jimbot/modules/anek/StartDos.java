package ru.jimbot.modules.anek;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import ru.jimbot.util.Log;

public class StartDos { // ���������� ������� ���������
    private Process process;
    private String processName;

    public StartDos() {
    }
    
    public String rebootBot(){
        String run = ".\\reboot.bat";
        String s="";
        try {
            process = Runtime.getRuntime().exec(run);
            process.getOutputStream().close();
            BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream(),"windows-1251"));
            String line;
            while((line = in.readLine()) != null) {
                if (!line.equals("")) s += line + '\n';
            }
            in.close();
            process.destroy();            
        } catch (Exception e){
            e.printStackTrace();
        }
        Log.debug(s);
        return s;        
    }
}