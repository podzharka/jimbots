package ru.jimbot.modules.anek;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;
import ru.jimbot.db.DBAdaptor;
import ru.jimbot.db.DBObject;

public class DBAneks extends DBAdaptor{
    
    public DBAneks() throws Exception  {
//        this.DRIVER = "org.hsqldb.jdbcDriver";
//        this.URL = "jdbc:hsqldb:file:";
//        this.dbName = "db/aneks";
    }
    
    public void createDB(){
//        if(!MainProps.isExtdb()){
//            Log.info("DB aneks not found. Create new DB...");
//            try{
//                executeQuery("CREATE CACHED TABLE ANEKS(ID INTEGER NOT NULL PRIMARY KEY,TEXT LONGVARCHAR)");
//                executeQuery("insert into aneks values (0, 'test')");
////                commit();
//            }catch(Exception ex){
//                ex.printStackTrace();
//            }
//        } else {
//        }
    }
    
    public DBObject getObject(String q){
        Aneks an = new Aneks();
        Statement stm = null;
        ResultSet rs = null;
        try{
            stm = getDb().createStatement();
            rs = stm.executeQuery(q);
            rs.next();
            an.id = rs.getInt(1);
            an.text = rs.getString(2);
        } catch (Exception ex){
            ex.printStackTrace();
        } finally {
            if(rs!=null) try{rs.close();}catch(Exception e){};
            if(stm!=null) try{stm.close();}catch(Exception e){};
        }
        return an;
    }

    public Vector getObjectVector(String q){
        Vector v = new Vector();
        Statement stm = null;
        ResultSet rs = null;
        try{
            stm = getDb().createStatement();
            rs = stm.executeQuery(q);
            while(rs.next()) {
                Aneks an = new Aneks();
                an.id = rs.getInt(1);
                an.text = rs.getString(2);
                v.addElement(an);
            }
        } catch (Exception ex){
            ex.printStackTrace();
        } finally {
            if(rs!=null) try{rs.close();}catch(Exception e){};
            if(stm!=null) try{stm.close();}catch(Exception e){};
        }
        return v;
    }

    public void insertObject(DBObject o){
        Aneks an = (Aneks)o;
        try{
            PreparedStatement pst = getDb().prepareStatement("insert into aneks values (?, ?)");
            pst.setInt(1,an.id);
            pst.setString(2,an.text);
            pst.execute();
            pst.close();
        } catch (Exception ex){
            ex.printStackTrace();
        }
    }

    public void updateObject(DBObject o){
    }
}