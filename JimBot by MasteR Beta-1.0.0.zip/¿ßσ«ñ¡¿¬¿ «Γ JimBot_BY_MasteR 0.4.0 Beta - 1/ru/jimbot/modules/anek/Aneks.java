package ru.jimbot.modules.anek;

import java.sql.Types;
import ru.jimbot.db.DBObject;

public class Aneks extends DBObject {
    public int id=0;
    public String text = "";

    public Aneks() {
        init();
    }

    public Aneks(int i, String s) {
       init();
       id=i;
       text=s;
    }

    private void init(){
        fields = new String[] {"id","text"};
        types = new int[] {Types.INTEGER, Types.LONGVARCHAR};
        tableName="aneks";        
    }

    public String[] getFields(){
        return fields;
    }

    public int[] getTypes(){
        return types;
    }

    public String getTableName(){
        return this.tableName;
    }
}