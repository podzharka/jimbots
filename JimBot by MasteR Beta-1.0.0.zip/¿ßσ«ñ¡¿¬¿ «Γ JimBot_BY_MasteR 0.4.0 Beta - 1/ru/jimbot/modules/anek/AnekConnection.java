package ru.jimbot.modules.anek;

import ru.jimbot.modules.AbstractConnection;

public class AnekConnection extends AbstractConnection{

    public AnekConnection(AnekServer s) {
        srv = s;
    }
}