package ru.jimbot.modules.chat;

import ru.jimbot.db.DBObject;

public class Rooms extends DBObject { // ������� � ����
    private int id=0;
    private String name="";
    private String topic="";
    private int user_id=0;
    private String pass="";
	
    public Rooms(){
    }
	
    public Rooms(int _id, String _name, String _topic, int _user_id){
        id=_id;
        name=_name;
        topic=_topic;
        user_id=_user_id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public boolean checkPass(String p) {
        if (pass.equals("")) {
            return true;
        } else
        return pass.equals(p);
   }

   public void setPass(String pass) {
      this.pass = pass;
   }

   @Override
    public String[] getFields() {
        return null;
    }

    @Override
    public String getTableName() {
        return null;
    }

    @Override
    public int[] getTypes() {
        return null;
    }
}