package ru.jimbot.modules.chat;

import java.util.Arrays;
import java.util.Random;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Victorina implements Runnable {
    private String Question = "";
    private String Answer = "";
    private ChatServer srv;
    private long cTime = System.currentTimeMillis();
    private Thread th;
    private int sleepAmount = 1000;
    private Random r = new Random();
    private int oldQuestion = 0;
    private int maxVic = 0;
    private String word;
    private char[] mix;
    private int starsCount;
    public ChatProps psp;

    private int count() {
        return maxVic ==0 ? (int)srv.us.db.getLastIndex("victorina") : maxVic;
    }

    public Victorina(ChatServer s) {
        srv = s;
        maxVic = count();
        psp = ChatProps.getInstance(srv.getName());
    }

    public void Vic(String word) {
        this.word = word;
        starsCount = word.length();
        mix = new char[starsCount];
        Arrays.fill(mix, '*');
    }

    public String HintVic() {
        String s = "";
        replaceOne();
        s = String.valueOf(getMix());
        return s;
    }

    private boolean testTime() {
        int time = psp.getIntProperty("vik.time");
        return (System.currentTimeMillis()-cTime)>time*60000;
    }

    private int getRND(int i) {
        return r.nextInt(i);
    }

    private String VicQuestion(int id) {
        try {
            PreparedStatement pst = srv.us.db.getDb().prepareStatement("SELECT * FROM victorina WHERE id = ? ");
            pst.setInt(1,id);
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                Question = rs.getString(2);
                Answer = rs.getString(3);
            }
            rs.close();
            pst.close();
        } catch (Exception ex) {}
        oldQuestion = id;
        Vic(Answer);
        return "������: " + Question + "\n���������: " + HintVic();
    }

    public String NICK(){
        return psp.getStringProperty("vik.Nick");
    }

    private String VicQuestionOld(int id) {
        try {
            PreparedStatement pst = srv.us.db.getDb().prepareStatement("SELECT * FROM victorina WHERE id = ? ");
            pst.setInt(1,id);
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                Question = rs.getString(2);
            }
            rs.close();
            pst.close();
        } catch (Exception ex) {}
            return "������: " + Question + "\n���������: " + HintVic();
        }

    public void Question(){
        if(!hasStars()){
            cTime = System.currentTimeMillis();
            say(VicQuestion(getRND((int)(maxVic - 2)) +1));
        }else{
            cTime = System.currentTimeMillis();
            say(VicQuestionOld(oldQuestion));
        }
    }

    private void timeEvent() {
        if(testTime()) {
            cTime = System.currentTimeMillis();
            Question();
        }
    }

    private void say(String m) {
        String s = NICK()  + "\n" + m;
        srv.cq.addMsg(s,"",psp.getIntProperty("vik.room"));
    }

    public void parse(String uin, String msg, int room){
        Users uss = srv.us.getUser(uin);
        if (room == psp.getIntProperty("vik.room") && Answer.equalsIgnoreCase(msg)){
            say(uss.localnick + " ��������� �������(�) � �������� + " + psp.getIntProperty("vik.ball") + " �����(��)");
            int rating = uss.rating + psp.getIntProperty("vik.ball");
            uss.rating = rating;
            srv.us.updateUser(uss);
            cTime = System.currentTimeMillis();
            say(VicQuestion(getRND((int)(maxVic - 2)) +1));
        }
    }

    public char[] getMix() {
        return mix;
    }

    public void replaceOne() {
        if (starsCount == 0) {
            return;
        }
        int nextStarIndex = r.nextInt(starsCount);
        for (int i = 0; i < mix.length; i++) {
            if (mix[i] == '*') {
                if (nextStarIndex-- == 0){
                    mix[i] = word.charAt(i);
                    break;
                }
            }
        }
        starsCount--;
    }

    public boolean hasStars() {
        return starsCount!=1 && starsCount!=0;
    }

    public String toString() {
        return word;
    }

    public int Star(){
        return starsCount;
    }

    public void start() {
        th = new Thread(this);
        th.setPriority(Thread.NORM_PRIORITY);
        th.start();
    }

    public synchronized void stop() {
        th = null;
        notify();
    }

    public void run() {
        Thread me = Thread.currentThread();
        while (th == me) {
            timeEvent();
            try {
                Thread.sleep(sleepAmount);
            } catch (InterruptedException e) { break; }
        }
        th=null;
    }
}