package ru.jimbot.modules.chat;

import ru.jimbot.modules.AbstractConnection;

public class ChatConnection extends AbstractConnection{
    
    public ChatConnection(ChatServer s) {
        srv = s;
    }
}