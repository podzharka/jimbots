package ru.jimbot.modules.chat;

import ru.jimbot.protocol.IcqProtocol;

public class MsgElement {
    public String msg="";
    public String uin="";
    public int room;
    public IcqProtocol proc;

    MsgElement(String m, String u, IcqProtocol p, int room) {
        msg = m;
        uin = u;
        proc = p;
        this.room = room;
    }
}