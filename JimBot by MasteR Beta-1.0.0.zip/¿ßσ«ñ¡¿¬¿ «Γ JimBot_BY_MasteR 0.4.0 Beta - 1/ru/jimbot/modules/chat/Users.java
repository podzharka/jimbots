package ru.jimbot.modules.chat;

import java.sql.Types;
import ru.jimbot.db.DBObject;

public class Users extends DBObject {
    public int id = 0;
    public String sn = "";
    public String nick="";
    public String localnick = "";
    public String fname="";
    public String lname="";
    public String gr = "user";
    public String status="";
    public int gender= 0;
    public int age= 0;
    public int rs= 0;
    public int rsid= 0;
    public String rsnick="";
    public String country="";
    public String city="";
    public String email="";
    public String homepage="";
    public int rating= 0;
    public String cloth = "";
    public String house = "";
    public String transport = "";
    public String pet = "";
    public String info = "";
    public int bomb= 0;
    public int language= -1;
    public int state = 0;
    public String basesn="";
    public long createtime=0;
    public int room = 0;
    public long bombtime = System.currentTimeMillis();
    public long lastbanroom = System.currentTimeMillis();
    public long lastKick = System.currentTimeMillis();

    public Users() {
        init();
        createtime = System.currentTimeMillis();
    }

    public Users (int _id,
            String _sn,
            String _nick,
            String _localNick,
            String _fname,
            String _lname,
            int _gender,
            int _age,
            String _country,
            String _city,
            String _email,
            String _homepage) {
        id = _id;
        sn = _sn;
        nick = _nick;
        localnick = _localNick;
        fname = _fname;
        lname = _lname;
        gender = _gender;
        age = _age;
        country = _country;
        city = _city;
        email = _email;
        homepage = _homepage;
    }

    private void init(){
        fields = new String[] {
            "id",
            "sn",
            "nick",
            "localnick",
            "fname",
            "lname",
            "gr",
            "status",
            "gender",
            "age",
            "rs",
            "rsid",
            "rsnick",
            "country",
            "city",
            "email",
            "homepage",
            "rating",
            "cloth",
            "house",
            "transport",
            "pet",
            "info",
            "bomb",
            "language",
            "state",
            "basesn",
            "createtime",
            "room",
            "bombtime",
            "lastbanroom",
            "lastkick"

        };
        types = new int[] {
            Types.INTEGER, //"id"
            Types.VARCHAR, //"sn"
            Types.VARCHAR, //"nick"
            Types.VARCHAR, //"localnick"
            Types.VARCHAR, //"fname"
            Types.VARCHAR, //"lname"
            Types.VARCHAR, //"gr"
            Types.VARCHAR, //"status"
            Types.INTEGER, //"gender"
            Types.INTEGER, //"age"
            Types.INTEGER, //"rs"
            Types.INTEGER, //"rsid"
            Types.VARCHAR, //"rsnick"
            Types.VARCHAR, //"country"
            Types.VARCHAR, //"city"
            Types.VARCHAR, //"email"
            Types.VARCHAR, //"homepage"
            Types.INTEGER, //"rating"
            Types.VARCHAR, //"cloth"
            Types.VARCHAR, //"house"
            Types.VARCHAR, //"transport"
            Types.VARCHAR, //"pet"
            Types.VARCHAR, //"info"
            Types.INTEGER, //"bomb"
            Types.INTEGER, //"language"
            Types.INTEGER, //"state"
            Types.VARCHAR, //"basesn"
            Types.TIMESTAMP, //"createtime"
            Types.INTEGER, //"room"
            Types.TIMESTAMP, //"bombtime"
            Types.TIMESTAMP, //"lastbanroom"
            Types.TIMESTAMP}; //"lastkick"
            tableName="users";
    }


    public String getInfo(){
        String s = "���������� � ������������:";
        s += "\nID: " + id;
        s += "\nUIN: " + sn;
        s += "\n��� � ���� ICQ: " + nick;
        s += "\n��� � ����: " + localnick;
        if(fname.equals("")){
            s += "";
        } else {
            s += "\n���: " + fname;
        }
        if(lname.equals("")){
            s += "";
        } else {
            s += "\n�������: " + lname;
        }
        s += "\n������: " + gr;
        if(status.equals("")){
            s += "";
        } else {
            s += "\n������: " + status;
        }
        if(gender==0){
            s += "";
        } else {
            if(gender==1){
                s += "\n���: �������";
            } else {
                s += "\n���: �������";
            }
        }
        if(age==0){
            s += "";
        } else {
            s += "\n�������: " + age;
        }
        if(rs==0){
            s += "\n�������� ���������: �� � �����";
        } else {
            if(rs==1){
                s += "\n�������� ���������: ����� �� " + rsnick;
            } else {
                s += "\n�������� ���������: ������� �� " + rsnick;
            }
        }
        if(country.equals("")){
            s += "";
        } else {
            s += "\n������: " + country;
        }
        if(city.equals("")){
            s += "";
        } else {
            s += "\n�����: " + city;
        }
        if(email.equals("")){
            s += "";
        } else {
            s += "\ne-mail: " + email;
        }
        if(homepage.equals("")){
            s += "";
        } else {
            s += "\n�������� ��������: " + homepage;
        }
        s += "\n�������: " + rating;
        if(cloth.equals("")){
            s += "";
        } else {
            s += "\n������: " + cloth;
        }
        if(house.equals("")){
            s += "";
        } else {
            s += "\n����� ����������: " + house;
        }
        if(transport.equals("")){
            s += "";
        } else {
            s += "\n�������� ������������: "+transport;
        }
        if(pet.equals("")){
            s += "";
        } else {
            s += "\n�������� ��������: "+pet;
        }
        if(info.equals("")){
            s += "";
        } else {
            s += "\n������� � ����: "+info;
        }
        if(state==-1){
            s += "\n������������ �������";
        } else {
            if(state==1){
                s += "\n������������ ��� ����";
            } else {
                if(state==2){
                    s += "\n������������ � ����";
                } else {
                    s += "\n������������ ��� ����";
                }
            }
        }
        return s;
    }

    public String[] getFields(){
        return fields;
    }

    public int[] getTypes(){
        return types;
    }

    public String getTableName(){
        return this.tableName;
    }
}