package ru.jimbot.db;

public abstract class DBObject {
    protected String[] fields;
    protected int[] types;
    protected String tableName;
    
    public DBObject() {
    }
    
    public abstract String[] getFields();

    public abstract int[] getTypes();

    public abstract String getTableName();
}