package ru.jimbot.protocol;

import ru.jimbot.modules.MsgOutQueue;

public abstract class AbstractProtocol { //  ���������� �������� ���������
    public String server="";
    public int port = 0;
    public boolean useProxy = false;
    public String proxyHost = "";
    public int proxyPort = 0;
    public String proxyUser = "";
    public String proxyPass = "";
    public String screenName = "";
    public String password = "";
    public MsgOutQueue mq;
    public String baseUin="";
    private String basePass="";    
    protected ProtocolListener protList;

    public void addListener(ProtocolListener p){ // �������� ������
        protList = p;
    }

    public abstract void connect();
    public abstract void reConnect();
    public abstract void disconnect();
    public abstract void setStatus(int status);
    public abstract boolean isOnLine();
    public abstract void sendMsg(String sn, String msg);
    public abstract void getMsg(String sendSN, String recivSN, String msg, boolean isOffline);
    public abstract void getStatus(String sn, int status);
    public abstract void addContactList(String sn);
    public abstract void RemoveContactList(String sn);
}