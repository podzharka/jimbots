package ru.jimbot.util;

import java.io.Serializable;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Log implements Serializable {

    private static Logger system, con, err, http, talk, flood;
    
    public static final String PATTERN = "[%d{dd.MM.yy HH:mm:ss}] %m%n";

    public static final int MAX_BACKUP_INDEX = 5;

    private Log() {}

    public static void init(String level) {
    	PropertyConfigurator.configure("lib/log4j.properties");
    	system = Logger.getRootLogger();
//    	con = Logger.getLogger("con");
    	err = Logger.getLogger("error");
    	http = Logger.getLogger("http");
    	talk = Logger.getLogger("talk");
    	flood = Logger.getLogger("flood");
    }

    public static synchronized void info(Object message, Throwable throwable) {
        system.info(message, throwable);
    }

    public static synchronized void debug(Object message) {
    	system.debug(message);
    }

    public static synchronized void debug(Object message, Throwable throwable) {
    	system.debug(message, throwable);
    }

    public static synchronized void error(Object message, Throwable throwable) {
        err.error(message, throwable);
    }

    public static synchronized void info(Object message) {
    	system.info(message);
    }

    public static synchronized void http(Object message) {
    	http.debug(message);
    }

    public static synchronized void talk(Object message) {
    	talk.info(message);
    }

    public static synchronized void flood(Object message) {
    	flood.info(message);
    }

    public static synchronized void flood2(Object message) {
    	flood.debug(message);
    }

    public static synchronized void error(Object message) {
    	err.error(message);
    }

    public static boolean isLogEnabled() {
        return system != null;
    }
}