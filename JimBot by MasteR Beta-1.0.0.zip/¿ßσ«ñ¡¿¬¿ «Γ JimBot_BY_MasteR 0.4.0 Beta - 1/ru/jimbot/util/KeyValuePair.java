package ru.jimbot.util;

public class KeyValuePair implements java.io.Serializable {
    public String key;
    public String value;
    public KeyValuePair() {}

    public KeyValuePair(String key, String value) {
        this.key = key;
        this.value = value;
    }
}