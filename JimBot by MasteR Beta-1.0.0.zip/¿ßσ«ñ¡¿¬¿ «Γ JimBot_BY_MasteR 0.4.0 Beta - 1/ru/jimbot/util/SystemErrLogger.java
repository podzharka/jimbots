package ru.jimbot.util;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.SwingUtilities;

public class SystemErrLogger extends OutputStream {
  
    private StringBuffer buf;
    private Matcher newLineMatcher;
    private PrintStream systemErr;

    public SystemErrLogger() {
        systemErr = System.err;
        buf = new StringBuffer();
        newLineMatcher = Pattern.compile("[\n\r]+").matcher("");
    }

    private void log(final String s) {
        Runnable update = new Runnable() {
            public void run() {
                newLineMatcher.reset(s);
                if (s.length() == 1 && newLineMatcher.find()) {
                    return;
                }
                String text = newLineMatcher.replaceAll(" ");
                Log.error(text);
            }
        };
        SwingUtilities.invokeLater(update);
    }

    public synchronized void write(int b) {
        systemErr.write(b);
        b &= 0x000000FF;
        char c = (char)b;
        buf.append(String.valueOf(c));
    }

    public synchronized void write(byte[] b, int offset, int length) {
        systemErr.write(b, offset, length);
        buf.append(new String(b, offset, length));
    }

    public synchronized void write(byte[] b) {
        try {
            systemErr.write(b);
        } catch (IOException e) {}
        buf.append(new String(b));
    }

    public synchronized void flush() {
        systemErr.flush();
        synchronized (buf) {
            if (buf.length() > 0) {
                log(buf.toString());
                buf.setLength(0);
            }                
        }
    } 
}