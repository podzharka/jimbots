package ru.jimbot;

public class Monitor2 implements Runnable {
    boolean isPause=false;
    private Thread th;
    int sleepAmount = 1000;
    private static final int testMaxCount = 30;
    private int count =0;

    public Monitor2() {
    }

    public void start(){
        th = new Thread(this,"monitor");
        th.setPriority(Thread.MIN_PRIORITY);
        th.start();
    }

    public synchronized void stop() {
        th = null;
        notify();
    }

    private void testState(){
        count++;
        if(count>testMaxCount){
            count=0;
            Manager.getInstance().testState();
            Manager.getInstance().testDB();
        }
    }

    public void run() {
        Thread me = Thread.currentThread(); 
        while (th == me) {
            testState();
            try {
                Thread.sleep(sleepAmount);
            } catch (InterruptedException e) { break; }             
        }
        th=null;
    }
}